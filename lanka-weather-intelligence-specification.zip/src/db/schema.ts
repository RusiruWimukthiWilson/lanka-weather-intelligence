import {
  boolean,
  doublePrecision,
  index,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    email: text("email").notNull(),
    name: text("name").notNull(),
    passwordHash: text("password_hash").notNull(),
    role: text("role").notNull().default("user"),
    language: text("language").notNull().default("en"),
    units: text("units").notNull().default("metric"),
    reduceMotion: boolean("reduce_motion").notNull().default(false),
    highContrast: boolean("high_contrast").notNull().default(false),
    homeLabel: text("home_label"),
    homeLat: doublePrecision("home_lat"),
    homeLon: doublePrecision("home_lon"),
    quietHoursStart: integer("quiet_hours_start").notNull().default(22),
    quietHoursEnd: integer("quiet_hours_end").notNull().default(6),
    quietHoursEnabled: boolean("quiet_hours_enabled").notNull().default(true),
    pushEnabled: boolean("push_enabled").notNull().default(false),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("users_email_unique").on(t.email)],
);

export const sessions = pgTable(
  "sessions",
  {
    token: text("token").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("sessions_user_idx").on(t.userId)],
);

export const savedLocations = pgTable(
  "saved_locations",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    label: text("label").notNull(),
    district: text("district"),
    province: text("province"),
    lat: doublePrecision("lat").notNull(),
    lon: doublePrecision("lon").notNull(),
    isDefault: boolean("is_default").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("saved_locations_user_idx").on(t.userId)],
);

export const subscriptions = pgTable(
  "subscriptions",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    scopeType: text("scope_type").notNull(), // location | district
    scopeLabel: text("scope_label").notNull(),
    district: text("district"),
    lat: doublePrecision("lat"),
    lon: doublePrecision("lon"),
    categories: jsonb("categories").notNull().default([]), // e.g. ["rain","wind","heat","lightning","flood","marine"]
    minimumSeverity: text("minimum_severity").notNull().default("advisory"),
    channel: text("channel").notNull().default("in_app"),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("subscriptions_user_idx").on(t.userId)],
);

export const notifications = pgTable(
  "notifications",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    body: text("body").notNull(),
    category: text("category").notNull(),
    severity: text("severity").notNull().default("info"),
    kind: text("kind").notNull().default("advisory"), // advisory | community | system
    source: text("source").notNull().default("Lanka Weather Intelligence"),
    origin: text("origin").notNull().default("model"), // official | model | community | system
    dedupeKey: text("dedupe_key").notNull(),
    link: text("link"),
    readAt: timestamp("read_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    index("notifications_user_idx").on(t.userId),
    uniqueIndex("notifications_dedupe_unique").on(t.dedupeKey),
  ],
);

export const alerts = pgTable(
  "alerts",
  {
    id: serial("id").primaryKey(),
    dedupeKey: text("dedupe_key").notNull(),
    source: text("source").notNull(), // dmc | meteo | nbro | irrigation | model-lwi
    origin: text("origin").notNull().default("model"), // official | model
    authority: text("authority").notNull(),
    title: text("title").notNull(),
    hazard: text("hazard").notNull(), // rain | flood | landslide | lightning | wind | cyclone | heat | marine
    severity: text("severity").notNull(), // advisory | watch | warning
    summary: text("summary").notNull(),
    impacts: jsonb("impacts").notNull().default([]),
    actions: jsonb("actions").notNull().default([]),
    areas: jsonb("areas").notNull().default([]),
    lat: doublePrecision("lat"),
    lon: doublePrecision("lon"),
    issuedAt: timestamp("issued_at", { withTimezone: true }).notNull().defaultNow(),
    effectiveAt: timestamp("effective_at", { withTimezone: true }).notNull().defaultNow(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    evidence: jsonb("evidence").notNull().default({}),
    isActive: boolean("is_active").notNull().default(true),
    fetchedAt: timestamp("fetched_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("alerts_dedupe_unique").on(t.dedupeKey),
    index("alerts_active_idx").on(t.isActive),
  ],
);

export const communityReports = pgTable(
  "community_reports",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
    reporterName: text("reporter_name").notNull().default("Anonymous observer"),
    category: text("category").notNull(), // rain_started | heavy_rain | flood | strong_wind | waterlogging | heat | other
    intensity: text("intensity").notNull().default("moderate"),
    note: text("note"),
    placeLabel: text("place_label").notNull(),
    district: text("district"),
    lat: doublePrecision("lat").notNull(),
    lon: doublePrecision("lon").notNull(),
    photoData: text("photo_data"),
    status: text("status").notNull().default("pending"), // pending | verified | rejected
    credibility: integer("credibility").notNull().default(50),
    upvotes: integer("upvotes").notNull().default(0),
    downvotes: integer("downvotes").notNull().default(0),
    isDemo: boolean("is_demo").notNull().default(false),
    moderatedBy: integer("moderated_by").references(() => users.id, { onDelete: "set null" }),
    moderationNote: text("moderation_note"),
    observedAt: timestamp("observed_at", { withTimezone: true }).notNull().defaultNow(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("community_reports_created_idx").on(t.createdAt)],
);

export const reportVotes = pgTable(
  "report_votes",
  {
    id: serial("id").primaryKey(),
    reportId: integer("report_id")
      .notNull()
      .references(() => communityReports.id, { onDelete: "cascade" }),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    value: integer("value").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("report_votes_unique").on(t.reportId, t.userId)],
);

export const assistantMessages = pgTable(
  "assistant_messages",
  {
    id: serial("id").primaryKey(),
    threadId: text("thread_id").notNull(),
    userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
    role: text("role").notNull(),
    content: text("content").notNull(),
    language: text("language").notNull().default("en"),
    engine: text("engine").notNull().default("lwi-rules"),
    citations: jsonb("citations").notNull().default([]),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("assistant_thread_idx").on(t.threadId)],
);

export const auditLogs = pgTable(
  "audit_logs",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
    actorLabel: text("actor_label").notNull().default("system"),
    action: text("action").notNull(),
    entity: text("entity"),
    meta: jsonb("meta").notNull().default({}),
    ip: text("ip"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("audit_logs_created_idx").on(t.createdAt)],
);

export const integrationStatus = pgTable(
  "integration_status",
  {
    id: serial("id").primaryKey(),
    provider: text("provider").notNull(),
    endpoint: text("endpoint").notNull(),
    kind: text("kind").notNull(), // observation | forecast | advisory | marine | air-quality
    status: text("status").notNull().default("unknown"), // ok | degraded | down | unavailable
    lastOkAt: timestamp("last_ok_at", { withTimezone: true }),
    lastCheckedAt: timestamp("last_checked_at", { withTimezone: true }),
    lastError: text("last_error"),
    latencyMs: integer("latency_ms"),
    notes: text("notes"),
  },
  (t) => [uniqueIndex("integration_provider_unique").on(t.provider)],
);

export const ingestRuns = pgTable("ingest_runs", {
  id: serial("id").primaryKey(),
  startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
  finishedAt: timestamp("finished_at", { withTimezone: true }),
  alertsFound: integer("alerts_found").notNull().default(0),
  alertsActive: integer("alerts_active").notNull().default(0),
  notificationsCreated: integer("notifications_created").notNull().default(0),
  officialFeedStatus: text("official_feed_status").notNull().default("unavailable"),
  notes: text("notes"),
});
