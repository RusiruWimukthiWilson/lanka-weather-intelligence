export type Province =
  | "Western"
  | "Central"
  | "Southern"
  | "Northern"
  | "Eastern"
  | "North Western"
  | "North Central"
  | "Uva"
  | "Sabaragamuwa";

export type DistrictInfo = {
  name: string;
  province: Province;
  capital: string;
  lat: number;
  lon: number;
  coastal: boolean;
  /** Model screening factor for rainfall-triggered landslide susceptibility. */
  terrain: "coastal-lowland" | "inland-lowland" | "hill-country" | "highland" | "dry-plain";
  marineArea?: string;
  si: string;
  ta: string;
};

export type Place = {
  name: string;
  district: string;
  province: Province;
  lat: number;
  lon: number;
  kind: "city" | "town" | "village";
  population?: number;
};

export const PROVINCES: { name: Province; capital: string; si: string; ta: string }[] = [
  { name: "Western", capital: "Colombo", si: "බස්නාහිර පළාත", ta: "மேல் மாகாணம்" },
  { name: "Central", capital: "Kandy", si: "මධ්‍යම පළාත", ta: "மத்திய மாகாணம்" },
  { name: "Southern", capital: "Galle", si: "දකුණු පළාත", ta: "தென் மாகாணம்" },
  { name: "Northern", capital: "Jaffna", si: "උතුරු පළාත", ta: "வட மாகாணம்" },
  { name: "Eastern", capital: "Trincomalee", si: "නැගෙනහිර පළාත", ta: "கிழக்கு மாகாணம்" },
  { name: "North Western", capital: "Kurunegala", si: "වයඹ පළාත", ta: "வட மேல் மாகாணம்" },
  { name: "North Central", capital: "Anuradhapura", si: "උතුරු මැද පළාත", ta: "வட மத்திய மாகாணம்" },
  { name: "Uva", capital: "Badulla", si: "ඌව පළාත", ta: "ஊவா மாகாணம்" },
  { name: "Sabaragamuwa", capital: "Ratnapura", si: "සබරගමුව පළාත", ta: "சபரகமுவ மாகாணம்" },
];

export const DISTRICTS: DistrictInfo[] = [
  { name: "Colombo", province: "Western", capital: "Colombo", lat: 6.9271, lon: 79.8612, coastal: true, terrain: "coastal-lowland", marineArea: "Colombo–Negombo", si: "කොළඹ", ta: "கொழும்பு" },
  { name: "Gampaha", province: "Western", capital: "Gampaha", lat: 7.0917, lon: 80.0, coastal: true, terrain: "coastal-lowland", marineArea: "Colombo–Negombo", si: "ගම්පහ", ta: "கம்பஹா" },
  { name: "Kalutara", province: "Western", capital: "Kalutara", lat: 6.5854, lon: 79.9609, coastal: true, terrain: "coastal-lowland", marineArea: "Colombo–Galle", si: "කළුතර", ta: "களுத்துறை" },
  { name: "Kandy", province: "Central", capital: "Kandy", lat: 7.2906, lon: 80.6337, coastal: false, terrain: "hill-country", si: "මහනුවර", ta: "கண்டி" },
  { name: "Matale", province: "Central", capital: "Matale", lat: 7.4675, lon: 80.6234, coastal: false, terrain: "hill-country", si: "මාතලේ", ta: "மாத்தளை" },
  { name: "Nuwara Eliya", province: "Central", capital: "Nuwara Eliya", lat: 6.9497, lon: 80.7891, coastal: false, terrain: "highland", si: "නුවරඑළිය", ta: "நுவரெலியா" },
  { name: "Galle", province: "Southern", capital: "Galle", lat: 6.0535, lon: 80.221, coastal: true, terrain: "coastal-lowland", marineArea: "Galle–Matara", si: "ගාල්ල", ta: "காலி" },
  { name: "Matara", province: "Southern", capital: "Matara", lat: 5.9485, lon: 80.5353, coastal: true, terrain: "coastal-lowland", marineArea: "Galle–Matara", si: "මාතර", ta: "மாத்தறை" },
  { name: "Hambantota", province: "Southern", capital: "Hambantota", lat: 6.1246, lon: 81.1185, coastal: true, terrain: "dry-plain", marineArea: "Matara–Hambantota", si: "හම්බන්තොට", ta: "அம்பாந்தோட்டை" },
  { name: "Jaffna", province: "Northern", capital: "Jaffna", lat: 9.6615, lon: 80.0255, coastal: true, terrain: "dry-plain", marineArea: "Jaffna–Mannar", si: "යාපනය", ta: "யாழ்ப்பாணம்" },
  { name: "Kilinochchi", province: "Northern", capital: "Kilinochchi", lat: 9.3803, lon: 80.377, coastal: true, terrain: "dry-plain", marineArea: "Jaffna–Mannar", si: "කිලිනොච්චි", ta: "கிளிநொச்சி" },
  { name: "Mannar", province: "Northern", capital: "Mannar", lat: 8.981, lon: 79.9044, coastal: true, terrain: "dry-plain", marineArea: "Jaffna–Mannar", si: "මන්නාරම", ta: "மான்னார்" },
  { name: "Vavuniya", province: "Northern", capital: "Vavuniya", lat: 8.7514, lon: 80.4971, coastal: false, terrain: "dry-plain", si: "වවුන්නියාව", ta: "வவுனியா" },
  { name: "Mullaitivu", province: "Northern", capital: "Mullaitivu", lat: 9.2671, lon: 80.8142, coastal: true, terrain: "dry-plain", marineArea: "Mullaitivu–Trincomalee", si: "මුලතිව්", ta: "முல்லைத்தீவு" },
  { name: "Batticaloa", province: "Eastern", capital: "Batticaloa", lat: 7.7102, lon: 81.6924, coastal: true, terrain: "coastal-lowland", marineArea: "Batticaloa", si: "මඩකලපුව", ta: "மட்டக்களப்பு" },
  { name: "Ampara", province: "Eastern", capital: "Ampara", lat: 7.2975, lon: 81.6747, coastal: true, terrain: "dry-plain", marineArea: "Batticaloa–Pottuvil", si: "අම්පාර", ta: "அம்பாறை" },
  { name: "Trincomalee", province: "Eastern", capital: "Trincomalee", lat: 8.5874, lon: 81.2152, coastal: true, terrain: "coastal-lowland", marineArea: "Trincomalee", si: "ත්‍රිකුණාමලය", ta: "திருகோணமலை" },
  { name: "Kurunegala", province: "North Western", capital: "Kurunegala", lat: 7.4863, lon: 80.3623, coastal: false, terrain: "inland-lowland", si: "කුරුණෑගල", ta: "குருநாகல்" },
  { name: "Puttalam", province: "North Western", capital: "Puttalam", lat: 8.0362, lon: 79.8283, coastal: true, terrain: "coastal-lowland", marineArea: "Puttalam–Chilaw", si: "පුත්තලම", ta: "புத்தளம்" },
  { name: "Anuradhapura", province: "North Central", capital: "Anuradhapura", lat: 8.3114, lon: 80.4037, coastal: false, terrain: "dry-plain", si: "අනුරාධපුරය", ta: "அனுராதபுரம்" },
  { name: "Polonnaruwa", province: "North Central", capital: "Polonnaruwa", lat: 7.9403, lon: 81.0188, coastal: false, terrain: "dry-plain", si: "පොළොන්නරුව", ta: "பொலன்னறுவை" },
  { name: "Badulla", province: "Uva", capital: "Badulla", lat: 6.9895, lon: 81.055, coastal: false, terrain: "hill-country", si: "බදුල්ල", ta: "பதுளை" },
  { name: "Monaragala", province: "Uva", capital: "Monaragala", lat: 6.8728, lon: 81.3507, coastal: false, terrain: "inland-lowland", si: "මොනරාගල", ta: "மொனராகலை" },
  { name: "Ratnapura", province: "Sabaragamuwa", capital: "Ratnapura", lat: 6.6828, lon: 80.3992, coastal: false, terrain: "hill-country", si: "රත්නපුර", ta: "இரத்தினபுரி" },
  { name: "Kegalle", province: "Sabaragamuwa", capital: "Kegalle", lat: 7.2513, lon: 80.3464, coastal: false, terrain: "hill-country", si: "කෑගල්ල", ta: "கேகாலை" },
];

export const PLACES: Place[] = [
  { name: "Colombo", district: "Colombo", province: "Western", lat: 6.9271, lon: 79.8612, kind: "city", population: 752993 },
  { name: "Dehiwala-Mount Lavinia", district: "Colombo", province: "Western", lat: 6.8511, lon: 79.8647, kind: "city" },
  { name: "Moratuwa", district: "Colombo", province: "Western", lat: 6.773, lon: 79.8816, kind: "city" },
  { name: "Kolonnawa", district: "Colombo", province: "Western", lat: 6.9329, lon: 79.8893, kind: "town" },
  { name: "Homagama", district: "Colombo", province: "Western", lat: 6.844, lon: 80.0026, kind: "town" },
  { name: "Avissawella", district: "Colombo", province: "Western", lat: 6.9508, lon: 80.2147, kind: "town" },
  { name: "Negombo", district: "Gampaha", province: "Western", lat: 7.2083, lon: 79.8358, kind: "city" },
  { name: "Gampaha", district: "Gampaha", province: "Western", lat: 7.0917, lon: 80.0, kind: "city" },
  { name: "Kelaniya", district: "Gampaha", province: "Western", lat: 6.9553, lon: 79.9219, kind: "town" },
  { name: "Wattala", district: "Gampaha", province: "Western", lat: 6.9903, lon: 79.8919, kind: "town" },
  { name: "Ja-Ela", district: "Gampaha", province: "Western", lat: 7.0744, lon: 79.8917, kind: "town" },
  { name: "Minuwangoda", district: "Gampaha", province: "Western", lat: 7.1667, lon: 79.9508, kind: "town" },
  { name: "Kalutara", district: "Kalutara", province: "Western", lat: 6.5854, lon: 79.9609, kind: "city" },
  { name: "Panadura", district: "Kalutara", province: "Western", lat: 6.7132, lon: 79.9026, kind: "city" },
  { name: "Horana", district: "Kalutara", province: "Western", lat: 6.7156, lon: 80.0628, kind: "town" },
  { name: "Matugama", district: "Kalutara", province: "Western", lat: 6.4833, lon: 80.1, kind: "town" },
  { name: "Beruwala", district: "Kalutara", province: "Western", lat: 6.4788, lon: 79.9828, kind: "town" },
  { name: "Kandy", district: "Kandy", province: "Central", lat: 7.2906, lon: 80.6337, kind: "city" },
  { name: "Peradeniya", district: "Kandy", province: "Central", lat: 7.2599, lon: 80.5977, kind: "town" },
  { name: "Katugastota", district: "Kandy", province: "Central", lat: 7.3333, lon: 80.6167, kind: "town" },
  { name: "Gampola", district: "Kandy", province: "Central", lat: 7.1642, lon: 80.5761, kind: "town" },
  { name: "Nawalapitiya", district: "Kandy", province: "Central", lat: 7.0544, lon: 80.5331, kind: "town" },
  { name: "Hatton", district: "Nuwara Eliya", province: "Central", lat: 6.8916, lon: 80.5955, kind: "town" },
  { name: "Nuwara Eliya", district: "Nuwara Eliya", province: "Central", lat: 6.9497, lon: 80.7891, kind: "city" },
  { name: "Ginigathhena", district: "Nuwara Eliya", province: "Central", lat: 6.9833, lon: 80.5167, kind: "town" },
  { name: "Matale", district: "Matale", province: "Central", lat: 7.4675, lon: 80.6234, kind: "city" },
  { name: "Dambulla", district: "Matale", province: "Central", lat: 7.86, lon: 80.6516, kind: "town" },
  { name: "Ukuwela", district: "Matale", province: "Central", lat: 7.5167, lon: 80.6667, kind: "town" },
  { name: "Galle", district: "Galle", province: "Southern", lat: 6.0535, lon: 80.221, kind: "city" },
  { name: "Hikkaduwa", district: "Galle", province: "Southern", lat: 6.1395, lon: 80.1063, kind: "town" },
  { name: "Ambalangoda", district: "Galle", province: "Southern", lat: 6.2354, lon: 80.0539, kind: "town" },
  { name: "Elpitiya", district: "Galle", province: "Southern", lat: 6.3, lon: 80.15, kind: "town" },
  { name: "Matara", district: "Matara", province: "Southern", lat: 5.9485, lon: 80.5353, kind: "city" },
  { name: "Weligama", district: "Matara", province: "Southern", lat: 5.9727, lon: 80.4297, kind: "town" },
  { name: "Akuressa", district: "Matara", province: "Southern", lat: 6.1019, lon: 80.4789, kind: "town" },
  { name: "Dikwella", district: "Matara", province: "Southern", lat: 5.9, lon: 80.6833, kind: "town" },
  { name: "Hambantota", district: "Hambantota", province: "Southern", lat: 6.1246, lon: 81.1185, kind: "city" },
  { name: "Tangalle", district: "Hambantota", province: "Southern", lat: 6.0245, lon: 80.7938, kind: "town" },
  { name: "Tissamaharama", district: "Hambantota", province: "Southern", lat: 6.2778, lon: 81.2847, kind: "town" },
  { name: "Ambalantota", district: "Hambantota", province: "Southern", lat: 6.1333, lon: 81.0, kind: "town" },
  { name: "Jaffna", district: "Jaffna", province: "Northern", lat: 9.6615, lon: 80.0255, kind: "city" },
  { name: "Nallur", district: "Jaffna", province: "Northern", lat: 9.6733, lon: 80.0333, kind: "town" },
  { name: "Point Pedro", district: "Jaffna", province: "Northern", lat: 9.8333, lon: 80.25, kind: "town" },
  { name: "Chavakachcheri", district: "Jaffna", province: "Northern", lat: 9.65, lon: 80.1667, kind: "town" },
  { name: "Kilinochchi", district: "Kilinochchi", province: "Northern", lat: 9.3803, lon: 80.377, kind: "town" },
  { name: "Elephant Pass", district: "Kilinochchi", province: "Northern", lat: 9.5, lon: 80.4167, kind: "village" },
  { name: "Mannar", district: "Mannar", province: "Northern", lat: 8.981, lon: 79.9044, kind: "town" },
  { name: "Vavuniya", district: "Vavuniya", province: "Northern", lat: 8.7514, lon: 80.4971, kind: "city" },
  { name: "Mullaitivu", district: "Mullaitivu", province: "Northern", lat: 9.2671, lon: 80.8142, kind: "town" },
  { name: "Batticaloa", district: "Batticaloa", province: "Eastern", lat: 7.7102, lon: 81.6924, kind: "city" },
  { name: "Kalmunai", district: "Ampara", province: "Eastern", lat: 7.4094, lon: 81.8344, kind: "city" },
  { name: "Ampara", district: "Ampara", province: "Eastern", lat: 7.2975, lon: 81.6747, kind: "town" },
  { name: "Pottuvil", district: "Ampara", province: "Eastern", lat: 6.8667, lon: 81.8333, kind: "town" },
  { name: "Trincomalee", district: "Trincomalee", province: "Eastern", lat: 8.5874, lon: 81.2152, kind: "city" },
  { name: "Kantale", district: "Trincomalee", province: "Eastern", lat: 8.3333, lon: 81.0, kind: "town" },
  { name: "Kurunegala", district: "Kurunegala", province: "North Western", lat: 7.4863, lon: 80.3623, kind: "city" },
  { name: "Kuliyapitiya", district: "Kurunegala", province: "North Western", lat: 7.4667, lon: 80.0333, kind: "town" },
  { name: "Narammala", district: "Kurunegala", province: "North Western", lat: 7.4167, lon: 80.2, kind: "town" },
  { name: "Nikaweratiya", district: "Kurunegala", province: "North Western", lat: 7.75, lon: 80.1167, kind: "town" },
  { name: "Puttalam", district: "Puttalam", province: "North Western", lat: 8.0362, lon: 79.8283, kind: "town" },
  { name: "Chilaw", district: "Puttalam", province: "North Western", lat: 7.5758, lon: 79.7953, kind: "town" },
  { name: "Anamaduwa", district: "Puttalam", province: "North Western", lat: 7.8833, lon: 80.0167, kind: "village" },
  { name: "Anuradhapura", district: "Anuradhapura", province: "North Central", lat: 8.3114, lon: 80.4037, kind: "city" },
  { name: "Kekirawa", district: "Anuradhapura", province: "North Central", lat: 8.2333, lon: 80.7333, kind: "town" },
  { name: "Medawachchiya", district: "Anuradhapura", province: "North Central", lat: 8.5333, lon: 80.6, kind: "village" },
  { name: "Polonnaruwa", district: "Polonnaruwa", province: "North Central", lat: 7.9403, lon: 81.0188, kind: "city" },
  { name: "Hingurakgoda", district: "Polonnaruwa", province: "North Central", lat: 8.0333, lon: 81.0833, kind: "town" },
  { name: "Badulla", district: "Badulla", province: "Uva", lat: 6.9895, lon: 81.055, kind: "city" },
  { name: "Bandarawela", district: "Badulla", province: "Uva", lat: 6.8333, lon: 80.9833, kind: "town" },
  { name: "Welimada", district: "Badulla", province: "Uva", lat: 6.9, lon: 80.9167, kind: "town" },
  { name: "Passara", district: "Badulla", province: "Uva", lat: 7.0, lon: 81.15, kind: "town" },
  { name: "Monaragala", district: "Monaragala", province: "Uva", lat: 6.8728, lon: 81.3507, kind: "town" },
  { name: "Wellawaya", district: "Monaragala", province: "Uva", lat: 6.7333, lon: 81.1, kind: "town" },
  { name: "Ratnapura", district: "Ratnapura", province: "Sabaragamuwa", lat: 6.6828, lon: 80.3992, kind: "city" },
  { name: "Embilipitiya", district: "Ratnapura", province: "Sabaragamuwa", lat: 6.3333, lon: 80.85, kind: "town" },
  { name: "Balangoda", district: "Ratnapura", province: "Sabaragamuwa", lat: 6.65, lon: 80.7, kind: "town" },
  { name: "Pelmadulla", district: "Ratnapura", province: "Sabaragamuwa", lat: 6.6333, lon: 80.5167, kind: "town" },
  { name: "Kegalle", district: "Kegalle", province: "Sabaragamuwa", lat: 7.2513, lon: 80.3464, kind: "city" },
  { name: "Mawanella", district: "Kegalle", province: "Sabaragamuwa", lat: 7.25, lon: 80.4469, kind: "town" },
  { name: "Dehiowita", district: "Kegalle", province: "Sabaragamuwa", lat: 6.9667, lon: 80.3, kind: "town" },
  { name: "Ella", district: "Badulla", province: "Uva", lat: 6.8667, lon: 81.0467, kind: "town" },
  { name: "Sigiriya", district: "Matale", province: "Central", lat: 7.957, lon: 80.7603, kind: "village" },
  { name: "Kataragama", district: "Monaragala", province: "Uva", lat: 6.4139, lon: 81.3319, kind: "town" },
  { name: "Nuwara Eliya Tea Country", district: "Nuwara Eliya", province: "Central", lat: 6.9667, lon: 80.7833, kind: "village" },
  { name: "Arugam Bay", district: "Ampara", province: "Eastern", lat: 6.8403, lon: 81.8347, kind: "village" },
  { name: "Kalpitiya", district: "Puttalam", province: "North Western", lat: 8.2363, lon: 79.7663, kind: "town" },
  { name: "Negombo Lagoon", district: "Gampaha", province: "Western", lat: 7.15, lon: 79.8333, kind: "village" },
  { name: "Adam's Peak (Sri Pada)", district: "Ratnapura", province: "Sabaragamuwa", lat: 6.8094, lon: 80.4992, kind: "village" },
  { name: " Horton Plains", district: "Nuwara Eliya", province: "Central", lat: 6.8092, lon: 80.8017, kind: "village" },
  { name: "Yala", district: "Monaragala", province: "Uva", lat: 6.3728, lon: 81.5017, kind: "village" },
  { name: "Wilpattu", district: "Puttalam", province: "North Western", lat: 8.4333, lon: 80.0333, kind: "village" },
  { name: "Knuckles Range", district: "Matale", province: "Central", lat: 7.4333, lon: 80.7667, kind: "village" },
  { name: "Kurunegala Lake Town", district: "Kurunegala", province: "North Western", lat: 7.49, lon: 80.37, kind: "town" },
];

const districtByName = new Map(DISTRICTS.map((d) => [d.name, d]));

export function getDistrict(name?: string | null): DistrictInfo | undefined {
  if (!name) return undefined;
  return districtByName.get(name.trim());
}

export function provinceOf(district?: string | null): Province | undefined {
  return getDistrict(district)?.province;
}

/** Deterministic grid of real Sri Lankan locations used to render live weather layers. */
export const WEATHER_GRID: { name: string; lat: number; lon: number; district: string }[] = [
  ...DISTRICTS.map((d) => ({ name: d.capital, lat: d.lat, lon: d.lon, district: d.name })),
  ...[
    { name: "Negombo", lat: 7.2083, lon: 79.8358, district: "Gampaha" },
    { name: "Panadura", lat: 6.7132, lon: 79.9026, district: "Kalutara" },
    { name: "Hatton", lat: 6.8916, lon: 80.5955, district: "Nuwara Eliya" },
    { name: "Ella", lat: 6.8667, lon: 81.0467, district: "Badulla" },
    { name: "Sigiriya", lat: 7.957, lon: 80.7603, district: "Matale" },
    { name: "Kalpitiya", lat: 8.2363, lon: 79.7663, district: "Puttalam" },
    { name: "Point Pedro", lat: 9.8333, lon: 80.25, district: "Jaffna" },
    { name: "Pottuvil", lat: 6.8667, lon: 81.8333, district: "Ampara" },
    { name: "Kataragama", lat: 6.4139, lon: 81.3319, district: "Monaragala" },
    { name: "Balangoda", lat: 6.65, lon: 80.7, district: "Ratnapura" },
    { name: "Dambulla", lat: 7.86, lon: 80.6516, district: "Matale" },
    { name: "Hikkaduwa", lat: 6.1395, lon: 80.1063, district: "Galle" },
  ],
];

export function nearestDistrict(lat: number, lon: number): DistrictInfo {
  let best = DISTRICTS[0];
  let bestDist = Number.POSITIVE_INFINITY;
  for (const d of DISTRICTS) {
    const dx = d.lat - lat;
    const dy = (d.lon - lon) * 0.98;
    const dist = dx * dx + dy * dy;
    if (dist < bestDist) {
      bestDist = dist;
      best = d;
    }
  }
  return best;
}

export function nearestPlace(lat: number, lon: number): Place {
  let best = PLACES[0];
  let bestDist = Number.POSITIVE_INFINITY;
  for (const p of PLACES) {
    const dx = p.lat - lat;
    const dy = (p.lon - lon) * 0.98;
    const dist = dx * dx + dy * dy;
    if (dist < bestDist) {
      bestDist = dist;
      best = p;
    }
  }
  return best;
}

export function searchPlaces(query: string, limit = 8): Place[] {
  const q = query.trim().toLowerCase();
  if (!q) return PLACES.slice(0, limit);
  const starts: Place[] = [];
  const contains: Place[] = [];
  for (const p of PLACES) {
    const n = p.name.toLowerCase();
    const d = p.district.toLowerCase();
    if (n.startsWith(q)) starts.push(p);
    else if (n.includes(q) || d.includes(q)) contains.push(p);
  }
  return [...starts, ...contains].slice(0, limit);
}
