import { getDistrict, nearestDistrict, PLACES, type Place } from "@/lib/lk-geo";

export type ResolvedLocation = {
  name: string;
  lat: number;
  lon: number;
  district: string;
  province: string;
  resolvedBy: string;
};

export function resolveLocation(params: URLSearchParams): ResolvedLocation {
  const latRaw = params.get("lat");
  const lonRaw = params.get("lon");
  const name = params.get("name") ?? undefined;
  const district = params.get("district") ?? undefined;

  const lat = latRaw !== null ? Number(latRaw) : NaN;
  const lon = lonRaw !== null ? Number(lonRaw) : NaN;

  const d = getDistrict(district);
  const validCoords = Number.isFinite(lat) && Number.isFinite(lon) && Math.abs(lat) <= 90 && Math.abs(lon) <= 180;

  if (validCoords) {
    const near = nearestDistrict(lat, lon);
    const place = PLACES.reduce<Place | null>((best, p) => {
      const dist = (p.lat - lat) ** 2 + (p.lon - lon) ** 2;
      const bestDist = best ? (best.lat - lat) ** 2 + (best.lon - lon) ** 2 : Number.POSITIVE_INFINITY;
      return dist < bestDist ? p : best;
    }, null);
    const close = place && (place.lat - lat) ** 2 + (place.lon - lon) ** 2 < 0.09;
    return {
      name: name || (close ? place!.name : near.capital),
      lat,
      lon,
      district: d?.name ?? near.name,
      province: d?.province ?? near.province,
      resolvedBy: "coordinates",
    };
  }

  if (name) {
    const match = PLACES.find((p) => p.name.toLowerCase() === name.toLowerCase());
    if (match) {
      return { name: match.name, lat: match.lat, lon: match.lon, district: match.district, province: match.province, resolvedBy: "place-name" };
    }
  }

  if (d) {
    return { name: name || d.capital, lat: d.lat, lon: d.lon, district: d.name, province: d.province, resolvedBy: "district" };
  }

  const fallback = PLACES[0];
  return { name: fallback.name, lat: fallback.lat, lon: fallback.lon, district: fallback.district, province: fallback.province, resolvedBy: "default" };
}

export function jsonError(message: string, status = 400, extra: Record<string, unknown> = {}) {
  return Response.json({ error: message, ...extra }, { status });
}
