import { db } from "@/db";
import { alerts, ingestRuns } from "@/db/schema";
import { and, desc, eq, gte, sql } from "drizzle-orm";
import { WEATHER_GRID, getDistrict } from "@/lib/lk-geo";
import { fetchGrid } from "@/lib/weather/openmeteo";
import { deriveCellAdvisories, fetchOfficialFeeds, severityFromText, districtFromText, type Severity } from "@/lib/advisory";

export const dynamic = "force-dynamic";

type FeedCache = { at: number; status: string; reason?: string; items: Awaited<ReturnType<typeof fetchOfficialFeeds>>["items"] };
const g = globalThis as typeof globalThis & { __lwiFeedCache?: FeedCache; __lwiIngestAt?: number };

const HAZARDS = ["rain", "flood", "landslide", "lightning", "wind", "cyclone", "heat", "marine"];

export async function runAlertIngestion(): Promise<{ officialStatus: string; officialReason?: string; officialItems: number; modelItems: number }> {
  const now = new Date();
  const feed = g.__lwiFeedCache && now.getTime() - g.__lwiFeedCache.at < 10 * 60 * 1000
    ? g.__lwiFeedCache
    : null;

  const feedResult = feed ?? (await (async () => {
    const res = await fetchOfficialFeeds();
    g.__lwiFeedCache = { at: now.getTime(), status: res.status, reason: res.reason, items: res.items };
    return { status: res.status, reason: res.reason, items: res.items };
  })());

  let officialItems = 0;
  if (feedResult.status === "ok") {
    for (const item of feedResult.items) {
      const severity: Severity = severityFromText(`${item.title} ${item.summary}`);
      const areas = districtFromText(`${item.title} ${item.summary}`);
      const hazard = HAZARDS.find((h) => new RegExp(h, "i").test(`${item.title} ${item.summary}`)) ?? "rain";
      const issued = item.publishedAt ? new Date(item.publishedAt) : now;
      try {
        await db
          .insert(alerts)
          .values({
            dedupeKey: `official-${item.externalId}`.slice(0, 240),
            source: item.source,
            origin: "official",
            authority: item.authority,
            title: item.title.slice(0, 300),
            hazard,
            severity,
            summary: item.summary || item.title,
            impacts: [],
            actions: [`Verify this advisory directly with ${item.authority}.`],
            areas,
            issuedAt: issued,
            effectiveAt: issued,
            expiresAt: new Date(issued.getTime() + 3 * 86400 * 1000),
            evidence: { sourceUrl: item.link, retrievedAt: now.toISOString() },
            isActive: true,
            fetchedAt: now,
          })
          .onConflictDoUpdate({
            target: alerts.dedupeKey,
            set: { summary: item.summary || item.title, severity, areas, fetchedAt: now, isActive: true },
          });
        officialItems += 1;
      } catch {
        // ignore single item failures
      }
    }
  }

  // Deactivate expired records.
  await db.update(alerts).set({ isActive: false }).where(sql`${alerts.expiresAt} < now()`);

  // Model screening over the nationwide grid (single upstream request).
  let modelItems = 0;
  try {
    const grid = await fetchGrid(WEATHER_GRID);
    for (const cell of grid.cells) {
      for (const adv of deriveCellAdvisories(cell, now)) {
        const district = getDistrict(cell.district);
        await db
          .insert(alerts)
          .values({
            dedupeKey: adv.dedupeKey,
            source: "model-lwi",
            origin: "model",
            authority: adv.authority,
            title: adv.title,
            hazard: adv.hazard,
            severity: adv.severity,
            summary: adv.summary,
            impacts: adv.impacts,
            actions: adv.actions,
            areas: adv.areas,
            lat: district?.lat ?? cell.lat,
            lon: district?.lon ?? cell.lon,
            issuedAt: new Date(adv.issuedAt),
            effectiveAt: new Date(adv.effectiveAt),
            expiresAt: new Date(adv.expiresAt),
            evidence: adv.evidence,
            isActive: true,
            fetchedAt: now,
          })
          .onConflictDoUpdate({
            target: alerts.dedupeKey,
            set: {
              severity: adv.severity,
              summary: adv.summary,
              impacts: adv.impacts,
              actions: adv.actions,
              evidence: adv.evidence,
              expiresAt: new Date(adv.expiresAt),
              isActive: true,
              fetchedAt: now,
            },
          });
        modelItems += 1;
      }
    }
  } catch {
    // model screening requires upstream availability
  }

  await db.insert(ingestRuns).values({
    startedAt: now,
    finishedAt: new Date(),
    alertsFound: officialItems + modelItems,
    alertsActive: officialItems + modelItems,
    notificationsCreated: 0,
    officialFeedStatus: feedResult.status,
    notes: feedResult.reason ?? null,
  });

  return { officialStatus: feedResult.status, officialReason: feedResult.reason, officialItems, modelItems };
}

export async function listAlerts(opts: { district?: string | null; includeHistory?: boolean; hazard?: string | null } = {}) {
  const conditions = [eq(alerts.isActive, true)];
  if (opts.hazard) conditions.push(eq(alerts.hazard, opts.hazard));
  if (opts.district) {
    conditions.push(sql`(${alerts.areas}::text ILIKE ${"%" + opts.district + "%"} OR ${alerts.areas}::jsonb = ${JSON.stringify([])}::jsonb)`);
  }
  const rows = await db
    .select()
    .from(alerts)
    .where(and(...conditions))
    .orderBy(desc(alerts.severity), desc(alerts.issuedAt))
    .limit(opts.includeHistory ? 200 : 120);
  return rows;
}

export async function recentHistory(limit = 40) {
  return db.select().from(alerts).where(gte(alerts.issuedAt, new Date(Date.now() - 30 * 86400 * 1000))).orderBy(desc(alerts.issuedAt)).limit(limit);
}

export async function GET(request: Request) {
  const url = new URL(request.url);
  const district = url.searchParams.get("district");
  const hazard = url.searchParams.get("hazard");
  const history = url.searchParams.get("history") === "1";
  const refresh = url.searchParams.get("refresh") !== "0";

  if (refresh || g.__lwiIngestAt === undefined || Date.now() - g.__lwiIngestAt > 5 * 60 * 1000) {
    try {
      await runAlertIngestion();
      g.__lwiIngestAt = Date.now();
    } catch {
      // keep serving whatever is stored
    }
  }

  const [active, historyRows] = await Promise.all([
    listAlerts({ district, hazard }),
    history ? recentHistory(60) : Promise.resolve([]),
  ]);

  const lastRun = await db.select().from(ingestRuns).orderBy(desc(ingestRuns.startedAt)).limit(1);
  const officialCount = active.filter((a) => a.origin === "official").length;

  return Response.json({
    counts: { active: active.length, official: officialCount, model: active.length - officialCount },
    officialFeed: {
      status: lastRun[0]?.officialFeedStatus ?? "unknown",
      note:
        lastRun[0]?.officialFeedStatus === "ok"
          ? "Official advisories retrieved from public DMC / Department of Meteorology feeds."
          : (lastRun[0]?.notes ??
            "Official Sri Lankan advisory feeds could not be read from this deployment. Only model-derived screening is shown."),
      checkedAt: lastRun[0]?.startedAt ?? null,
    },
    alerts: active,
    history: historyRows,
  });
}
