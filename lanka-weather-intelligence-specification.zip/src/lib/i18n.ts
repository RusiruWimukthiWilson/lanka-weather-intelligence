export type Lang = "en" | "si" | "ta";

export const LANGS: { code: Lang; label: string; native: string }[] = [
  { code: "en", label: "English", native: "English" },
  { code: "si", label: "Sinhala", native: "සිංහල" },
  { code: "ta", label: "Tamil", native: "தமிழ்" },
];

type Dict = Record<string, [string, string, string]>;

const DICT: Dict = {
  brand: ["Lanka Weather Intelligence", "ලංකා කාලගුණ බුද්ධිය", "இலங்கை வானிலை நுண்ணறிவு"],
  tagline: ["Understand Your Weather. Protect Your Tomorrow.", "ඔබේ කාලගුණය තේරුම් ගන්න. හෙට ආරක්ෂා කරගන්න.", "உங்கள் வானிலையை புரிந்துகொள்க. நாளையை பாதுகாக்க."],
  nav_home: ["Home", "මුල් පිටුව", "முகப்பு"],
  nav_explore: ["Explore", "ගවේෂණය", "ஆய்வு"],
  nav_forecast: ["Forecast", "පුරෝකථනය", "முன்னறிவிப்பு"],
  nav_alerts: ["Alerts", "අනතුරු ඇඟවීම්", "எச்சரிக்கைகள்"],
  nav_assistant: ["AI Assistant", "AI සහායක", "AI உதவியாளர்"],
  nav_travel: ["Travel", "සංචාරය", "பயணம்"],
  nav_agriculture: ["Agriculture", "කෘෂිකර්මය", "வேளாண்மை"],
  nav_marine: ["Marine", "මුහුදු", "கடல்"],
  nav_community: ["Community", "ප්‍රජාව", "சமூகம்"],
  nav_profile: ["Profile", "පැතිකඩ", "சுயவிவரம்"],
  search_placeholder: ["Search any Sri Lankan city or district…", "ශ්‍රී ලංකාවේ නගරයක් හෝ දිස්ත්‍රික්කයක් සොයන්න…", "இலங்கையின் நகரம் அல்லது மாவட்டம் தேடுங்கள்…"],
  use_my_location: ["Use my location", "මගේ ස්ථානය භාවිතා කරන්න", "என் இடத்தை பயன்படுத்து"],
  feels_like: ["Feels like", "දැනෙන උෂ්ණත්වය", "உணரப்படும் வெப்பம்"],
  humidity: ["Humidity", "ආර්ද්‍රතාවය", "ஈரப்பதம்"],
  wind: ["Wind", "සුළඟ", "காற்று"],
  pressure: ["Pressure", "වායු පීඩනය", "காற்றழுத்தம்"],
  uv_index: ["UV index", "UV දර්ශකය", "UV குறியீடு"],
  visibility: ["Visibility", "දෘශ්‍යතාවය", "தெரிவுநிலை"],
  rain_chance: ["Rain chance", "වැසි ඉඩකඩ", "மழை வாய்ப்பு"],
  expected_rain: ["Expected rain", "අපේක්ෂිත වැසි", "எதிர்பார்க்கும் மழை"],
  sunrise: ["Sunrise", "හිරු නැගීම", "சூரிய உதயம்"],
  sunset: ["Sunset", "හිරු බැසීම", "சூரிய அஸ்தமனம்"],
  air_quality: ["Air quality", "වායු ගුණාත්මකභාවය", "காற்றின் தரம்"],
  hourly: ["Hourly", "පැය පාසා", "மணிதோறும்"],
  next_24h: ["Next 24 hours", "ඊළඟ පැය 24", "அடுத்த 24 மணி"],
  next_7_days: ["7-day forecast", "දින 7 පුරෝකථනය", "7 நாள் முன்னறிவிப்பு"],
  extended: ["Extended (14 days)", "දිගු කාලීන (දින 14)", "நீட்டிய (14 நாட்கள்)"],
  updated: ["Updated", "යාවත්කාලීන", "புதுப்பிக்கப்பட்டது"],
  source: ["Source", "මූලාශ්‍රය", "மூலம்"],
  stale_warning: ["Cached data — older than the refresh target", "නිරන්තර යාවත්කාලීන නොවූ දත්ත", "தற்காலிகச் சேமிப்பு தரவு"],
  official: ["Official", "නිල", "அதிகாரப்பூர்வ"],
  model: ["Model screening", "ආකෘති පරීක්ෂණය", "மாதிரி பரிசோதனை"],
  unverified: ["Unverified community report", "තහවුරු නොකළ ප්‍රජා වාර්තාව", "சரிபார்க்கப்படாத சமூக அறிக்கை"],
  loading: ["Loading live data…", "සජීවී දත්ත පූරණය වෙමින්…", "நேரடி தரவு ஏற்றப்படுகிறது…"],
  retry: ["Retry", "නැවත උත්සාහ කරන්න", "மீண்டும் முயற்சி"],
};

const IDX: Record<Lang, 0 | 1 | 2> = { en: 0, si: 1, ta: 2 };

export function t(lang: Lang, key: keyof typeof DICT | string): string {
  const entry = DICT[key];
  if (!entry) return String(key);
  return entry[IDX[lang]];
}
