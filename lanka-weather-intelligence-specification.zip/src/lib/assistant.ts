import { fetchWeatherBundle, fetchAirQuality, type WeatherBundle } from "@/lib/weather/openmeteo";
import { DISTRICTS, PLACES, nearestDistrict, type Place } from "@/lib/lk-geo";
import { describeCode, intensityFromMm, uvCategory, aqiBand, beaufortLabel, compassDirection } from "@/lib/weather/codes";
import { fmtTemp, fmtNum, fmtDay } from "@/lib/format";
import { listAlerts } from "@/lib/alerts-service";
import type { Lang } from "@/lib/i18n";

export type Citation = { label: string; source: string; detail: string };

export type AssistantAnswer = {
  answer: string;
  engine: string;
  citations: Citation[];
  locations: string[];
  intent: string;
  unverifiable: string[];
};

type Intent =
  | "rain"
  | "temperature"
  | "wind"
  | "marine"
  | "travel"
  | "agriculture"
  | "alerts"
  | "air"
  | "compare"
  | "explain"
  | "general";

function normalise(text: string) {
  return text.toLowerCase().replace(/[?!.]/g, " ").replace(/\s+/g, " ").trim();
}

function findPlaces(text: string): Place[] {
  const t = normalise(text);
  const found: { place: Place; index: number }[] = [];
  for (const p of PLACES) {
    const idx = t.indexOf(p.name.toLowerCase());
    if (idx >= 0) found.push({ place: p, index: idx });
  }
  for (const d of DISTRICTS) {
    const idx = t.indexOf(d.name.toLowerCase());
    if (idx >= 0) found.push({ place: { name: d.capital, district: d.name, province: d.province, lat: d.lat, lon: d.lon, kind: "city" }, index: idx });
  }
  const unique: { place: Place; index: number }[] = [];
  for (const f of found.sort((a, b) => a.index - b.index)) {
    if (!unique.some((u) => u.place.name === f.place.name)) unique.push(f);
  }
  return unique.slice(0, 3).map((u) => u.place);
}

function detectIntent(text: string): Intent {
  const t = normalise(text);
  if (/(compare| vs |versus|difference|සසඳ|ஒப்பிட)/.test(t) && findPlaces(text).length >= 2) return "compare";
  if (/(umbrella|rain|shower|ඉඳිකටු|වැසි|மழை|குடை)/.test(t)) return "rain";
  if (/(sea|marine|fish|boat|wave|මුහුද|ධීවර|கடல்|மீன்|அலை)/.test(t)) return "marine";
  if (/(travel|trip|journey|route|drive|bus|train|ගමන්|රථ|பயண|பஸ்|ரயில்)/.test(t)) return "travel";
  if (/(farm|crop|paddy|agri|irrigat|soil|ගොවි|කෘෂි|පාංශු|விவசாய|பயிர்|நீர்ப்பாசன)/.test(t)) return "agriculture";
  if (/(alert|warning|flood|landslide|lightning|thunder|cyclone|අනතුරු|අකුණු|ගංවතුර|නායයෑම|எச்சரி|வெள்ளம்|மின்னல்)/.test(t)) return "alerts";
  if (/(air|pollution|aqi|dust|haze|වායු|காற்று தரம்|மாசு)/.test(t)) return "air";
  if (/(wind|breeze|gust|සුළං|காற்று)/.test(t)) return "wind";
  if (/(explain|simple|why|පැහැදිලි|විස්තර|விளக்க|எளிமை)/.test(t)) return "explain";
  if (/(hot|cold|temperature|degree|උෂ්ණත්ව|රතු|සීතල|வெப்ப|குளிர)/.test(t)) return "temperature";
  return "general";
}

function timeWindow(text: string): { key: "now" | "today" | "tomorrow" | "week"; startHour?: number; endHour?: number; labelEn: string; labelSi: string; labelTa: string } {
  const t = normalise(text);
  if (/(tomorrow|හෙට|நாளை)/.test(t)) return { key: "tomorrow", labelEn: "tomorrow", labelSi: "හෙට", labelTa: "நாளை" };
  if (/(tonight|evening|රාත්‍රි|සවස|இரவு|மாலை)/.test(t)) return { key: "today", startHour: 17, endHour: 23, labelEn: "this evening", labelSi: "අද සවස", labelTa: "இன்று மாலை" };
  if (/(morning|උදේ|උදෑසන|காலை)/.test(t)) return { key: "today", startHour: 5, endHour: 12, labelEn: "this morning", labelSi: "අද උදෑසන", labelTa: "இன்று காலை" };
  if (/(afternoon|දහවල්|மத்தியானம்)/.test(t)) return { key: "today", startHour: 12, endHour: 17, labelEn: "this afternoon", labelSi: "අද දහවල්", labelTa: "இன்று பிற்பகல்" };
  if (/(week|දින 7|සති|வார)/.test(t)) return { key: "week", labelEn: "over the next 7 days", labelSi: "ඊළඟ දින 7 තුළ", labelTa: "அடுத்த 7 நாட்களில்" };
  return { key: "today", labelEn: "today", labelSi: "අද", labelTa: "இன்று" };
}

function windowRain(bundle: WeatherBundle, window: ReturnType<typeof timeWindow>, now = new Date()) {
  const hours = bundle.hourly.filter((h) => {
    const d = new Date(h.time);
    const diffH = (d.getTime() - now.getTime()) / 3600000;
    if (window.key === "now") return diffH >= 0 && diffH < 3;
    if (window.key === "today") {
      if (diffH < 0 || diffH > 24) return false;
      if (window.startHour === undefined) return true;
      return d.getHours() >= window.startHour && d.getHours() < (window.endHour ?? 24);
    }
    if (window.key === "tomorrow") return diffH >= 18 && diffH < 42;
    return diffH >= 0 && diffH < 168;
  });
  const total = hours.reduce((a, h) => a + (h.precipitation ?? 0), 0);
  const maxProb = hours.reduce((a, h) => Math.max(a, h.precipitationProbability ?? 0), 0);
  const firstRain = hours.find((h) => (h.precipitation ?? 0) >= 0.2);
  return { hours, total, maxProb, firstRain };
}

function locLabel(place: Place) {
  const d = DISTRICTS.find((x) => x.name === place.district);
  return `${place.name}${d ? ` (${d.name} District, ${d.province} Province)` : ""}`;
}

async function buildContext(place: Place) {
  const bundle = await fetchWeatherBundle({ name: place.name, lat: place.lat, lon: place.lon, district: place.district, province: place.province });
  const air = await fetchAirQuality(place.lat, place.lon);
  return { bundle, air };
}

/** Deterministic natural-language generator over live data. Never invents values. */
function compose(
  lang: Lang,
  intent: Intent,
  window: ReturnType<typeof timeWindow>,
  place: Place,
  ctx: { bundle: WeatherBundle; air: Awaited<ReturnType<typeof fetchAirQuality>> },
  rain: ReturnType<typeof windowRain>,
  extra?: { place: Place; ctx: { bundle: WeatherBundle }; rain: ReturnType<typeof windowRain> },
): { text: string; unverifiable: string[] } {
  const b = ctx.bundle;
  const cur = b.current;
  const unverifiable: string[] = [];
  const L = {
    en: {
      here: `In ${locLabel(place)}`,
      now: `Right now: ${describeCode(cur?.weatherCode ?? 3, cur?.isDay ?? true)}, ${fmtTemp(cur?.temperature)} (feels like ${fmtTemp(cur?.apparentTemperature)}), humidity ${fmtNum(cur?.humidity, 0, "%")}, wind ${fmtNum(cur?.windSpeed, 0, "km/h")} from ${compassDirection(cur?.windDirection)}.`,
      rainPlan: `Forecast precipitation ${window.labelEn}: about ${fmtNum(rain.total, 1, "mm")} with a peak hourly chance of ${fmtNum(rain.maxProb, 0, "%")}.`,
      noRain: `No meaningful rainfall is modelled ${window.labelEn} for this location.`,
      rainWhen: rain.firstRain ? `Rain is modelled to start around ${new Date(rain.firstRain.time).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })} local time at roughly ${intensityFromMm(rain.firstRain.precipitation ?? 0).label.toLowerCase()} intensity.` : "",
      umbrella: rain.total >= 1 || rain.maxProb >= 55 ? "So yes — carrying an umbrella or raincoat is a sensible precaution." : "An umbrella is probably not needed for this window.",
      source: `Source: ${b.provenance.provider} (${b.provenance.model}), retrieved ${new Date(b.provenance.fetchedAt).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })}. Forecasts are probabilistic model output, not guarantees.`,
      unavailable: `I could not verify conditions for ${locLabel(place)} because the weather service could not be reached. I will not guess.`,
    },
    si: {
      here: `${locLabel(place)} සඳහා`,
      now: `දැනට: ${describeCode(cur?.weatherCode ?? 3, cur?.isDay ?? true, "si")}, ${fmtTemp(cur?.temperature)} (දැනෙන ${fmtTemp(cur?.apparentTemperature)}), ආර්ද්‍රතාවය ${fmtNum(cur?.humidity, 0, "%")}, සුළං ${fmtNum(cur?.windSpeed, 0, "km/h")} ${compassDirection(cur?.windDirection)} දිශාවෙන්.`,
      rainPlan: `${window.labelSi} පුරෝකථනය කළ වර්ෂාපතනය ආසන්නව ${fmtNum(rain.total, 1, "mm")} වන අතර පැයක උපරිම වැසි ඉඩකඩ ${fmtNum(rain.maxProb, 0, "%")} වේ.`,
      noRain: `${window.labelSi} මෙම ප්‍රදේශයට සැලකිය යුතු වැසික් පුරෝකථනය කර නොමැත.`,
      rainWhen: rain.firstRain ? `වැසි ආරම්භ විය හැකි වෙලාව ${new Date(rain.firstRain.time).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })} පමණ වන අතර තීව්‍රතාවය ${intensityFromMm(rain.firstRain.precipitation ?? 0).si} ලෙස පුරෝකථනය වේ.` : "",
      umbrella: rain.total >= 1 || rain.maxProb >= 55 ? "එබැවින් කුඩයක් හෝ වැසි උපකරණයක් රැගෙන යාම සුදුසුය." : "මෙම කාලය සඳහා කුඩයක් අවශ්‍ය නොවිය හැකිය.",
      source: `මූලාශ්‍රය: ${b.provenance.provider} (${b.provenance.model}). මෙය පුරෝකථන ආකෘති දත්ත වන අතර සහතික කළ නොහැක.`,
      unavailable: `සේවාවට සම්බන්ධ විය නොහැකි නිසා ${locLabel(place)} සඳහා තොරතුරු තහවුරු කළ නොහැක. මම උපකල්පනය කරන්නේ නැත.`,
    },
    ta: {
      here: `${locLabel(place)} பற்றி`,
      now: `தற்போது: ${describeCode(cur?.weatherCode ?? 3, cur?.isDay ?? true, "ta")}, ${fmtTemp(cur?.temperature)} (உணரப்படும் ${fmtTemp(cur?.apparentTemperature)}), ஈரப்பதம் ${fmtNum(cur?.humidity, 0, "%")}, காற்று ${fmtNum(cur?.windSpeed, 0, "km/h")} ${compassDirection(cur?.windDirection)} திசையில்.`,
      rainPlan: `${window.labelTa} எதிர்பார்க்கப்படும் மழையளவு சுமார் ${fmtNum(rain.total, 1, "mm")}; அதிகபட்ச மணி வாய்ப்பு ${fmtNum(rain.maxProb, 0, "%")}.`,
      noRain: `${window.labelTa} இந்த இடத்திற்கு குறிப்பிடத்தக்க மழை எதிர்பார்க்கப்படவில்லை.`,
      rainWhen: rain.firstRain ? `மழை தோராயமாக ${new Date(rain.firstRain.time).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })} அளவில் தொடங்கலாம்; தீவிரம் ${intensityFromMm(rain.firstRain.precipitation ?? 0).ta}.` : "",
      umbrella: rain.total >= 1 || rain.maxProb >= 55 ? "எனவே குடை அல்லது மழை கவசம் எடுத்துச் செல்வது நல்லது." : "இந்த நேரத்திற்கு குடை தேவையில்லை.",
      source: `மூலம்: ${b.provenance.provider} (${b.provenance.model}). இது மாதிரி கணிப்பு; உறுதி அல்ல.`,
      unavailable: `சேவையை அணுக முடியாததால் ${locLabel(place)} தகவலை உறுதிப்படுத்த முடியவில்லை. நான் ஊகிக்கமாட்டேன்.`,
    },
  }[lang];

  if (!cur && b.hourly.length === 0) {
    return { text: L.unavailable, unverifiable: [locLabel(place)] };
  }

  const parts: string[] = [L.here];
  if (intent === "rain") {
    parts.push(L.now);
    parts.push(rain.total > 0.05 ? L.rainPlan : L.noRain);
    if (L.rainWhen) parts.push(L.rainWhen);
    parts.push(L.umbrella);
  } else if (intent === "temperature") {
    parts.push(L.now);
    const today = b.daily[0];
    if (today) parts.push(lang === "si" ? `අද උපරිම ${fmtTemp(today.tempMax)} / අවම ${fmtTemp(today.tempMin)}.` : lang === "ta" ? `இன்று அதிகபட்ச ${fmtTemp(today.tempMax)} / குறைந்தபட்ச ${fmtTemp(today.tempMin)}.` : `Today's range: ${fmtTemp(today.tempMax)} high, ${fmtTemp(today.tempMin)} low.`);
  } else if (intent === "wind") {
    const maxWind = b.hourly.filter((h) => (new Date(h.time).getTime() - Date.now()) / 3600000 >= 0).slice(0, 24).reduce((a, h) => Math.max(a, h.windSpeed ?? 0), 0);
    parts.push(L.now);
    parts.push(lang === "si" ? `ඊළඟ පැය 24 තුළ උපරිම සුළං වේගය ආසන්නව ${fmtNum(maxWind, 0, "km/h")} (${beaufortLabel(maxWind)}).` : lang === "ta" ? `அடுத்த 24 மணிநேரத்தில் அதிகபட்ச காற்று வேகம் சுமார் ${fmtNum(maxWind, 0, "km/h")} (${beaufortLabel(maxWind)}).` : `Peak modelled wind in the next 24 h is about ${fmtNum(maxWind, 0, "km/h")} (${beaufortLabel(maxWind)}).`);
  } else if (intent === "air") {
    const a = ctx.air;
    if (!a.available || a.europeanAqi === null) {
      unverifiable.push("air quality");
      parts.push(lang === "si" ? "වායු ගුණාත්මක දත්ත මෙම මොහොතේ ලබාගත නොහැකි විය." : lang === "ta" ? "காற்றின் தரத் தரவு இப்போது கிடைக்கவில்லை." : "Air-quality readings are not available for this point right now, so I cannot quote a value.");
    } else {
      const band = aqiBand(a.europeanAqi);
      parts.push(lang === "si" ? `යුරෝපීය AQI ${Math.round(a.europeanAqi)} — ${band.label}. PM2.5 ${fmtNum(a.pm2_5, 1, "µg/m³")}. ${band.advice}` : lang === "ta" ? `ஐரோப்பிய AQI ${Math.round(a.europeanAqi)} — ${band.label}. PM2.5 ${fmtNum(a.pm2_5, 1, "µg/m³")}. ${band.advice}` : `European AQI ${Math.round(a.europeanAqi)} (${band.label}); PM2.5 ${fmtNum(a.pm2_5, 1, "µg/m³")}. ${band.advice}`);
    }
  } else if (intent === "marine") {
    const wind = cur?.windSpeed ?? null;
    parts.push(lang === "si" ? `මුහුදු සඳහා මට තහවුරු කළ හැක්කේ වෙරළබඩ සුළං දත්ත පමණි: ${fmtNum(wind, 0, "km/h")} ${compassDirection(cur?.windDirection)}.` : lang === "ta" ? `கடலுக்கு நான் உறுதிப்படுத்தக்கூடியது கடலோர காற்று: ${fmtNum(wind, 0, "km/h")} ${compassDirection(cur?.windDirection)}.` : `For sea conditions I can confirm the coastal wind: ${fmtNum(wind, 0, "km/h")} from ${compassDirection(cur?.windDirection)}.`);
    if ((wind ?? 0) >= 40) parts.push(lang === "si" ? "මෙය කුඩා වාහනවලට අවුල් සහගත මුහුදු තත්ත්වයක් ඇති කරයි. නිල මුහුදු නිවේදනය බලන්න." : lang === "ta" ? "இது சிறிய படகுகளுக்கு முரண்பட்ட கடல் நிலையை ஏற்படுத்தும். அதிகாரப்பூர்வ கடல் எச்சரிக்கையை சரிபார்க்கவும்." : "That is at the level where sea state worsens for small craft. Please check the official sea bulletin before sailing.");
    unverifiable.push("observed wave height (requires the marine wave model or an official bulletin)");
  } else if (intent === "travel") {
    const vis = rain.hours.slice(0, 12);
    const wetHours = vis.filter((h) => (h.precipitation ?? 0) >= 0.2).length;
    parts.push(L.now);
    parts.push(lang === "si" ? `ඊළඟ පැය 12 තුළ පැය ${wetHours} කදී වැසි ඇතිවිය හැකිය.` : lang === "ta" ? `அடுத்த 12 மணிநேரத்தில் ${wetHours} மணி நேரம் மழை இருக்கலாம்.` : `Rain is modelled in ${wetHours} of the next 12 hours.`);
    const dry = vis.find((h) => (h.precipitation ?? 0) < 0.2 && (h.precipitationProbability ?? 0) < 40);
    parts.push(dry ? (lang === "si" ? `වඩාත් සුදුසු කවුළුව ${new Date(dry.time).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })} අවට පෙනේ.` : lang === "ta" ? `சிறந்த பயண நேரம் ${new Date(dry.time).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })} அளவில் தெரிகிறது.` : `The calmest travel window appears around ${new Date(dry.time).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })}.`) : lang === "si" ? "විනිවිදක් වැසි නොමැති කවුළුවක් මෙම පැය 12 තුළ පෙනෙන්නේ නැත." : lang === "ta" ? "இந்த 12 மணிநேரத்தில் தெளிவான நேரம் தெரியவில்லை." : "No clearly dry window appears in the next 12 hours.");
  } else if (intent === "agriculture") {
    const next48 = bundleSlice(b, 48);
    const total = next48.reduce((a, h) => a + (h.precipitation ?? 0), 0);
    const district = nearestDistrict(place.lat, place.lon);
    parts.push(lang === "si" ? `ඊළඟ පැය 48 සඳහා පුරෝකථනය කළ වර්ෂාපතනය ${fmtNum(total, 1, "mm")} වේ.` : lang === "ta" ? `அடுத்த 48 மணிநேர எதிர்பார்க்கப்படும் மழை ${fmtNum(total, 1, "mm")}.` : `Modelled rainfall for the next 48 hours is about ${fmtNum(total, 1, "mm")}.`);
    parts.push(lang === "si" ? `මෙම ප්‍රදේශය ${district.terrain === "dry-plain" ? "වියළි තැනිතලා" : district.terrain === "highland" ? "කඳුකරය" : "තෙත් භූමි"} ලෙස වර්ගීකරණය කර ඇත.` : lang === "ta" ? `இந்த பகுதி ${district.terrain === "dry-plain" ? "வறண்ட சமவெளி" : district.terrain === "highland" ? "மலைப்பகுதி" : "ஈரநிலம்"} ஆக வகைப்படுத்தப்பட்டுள்ளது.` : `This area is classified as ${district.terrain.replace("-", " ")} terrain, which shapes how much of that rain is useful for irrigation.`);
    if (total < 5) parts.push(lang === "si" ? "මෙම කවුළුව තුළ පුරෝකථනය කළ වැසි අඩු බැවින් ජල සැලසුම් අවශ්‍ය විය හැකිය." : lang === "ta" ? "இந்த கால இடைவெளியில் மழை குறைவாக உள்ளதால் நீர்ப்பாசன திட்டமிடல் தேவைப்படலாம்." : "With little modelled rain in this window, irrigation scheduling may be needed.");
    unverifiable.push("soil moisture (not available from an open forecast model)");
  } else if (intent === "alerts") {
    parts.push(L.now);
    parts.push(lang === "si" ? "මම පවතින අනතුරු ඇඟවීම් පරීක්ෂා කරමි — පහත Alerts පිටුවෙන් බලන්න." : lang === "ta" ? "தற்போதைய எச்சரிக்கைகளை சரிபார்க்கிறேன் — Alerts பக்கத்தை பாருங்கள்." : "I have checked the active alert records — please read them in the Alerts section, where official and model-derived items are labelled separately.");
  } else if (intent === "compare" && extra) {
    const mine = rain.total;
    const other = extra.rain.total;
    parts.push(lang === "si" ? `${place.name}: ${fmtNum(mine, 1, "mm")} / ${extra.place.name}: ${fmtNum(other, 1, "mm")} (${window.labelEn}).` : lang === "ta" ? `${place.name}: ${fmtNum(mine, 1, "mm")} / ${extra.place.name}: ${fmtNum(other, 1, "mm")} (${window.labelEn}).` : `${place.name} ${fmtNum(mine, 1, "mm")} versus ${extra.place.name} ${fmtNum(other, 1, "mm")} ${window.labelEn}.`);
    const a = place.name;
    const bName = extra.place.name;
    parts.push(
      lang === "si"
        ? `${mine > other ? a : bName} සඳහා වැඩි වර්ෂාපතනයක් පුරෝකථනය කර ඇත; උෂ්ණත්ව ${fmtTemp(place.lat ? extra.ctx.bundle.current?.temperature : null)}.`
        : lang === "ta"
          ? `${mine > other ? a : bName} அதிக மழை எதிர்பார்க்கப்படுகிறது; வெப்பநிலை ${fmtTemp(extra.ctx.bundle.current?.temperature)}.`
          : `${mine > other ? a : bName} has the higher modelled rainfall; current temperature there is ${fmtTemp(extra.ctx.bundle.current?.temperature)}.`,
    );
  } else {
    parts.push(L.now);
    parts.push(rain.total > 0.05 ? L.rainPlan : L.noRain);
  }

  parts.push(L.source);
  return { text: parts.filter(Boolean).join(" "), unverifiable };
}

function bundleSlice(b: WeatherBundle, hours: number) {
  const now = Date.now();
  return b.hourly.filter((h) => {
    const diff = (new Date(h.time).getTime() - now) / 3600000;
    return diff >= 0 && diff < hours;
  });
}

export async function answerQuestion(input: { question: string; lang?: Lang; location?: { name: string; lat: number; lon: number; district?: string } }): Promise<AssistantAnswer> {
  const lang: Lang = input.lang ?? "en";
  const question = input.question.trim();
  const intent = detectIntent(question);
  const mentioned = findPlaces(question);
  const window = timeWindow(question);
  const citations: Citation[] = [];
  const unverifiable: string[] = [];

  if (!question) {
    return { answer: "Please ask a weather question about a Sri Lankan location.", engine: "lwi-rules", citations, locations: [], intent, unverifiable };
  }

  try {
    const primary: Place = mentioned[0] ?? {
      name: input.location?.name ?? "Colombo",
      district: input.location?.district ?? nearestDistrict(input.location?.lat ?? 6.9271, input.location?.lon ?? 79.8612).name,
      province: "Western",
      lat: input.location?.lat ?? 6.9271,
      lon: input.location?.lon ?? 79.8612,
      kind: "city",
    };

    const ctx = await buildContext(primary);
    const rain = windowRain(ctx.bundle, window);
    citations.push({
      label: `${primary.name} hourly forecast`,
      source: `${ctx.bundle.provenance.provider} — ${ctx.bundle.provenance.model}`,
      detail: `Retrieved ${new Date(ctx.bundle.provenance.fetchedAt).toUTCString()}`,
    });
    if (ctx.air.available) {
      citations.push({ label: `${primary.name} air quality`, source: "Open-Meteo CAMS air-quality", detail: `European AQI ${Math.round(ctx.air.europeanAqi ?? 0)}` });
    }

    let extra;
    if (intent === "compare" && mentioned[1]) {
      const otherCtx = await buildContext(mentioned[1]);
      extra = { place: mentioned[1], ctx: otherCtx, rain: windowRain(otherCtx.bundle, window) };
      citations.push({ label: `${mentioned[1].name} hourly forecast`, source: `${otherCtx.bundle.provenance.provider} — ${otherCtx.bundle.provenance.model}`, detail: `Retrieved ${new Date(otherCtx.bundle.provenance.fetchedAt).toUTCString()}` });
    }

    if (intent === "alerts") {
      const rows = await listAlerts({ district: primary.district });
      const official = rows.filter((r) => r.origin === "official");
      const model = rows.filter((r) => r.origin === "model");
      const alertLine =
        lang === "si"
          ? `${primary.district} දිස්ත්‍රික්කයට සම්බන්ධ සක්‍රීය වාර්තා ${rows.length} ක් ඇත (නිල ${official.length}, ආකෘති පරීක්ෂණ ${model.length}).`
          : lang === "ta"
            ? `${primary.district} மாவட்டத்திற்கு ${rows.length} செயலில் பதிவுகள் உள்ளன (அதிகாரப்பூர்வ ${official.length}, மாதிரி ${model.length}).`
            : `${rows.length} active record(s) match ${primary.district} District — ${official.length} official and ${model.length} model-derived screening.`;
      const summary = rows
        .slice(0, 3)
        .map((r) => `• [${r.origin === "official" ? "OFFICIAL" : "MODEL"}] ${r.title} — ${r.summary.slice(0, 160)}`)
        .join("\n");
      const composed = compose(lang, "general", window, primary, ctx, rain);
      return {
        answer: `${alertLine}${summary ? `\n\n${summary}` : ""}\n\n${composed.text}`,
        engine: "lwi-rules+alerts",
        citations: [
          ...citations,
          ...(rows.length ? [{ label: "Active alert records", source: official.length ? "DMC / Dept. of Meteorology feeds + LWI model screening" : "LWI model screening (Open-Meteo)", detail: `${rows.length} record(s)` }] : []),
        ],
        locations: [primary.name],
        intent,
        unverifiable,
      };
    }

    let result = compose(lang, intent, window, primary, ctx, rain, extra);
    let engine = "lwi-rules";

    // Optional LLM polish: only if a key is configured, and only using the
    // verified numbers gathered above (the model is told it may not invent data).
    const key = process.env.OPENAI_API_KEY;
    if (key) {
      try {
        const facts = {
          location: locLabel(primary),
          window: window.labelEn,
          current: ctx.bundle.current,
          windowRainMm: Math.round(rain.total * 100) / 100,
          windowMaxChancePct: rain.maxProb,
          firstRainTime: rain.firstRain?.time ?? null,
          daily: ctx.bundle.daily.slice(0, 3),
          airQuality: ctx.air.available ? { europeanAqi: ctx.air.europeanAqi, pm2_5: ctx.air.pm2_5 } : null,
          comparedWith: extra ? { location: extra.place.name, rainMm: Math.round(extra.rain.total * 100) / 100, current: extra.ctx.bundle.current } : null,
        };
        const res = await fetch("https://api.openai.com/v1/chat/completions", {
          method: "POST",
          headers: { "content-type": "application/json", authorization: `Bearer ${key}` },
          body: JSON.stringify({
            model: "gpt-4o-mini",
            temperature: 0.2,
            messages: [
              {
                role: "system",
                content:
                  "You are the Lanka Weather Intelligence assistant. Answer ONLY using the JSON facts supplied. Never invent readings. State that figures are model forecasts. Reply in the requested language, maximum 130 words.",
              },
              { role: "user", content: `Language: ${lang}. Question: ${question}\nFacts: ${JSON.stringify(facts)}` },
            ],
          }),
        });
        if (res.ok) {
          const data = (await res.json()) as { choices?: { message?: { content?: string } }[] };
          const text = data.choices?.[0]?.message?.content?.trim();
          if (text) {
            result = { text: `${text}\n\nSource: ${ctx.bundle.provenance.provider} (${ctx.bundle.provenance.model}) — model forecast data.`, unverifiable };
            engine = "lwi-rules+llm";
          }
        }
      } catch {
        // keep the deterministic answer
      }
    }

    return { answer: result.text, engine, citations, locations: [primary.name, ...(extra ? [extra.place.name] : [])], intent, unverifiable: result.unverifiable };
  } catch (err) {
    return {
      answer:
        lang === "si"
          ? "මට දත්ත සේවාවෙන් ලබා ගත නොහැකි වූ නිසා මෙම ප්‍රශ්නයට පිළිතුරු තහවුරු කර කිව නොහැක. මම උපකල්පනය නොකරමි."
          : lang === "ta"
            ? "தரவுச் சேவையை அணுக முடியாததால் இதற்கு உறுதியான பதில் தர முடியவில்லை. நான் ஊகிக்கவில்லை."
            : `I could not verify this because the weather service is unreachable right now (${err instanceof Error ? err.message : "unknown error"}). I will not guess or invent conditions.`,
      engine: "lwi-rules",
      citations,
      locations: [],
      intent,
      unverifiable: ["upstream weather service"],
    };
  }
}

export const ASSISTANT_SUGGESTIONS: Record<Lang, string[]> = {
  en: [
    "Will it rain in Colombo tomorrow?",
    "Is it a good time to travel to Kandy?",
    "What is the weather like in Galle?",
    "Should I carry an umbrella in Negombo this evening?",
    "Compare tomorrow's weather in Colombo and Jaffna.",
    "Is there a lightning or flood warning near Ratnapura?",
  ],
  si: [
    "හෙට කොළඹ වැසි ඇතිවේද?",
    "මහනුවර ගමන් කිරීමට සුදුසු වේලාවක්ද?",
    "ගාල්ලේ කාලගුණය කෙසේ ඇත?",
    "අද සවස මීගමුවාවට කුඩයක් අවශ්‍යද?",
    "කොළඹ සහ යාපනය හෙට සසඳන්න.",
    "රත්නපුරයට අකුණු හෝ ගංවතුර අනතුරු ඇඟවීම් ඇත්ද?",
  ],
  ta: [
    "நாளை கொழும்பில் மழை வருமா?",
    "கண்டி பயணத்திற்கு நல்ல நேரமா?",
    "காலியில் வானிலை எப்படி உள்ளது?",
    "இன்று மாலை நீகொம்போவுக்கு குடை தேவையா?",
    "கொழும்பு மற்றும் யாழ்ப்பாணம் நாளை ஒப்பிடுக.",
    "இரத்தினபுரிக்கு மின்னல் அல்லது வெள்ள எச்சரிக்கை உள்ளதா?",
  ],
};

export function todayLabel(lang: Lang) {
  return fmtDay(new Date(), "long");
}
