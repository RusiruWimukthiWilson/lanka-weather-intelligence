export type ConditionGroup =
  | "clear"
  | "mainly-clear"
  | "partly-cloudy"
  | "cloudy"
  | "fog"
  | "drizzle"
  | "rain"
  | "freezing"
  | "snow"
  | "showers"
  | "thunderstorm";

export type CodeInfo = {
  code: number;
  group: ConditionGroup;
  en: string;
  si: string;
  ta: string;
  night?: { en: string; si: string; ta: string };
};

export const WMO_CODES: Record<number, CodeInfo> = {
  0: { code: 0, group: "clear", en: "Clear sky", si: "පැහැදිලි අහස", ta: "தெளிவான வானம்", night: { en: "Clear night", si: "පැහැදිලි රාත්‍රිය", ta: "தெளிவான இரவு" } },
  1: { code: 1, group: "mainly-clear", en: "Mainly clear", si: "බොහෝ දුරට පැහැදිලි", ta: "பெரும்பாலும் தெளிவு" },
  2: { code: 2, group: "partly-cloudy", en: "Partly cloudy", si: "අර්ධ වශයෙන් වලාකුළු", ta: "பகுதியளவு மேகமூட்டம்" },
  3: { code: 3, group: "cloudy", en: "Overcast", si: "වලාකුළු සහිත", ta: "மேகமூட்டம்" },
  45: { code: 45, group: "fog", en: "Fog", si: "මීදුම", ta: "மூட்டம்" },
  48: { code: 48, group: "fog", en: "Depositing rime fog", si: "ගිම්සිරි මීදුම", ta: "உறை மூட்டம்" },
  51: { code: 51, group: "drizzle", en: "Light drizzle", si: "සැහැල්ලු ඉණිමැසි වැසි", ta: "லேசான துளிமழை" },
  53: { code: 53, group: "drizzle", en: "Moderate drizzle", si: "මධ්‍යම ඉණිමැසි වැසි", ta: "மிதமான துளிமழை" },
  55: { code: 55, group: "drizzle", en: "Dense drizzle", si: "ඝන ඉණිමැසි වැසි", ta: "அடர்ந்த துளிமழை" },
  56: { code: 56, group: "freezing", en: "Light freezing drizzle", si: "සැහැල්ලු ශීතල ඉණිමැසි වැසි", ta: "லேசான உறை துளிமழை" },
  57: { code: 57, group: "freezing", en: "Dense freezing drizzle", si: "ඝන ශීතල ඉණිමැසි වැසි", ta: "அடர்ந்த உறை துளிமழை" },
  61: { code: 61, group: "rain", en: "Slight rain", si: "සැහැල්ලු වැසි", ta: "லேசான மழை" },
  63: { code: 63, group: "rain", en: "Moderate rain", si: "මධ්‍යම වැසි", ta: "மிதமான மழை" },
  65: { code: 65, group: "rain", en: "Heavy rain", si: "බරපතල වැසි", ta: "கனமழை" },
  66: { code: 66, group: "freezing", en: "Light freezing rain", si: "සැහැල්ලු ශීතල වැසි", ta: "லேசான உறை மழை" },
  67: { code: 67, group: "freezing", en: "Heavy freezing rain", si: "බරපතල ශීතල වැසි", ta: "கன உறை மழை" },
  71: { code: 71, group: "snow", en: "Slight snowfall", si: "සැහැල්ලු හිම", ta: "லேசான பனி" },
  73: { code: 73, group: "snow", en: "Moderate snowfall", si: "මධ්‍යම හිම", ta: "மிதமான பனி" },
  75: { code: 75, group: "snow", en: "Heavy snowfall", si: "බරපතල හිම", ta: "கன பனி" },
  77: { code: 77, group: "snow", en: "Snow grains", si: "හිම ඇට", ta: "பனித் துகள்" },
  80: { code: 80, group: "showers", en: "Slight rain showers", si: "සැහැල්ලු වැසි පහර්", ta: "லேசான மழைப்பொழிவு" },
  81: { code: 81, group: "showers", en: "Moderate rain showers", si: "මධ්‍යම වැසි පහර්", ta: "மிதமான மழைப்பொழிவு" },
  82: { code: 82, group: "showers", en: "Violent rain showers", si: "දරුණු වැසි පහර්", ta: "வன்மழைப்பொழிவு" },
  85: { code: 85, group: "snow", en: "Slight snow showers", si: "සැහැල්ලු හිම පහර්", ta: "லேசான பனிப்பொழிவு" },
  86: { code: 86, group: "snow", en: "Heavy snow showers", si: "බරපතල හිම පහර්", ta: "கன பனிப்பொழிவு" },
  95: { code: 95, group: "thunderstorm", en: "Thunderstorm", si: "අකුණු සැරසිලි සහිත වැසි", ta: "இடி மின்னல் மழை" },
  96: { code: 96, group: "thunderstorm", en: "Thunderstorm with slight hail", si: "සැහැල්ලු අයිස් වැසි සහිත අකුණු", ta: "ஆலிவழி இடியுடன்" },
  99: { code: 99, group: "thunderstorm", en: "Thunderstorm with heavy hail", si: "බරපතල අයිස් වැසි සහිත අකුණු", ta: "கன ஆலிவழி இடியுடன்" },
};

export function describeCode(code: number, isDay = true, lang: "en" | "si" | "ta" = "en"): string {
  const info = WMO_CODES[code] ?? WMO_CODES[3];
  if (!isDay && info.night) return info.night[lang];
  return info[lang];
}

export function groupOf(code: number): ConditionGroup {
  return (WMO_CODES[code] ?? WMO_CODES[3]).group;
}

export const UV_CATEGORIES = [
  { max: 2, label: "Low", si: "අඩු", ta: "குறைந்த", color: "#22c55e", advice: "No protection needed for most people." },
  { max: 5, label: "Moderate", si: "මධ්‍යම", ta: "மிதமான", color: "#eab308", advice: "Seek shade around midday; use sunscreen." },
  { max: 7, label: "High", si: "ඉහළ", ta: "உயர்ந்த", color: "#f97316", advice: "Cover up, wear a hat and SPF 30+ between 10am–4pm." },
  { max: 10, label: "Very high", si: "ඉතා ඉහළ", ta: "மிக உயர்ந்த", color: "#ef4444", advice: "Minimise midday sun exposure; protection essential." },
  { max: 99, label: "Extreme", si: "අති ඉහළ", ta: "மிக அதிக", color: "#a855f7", advice: "Avoid direct sun between 10am–4pm." },
];

export function uvCategory(uv: number | null | undefined) {
  const value = typeof uv === "number" && Number.isFinite(uv) ? uv : 0;
  return UV_CATEGORIES.find((c) => value <= c.max) ?? UV_CATEGORIES[UV_CATEGORIES.length - 1];
}

export const AQI_BANDS = [
  { max: 20, label: "Good", color: "#22c55e", advice: "Air quality is satisfactory." },
  { max: 40, label: "Fair", color: "#84cc16", advice: "Acceptable for almost everyone." },
  { max: 60, label: "Moderate", color: "#eab308", advice: "Sensitive groups should limit long outdoor exertion." },
  { max: 80, label: "Poor", color: "#f97316", advice: "Reduce prolonged outdoor activity." },
  { max: 100, label: "Very poor", color: "#ef4444", advice: "Avoid outdoor exertion; keep windows closed." },
  { max: 1000, label: "Extremely poor", color: "#a855f7", advice: "Stay indoors if possible." },
];

export function aqiBand(aqi: number | null | undefined) {
  const value = typeof aqi === "number" && Number.isFinite(aqi) ? aqi : 0;
  return AQI_BANDS.find((b) => value <= b.max) ?? AQI_BANDS[AQI_BANDS.length - 1];
}

export function beaufortLabel(kmh: number): string {
  if (kmh < 1) return "Calm";
  if (kmh < 12) return "Light breeze";
  if (kmh < 20) return "Gentle breeze";
  if (kmh < 29) return "Moderate breeze";
  if (kmh < 39) return "Fresh breeze";
  if (kmh < 50) return "Strong breeze";
  if (kmh < 62) return "Near gale";
  if (kmh < 75) return "Gale";
  if (kmh < 89) return "Strong gale";
  if (kmh < 103) return "Storm";
  return "Violent storm";
}

export function compassDirection(deg: number | null | undefined): string {
  if (typeof deg !== "number" || !Number.isFinite(deg)) return "—";
  const dirs = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"];
  return dirs[Math.round((((deg % 360) + 360) % 360) / 22.5) % 16];
}

export function intensityFromMm(mm: number): { label: string; si: string; ta: string } {
  if (mm <= 0) return { label: "No rain", si: "වැසි නැත", ta: "மழை இல்லை" };
  if (mm < 1) return { label: "Very light", si: "ඉතා සැහැල්ලු", ta: "மிக லேசான" };
  if (mm < 2.5) return { label: "Light", si: "සැහැල්ලු", ta: "லேசான" };
  if (mm < 7.6) return { label: "Moderate", si: "මධ්‍යම", ta: "மிதமான" };
  if (mm < 15) return { label: "Heavy", si: "බර", ta: "கனமான" };
  if (mm < 30) return { label: "Very heavy", si: "ඉතා බර", ta: "மிக கனமான" };
  return { label: "Extreme", si: "අති බර", ta: "மிக அதிக" };
}
