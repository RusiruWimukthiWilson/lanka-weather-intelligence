/**
 * Open-Meteo provider layer.
 *
 * All numbers returned by this module come directly from the Open-Meteo API
 * (forecast / air-quality / marine endpoints). Nothing is generated or
 * interpolated into fake readings. Every response carries provenance metadata
 * so the UI can show the source, model, fetch time and staleness.
 */

export type Provenance = {
  provider: string;
  model: string;
  fetchedAt: string;
  ageSeconds: number;
  stale: boolean;
  ttlSeconds: number;
  attribution: string;
  degraded?: string;
};

export type CurrentWeather = {
  time: string;
  temperature: number;
  apparentTemperature: number;
  humidity: number | null;
  pressure: number | null;
  windSpeed: number | null;
  windDirection: number | null;
  windGust: number | null;
  precipitation: number | null;
  cloudCover: number | null;
  weatherCode: number;
  isDay: boolean;
  dewPoint: number | null;
};

export type HourlyPoint = {
  time: string;
  temperature: number | null;
  apparentTemperature: number | null;
  precipitationProbability: number | null;
  precipitation: number | null;
  weatherCode: number | null;
  windSpeed: number | null;
  windDirection: number | null;
  windGust: number | null;
  humidity: number | null;
  cloudCover: number | null;
  uvIndex: number | null;
  cape: number | null;
  visibility: number | null;
  isDay: boolean;
};

export type DailyPoint = {
  date: string;
  weatherCode: number | null;
  tempMax: number | null;
  tempMin: number | null;
  precipitationSum: number | null;
  precipitationProbabilityMax: number | null;
  precipitationHours: number | null;
  windSpeedMax: number | null;
  windGustsMax: number | null;
  windDirectionDominant: number | null;
  uvIndexMax: number | null;
  sunrise: string | null;
  sunset: string | null;
  daylightSeconds: number | null;
};

export type WeatherBundle = {
  location: { name: string; lat: number; lon: number; district: string; province: string; elevation: number | null; timezone: string };
  current: CurrentWeather | null;
  hourly: HourlyPoint[];
  daily: DailyPoint[];
  provenance: Provenance;
  error?: string;
};

const FORECAST_BASE = "https://api.open-meteo.com/v1/forecast";
const AIR_BASE = "https://air-quality-api.open-meteo.com/v1/air-quality";
const MARINE_BASE = "https://marine-api.open-meteo.com/v1/marine";
const ATTRIBUTION = "Data: Open-Meteo (CC BY 4.0) — open-meteo.com";

type CacheEntry = { value: unknown; at: number; ttl: number };
const globalCache = globalThis as typeof globalThis & { __lwiCache?: Map<string, CacheEntry> };
const cache: Map<string, CacheEntry> = (globalCache.__lwiCache ??= new Map());

export function cacheGet<T>(key: string): { value: T; at: number; ttl: number } | null {
  const hit = cache.get(key);
  if (!hit) return null;
  const age = (Date.now() - hit.at) / 1000;
  if (age > hit.ttl * 6) {
    cache.delete(key);
    return null;
  }
  return hit as { value: T; at: number; ttl: number };
}

export function cacheSet(key: string, value: unknown, ttl: number) {
  cache.set(key, { value, at: Date.now(), ttl });
}

function num(v: unknown): number | null {
  return typeof v === "number" && Number.isFinite(v) ? v : null;
}

async function fetchJson<T>(url: string, timeoutMs = 12000): Promise<T> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { signal: controller.signal, cache: "no-store", headers: { accept: "application/json" } });
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      throw new Error(`Upstream ${res.status}: ${text.slice(0, 180)}`);
    }
    return (await res.json()) as T;
  } finally {
    clearTimeout(timer);
  }
}

function provenance(model: string, at: number, ttl: number, degraded?: string): Provenance {
  const ageSeconds = Math.round((Date.now() - at) / 1000);
  return {
    provider: "Open-Meteo",
    model,
    fetchedAt: new Date(at).toISOString(),
    ageSeconds,
    stale: ageSeconds > ttl,
    ttlSeconds: ttl,
    attribution: ATTRIBUTION,
    ...(degraded ? { degraded } : {}),
  };
}

const HOURLY_VARS = [
  "temperature_2m",
  "apparent_temperature",
  "precipitation_probability",
  "precipitation",
  "weather_code",
  "wind_speed_10m",
  "wind_direction_10m",
  "wind_gusts_10m",
  "relative_humidity_2m",
  "cloud_cover",
  "uv_index",
  "cape",
  "visibility",
  "is_day",
].join(",");

const DAILY_VARS = [
  "weather_code",
  "temperature_2m_max",
  "temperature_2m_min",
  "precipitation_sum",
  "precipitation_probability_max",
  "precipitation_hours",
  "wind_speed_10m_max",
  "wind_gusts_10m_max",
  "wind_direction_10m_dominant",
  "uv_index_max",
  "sunrise",
  "sunset",
  "daylight_duration",
].join(",");

type RawForecast = {
  latitude?: number;
  longitude?: number;
  elevation?: number;
  timezone?: string;
  current?: Record<string, number | string>;
  hourly?: Record<string, (number | string | null)[]>;
  daily?: Record<string, (number | string | null)[]>;
  reason?: string;
  error?: boolean;
};

export type LocationDescriptor = {
  name: string;
  lat: number;
  lon: number;
  district?: string;
  province?: string;
};

export async function fetchWeatherBundle(
  loc: LocationDescriptor,
  opts: { forecastDays?: number; pastDays?: number } = {},
): Promise<WeatherBundle> {
  const forecastDays = opts.forecastDays ?? 14;
  const pastDays = opts.pastDays ?? 1;
  const url =
    `${FORECAST_BASE}?latitude=${loc.lat.toFixed(4)}&longitude=${loc.lon.toFixed(4)}` +
    `&current=temperature_2m,apparent_temperature,relative_humidity_2m,is_day,precipitation,weather_code,cloud_cover,pressure_msl,surface_pressure,wind_speed_10m,wind_direction_10m,wind_gusts_10m,dew_point_2m` +
    `&hourly=${HOURLY_VARS}&daily=${DAILY_VARS}&timezone=Asia%2FColombo&past_days=${pastDays}&forecast_days=${forecastDays}&wind_speed_unit=kmh`;

  const key = `bundle:${loc.lat.toFixed(3)}:${loc.lon.toFixed(3)}:${forecastDays}:${pastDays}`;
  const cached = cacheGet<WeatherBundle>(key);
  if (cached) {
    return { ...cached.value, provenance: provenance(cached.value.provenance.model, cached.at, cached.ttl, "Served from cache") };
  }

  const started = Date.now();
  try {
    const raw = await fetchJson<RawForecast>(url);
    if (raw.error) throw new Error(raw.reason ?? "Upstream rejected the request");
    cacheSet(key, raw, 600);
    recordIntegration("open-meteo-forecast", FORECAST_BASE, "forecast", "ok", Date.now() - started, null);
    return {
      location: {
        name: loc.name,
        lat: num(raw.latitude) ?? loc.lat,
        lon: num(raw.longitude) ?? loc.lon,
        district: loc.district ?? "",
        province: loc.province ?? "",
        elevation: num(raw.elevation),
        timezone: raw.timezone ?? "Asia/Colombo",
      },
      current: mapCurrent(raw.current),
      hourly: mapHourly(raw.hourly),
      daily: mapDaily(raw.daily),
      provenance: provenance("Best-match NWP blend (ICON, GFS, ECMWF IFS via Open-Meteo)", Date.now(), 600),
    };
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown upstream error";
    recordIntegration("open-meteo-forecast", FORECAST_BASE, "forecast", "down", Date.now() - started, message);
    const older = cacheGet<RawForecast>(key);
    if (older) {
      const raw = older.value;
      return {
        location: {
          name: loc.name,
          lat: loc.lat,
          lon: loc.lon,
          district: loc.district ?? "",
          province: loc.province ?? "",
          elevation: num(raw.elevation),
          timezone: raw.timezone ?? "Asia/Colombo",
        },
        current: mapCurrent(raw.current),
        hourly: mapHourly(raw.hourly),
        daily: mapDaily(raw.daily),
        provenance: provenance("Best-match NWP blend (cached)", older.at, older.ttl, `Live fetch failed (${message}). Showing last successfully retrieved data.`),
      };
    }
    throw new Error(message);
  }
}

function mapCurrent(c: Record<string, number | string> | undefined): CurrentWeather | null {
  if (!c) return null;
  return {
    time: String(c.time ?? ""),
    temperature: num(c.temperature_2m) ?? 0,
    apparentTemperature: num(c.apparent_temperature) ?? 0,
    humidity: num(c.relative_humidity_2m),
    pressure: num(c.pressure_msl) ?? num(c.surface_pressure),
    windSpeed: num(c.wind_speed_10m),
    windDirection: num(c.wind_direction_10m),
    windGust: num(c.wind_gusts_10m),
    precipitation: num(c.precipitation),
    cloudCover: num(c.cloud_cover),
    weatherCode: num(c.weather_code) ?? 3,
    isDay: num(c.is_day) === 1,
    dewPoint: num(c.dew_point_2m),
  };
}

function str(v: unknown): string | null {
  return typeof v === "string" ? v : null;
}

function mapHourly(h: Record<string, (number | string | null)[]> | undefined): HourlyPoint[] {
  if (!h?.time) return [];
  const times = h.time.map((t) => String(t));
  const nowMs = Date.now();
  const out: HourlyPoint[] = [];
  for (let i = 0; i < times.length; i += 1) {
    // Include the previous 24h plus the next 14 days; drop the deep past.
    const ts = new Date(times[i]).getTime();
    if (Number.isFinite(ts) && nowMs - ts > 26 * 3600 * 1000) continue;
    out.push({
      time: times[i],
      temperature: num(h.temperature_2m?.[i]),
      apparentTemperature: num(h.apparent_temperature?.[i]),
      precipitationProbability: num(h.precipitation_probability?.[i]),
      precipitation: num(h.precipitation?.[i]),
      weatherCode: num(h.weather_code?.[i]),
      windSpeed: num(h.wind_speed_10m?.[i]),
      windDirection: num(h.wind_direction_10m?.[i]),
      windGust: num(h.wind_gusts_10m?.[i]),
      humidity: num(h.relative_humidity_2m?.[i]),
      cloudCover: num(h.cloud_cover?.[i]),
      uvIndex: num(h.uv_index?.[i]),
      cape: num(h.cape?.[i]),
      visibility: num(h.visibility?.[i]),
      isDay: num(h.is_day?.[i]) === 1,
    });
  }
  return out;
}

function mapDaily(d: Record<string, (number | string | null)[]> | undefined): DailyPoint[] {
  if (!d?.time) return [];
  return d.time.map((t, i) => ({
    date: String(t),
    weatherCode: num(d.weather_code?.[i]),
    tempMax: num(d.temperature_2m_max?.[i]),
    tempMin: num(d.temperature_2m_min?.[i]),
    precipitationSum: num(d.precipitation_sum?.[i]),
    precipitationProbabilityMax: num(d.precipitation_probability_max?.[i]),
    precipitationHours: num(d.precipitation_hours?.[i]),
    windSpeedMax: num(d.wind_speed_10m_max?.[i]),
    windGustsMax: num(d.wind_gusts_10m_max?.[i]),
    windDirectionDominant: num(d.wind_direction_10m_dominant?.[i]),
    uvIndexMax: num(d.uv_index_max?.[i]),
    sunrise: str(d.sunrise?.[i]),
    sunset: str(d.sunset?.[i]),
    daylightSeconds: num(d.daylight_duration?.[i]),
  }));
}

/* ----------------------------- Air quality ----------------------------- */

export type AirQuality = {
  time: string | null;
  europeanAqi: number | null;
  usAqi: number | null;
  pm2_5: number | null;
  pm10: number | null;
  ozone: number | null;
  no2: number | null;
  so2: number | null;
  co: number | null;
  uvIndex: number | null;
  dust: number | null;
  provenance: Provenance;
  available: boolean;
  reason?: string;
};

export async function fetchAirQuality(lat: number, lon: number): Promise<AirQuality> {
  const url =
    `${AIR_BASE}?latitude=${lat.toFixed(4)}&longitude=${lon.toFixed(4)}` +
    `&current=european_aqi,us_aqi,pm10,pm2_5,carbon_monoxide,nitrogen_dioxide,sulphur_dioxide,ozone,uv_index,dust&timezone=Asia%2FColombo&forecast_days=3`;
  const key = `air:${lat.toFixed(2)}:${lon.toFixed(2)}`;
  const cached = cacheGet<AirQuality>(key);
  if (cached) return { ...cached.value, provenance: provenance("CAMS global air quality (cached)", cached.at, cached.ttl, "Served from cache") };
  const started = Date.now();
  try {
    const raw = await fetchJson<{ current?: Record<string, number | string>; error?: boolean; reason?: string }>(url);
    if (raw.error) throw new Error(raw.reason ?? "air quality unavailable");
    const c = raw.current ?? {};
    const value: AirQuality = {
      time: str(c.time),
      europeanAqi: num(c.european_aqi),
      usAqi: num(c.us_aqi),
      pm2_5: num(c.pm2_5),
      pm10: num(c.pm10),
      ozone: num(c.ozone),
      no2: num(c.nitrogen_dioxide),
      so2: num(c.sulphur_dioxide),
      co: num(c.carbon_monoxide),
      uvIndex: num(c.uv_index),
      dust: num(c.dust),
      provenance: provenance("CAMS global composition analysis via Open-Meteo", Date.now(), 1800),
      available: true,
    };
    cacheSet(key, value, 1800);
    recordIntegration("open-meteo-air-quality", AIR_BASE, "air-quality", "ok", Date.now() - started, null);
    return value;
  } catch (err) {
    const message = err instanceof Error ? err.message : "air quality unavailable";
    recordIntegration("open-meteo-air-quality", AIR_BASE, "air-quality", "degraded", Date.now() - started, message);
    return {
      time: null,
      europeanAqi: null,
      usAqi: null,
      pm2_5: null,
      pm10: null,
      ozone: null,
      no2: null,
      so2: null,
      co: null,
      uvIndex: null,
      dust: null,
      provenance: provenance("CAMS global composition analysis via Open-Meteo", Date.now(), 1800, `Air quality data unavailable: ${message}`),
      available: false,
      reason: message,
    };
  }
}

/* -------------------------------- Marine -------------------------------- */

export type MarineBundle = {
  available: boolean;
  reason?: string;
  current: { time: string | null; waveHeight: number | null; waveDirection: number | null; wavePeriod: number | null; swellHeight: number | null; seaSurfaceTemperature: number | null; oceanCurrent: number | null };
  hourly: { time: string; waveHeight: number | null; wavePeriod: number | null; waveDirection: number | null; swellHeight: number | null }[];
  provenance: Provenance;
};

export async function fetchMarine(lat: number, lon: number): Promise<MarineBundle> {
  const url =
    `${MARINE_BASE}?latitude=${lat.toFixed(4)}&longitude=${lon.toFixed(4)}` +
    `&current=wave_height,wave_direction,wave_period,swell_wave_height,sea_surface_temperature,ocean_current_velocity` +
    `&hourly=wave_height,wave_period,wave_direction,swell_wave_height&timezone=Asia%2FColombo&forecast_days=5&length_unit=metric`;
  const key = `marine:${lat.toFixed(2)}:${lon.toFixed(2)}`;
  const cached = cacheGet<MarineBundle>(key);
  if (cached) return { ...cached.value, provenance: provenance("ECMWF WAM wave model (cached)", cached.at, cached.ttl, "Served from cache") };
  const started = Date.now();
  const empty: MarineBundle = {
    available: false,
    current: { time: null, waveHeight: null, waveDirection: null, wavePeriod: null, swellHeight: null, seaSurfaceTemperature: null, oceanCurrent: null },
    hourly: [],
    provenance: provenance("ECMWF WAM wave model", Date.now(), 3600),
  };
  try {
    const raw = await fetchJson<{
      current?: Record<string, number | string>;
      hourly?: Record<string, (number | string | null)[]>;
      error?: boolean;
      reason?: string;
    }>(url);
    if (raw.error) throw new Error(raw.reason ?? "marine grid unavailable for this point");
    const c = raw.current ?? {};
    const h = raw.hourly ?? {};
    const value: MarineBundle = {
      available: true,
      current: {
        time: str(c.time),
        waveHeight: num(c.wave_height),
        waveDirection: num(c.wave_direction),
        wavePeriod: num(c.wave_period),
        swellHeight: num(c.swell_wave_height),
        seaSurfaceTemperature: num(c.sea_surface_temperature),
        oceanCurrent: num(c.ocean_current_velocity),
      },
      hourly: (h.time ?? []).map((t, i) => ({
        time: String(t),
        waveHeight: num(h.wave_height?.[i]),
        wavePeriod: num(h.wave_period?.[i]),
        waveDirection: num(h.wave_direction?.[i]),
        swellHeight: num(h.swell_wave_height?.[i]),
      })),
      provenance: provenance("ECMWF WAM wave model via Open-Meteo Marine", Date.now(), 3600),
    };
    cacheSet(key, value, 3600);
    recordIntegration("open-meteo-marine", MARINE_BASE, "marine", "ok", Date.now() - started, null);
    return value;
  } catch (err) {
    const message = err instanceof Error ? err.message : "marine grid unavailable";
    recordIntegration("open-meteo-marine", MARINE_BASE, "marine", "degraded", Date.now() - started, message);
    return { ...empty, available: false, reason: message, provenance: provenance("ECMWF WAM wave model", Date.now(), 3600, `Marine grid unavailable: ${message}`) };
  }
}

/* ---------------------------- Multi-point grid ---------------------------- */

export type GridCell = {
  name: string;
  district: string;
  lat: number;
  lon: number;
  temperature: number | null;
  precipitation: number | null;
  cloudCover: number | null;
  windSpeed: number | null;
  windDirection: number | null;
  humidity: number | null;
  uvIndex: number | null;
  cape: number | null;
  weatherCode: number | null;
  rainNext24h: number | null;
  rainNext6h: number | null;
  rainPast24h: number | null;
};

type RawMulti = RawForecast[];

export async function fetchGrid(
  points: { name: string; lat: number; lon: number; district: string }[],
): Promise<{ cells: GridCell[]; provenance: Provenance }> {
  const lats = points.map((p) => p.lat.toFixed(4)).join(",");
  const lons = points.map((p) => p.lon.toFixed(4)).join(",");
  const url =
    `${FORECAST_BASE}?latitude=${lats}&longitude=${lons}` +
    `&current=temperature_2m,precipitation,weather_code,cloud_cover,wind_speed_10m,wind_direction_10m,relative_humidity_2m` +
    `&hourly=precipitation,cape,uv_index&past_days=1&forecast_days=3&timezone=Asia%2FColombo&wind_speed_unit=kmh`;
  const key = `grid:${points.length}:${points[0]?.lat.toFixed(2)}:${points[0]?.lon.toFixed(2)}`;
  const cached = cacheGet<{ cells: GridCell[] }>(key);
  if (cached) return { ...cached.value, provenance: provenance("Best-match NWP blend (cached)", cached.at, cached.ttl, "Served from cache") };
  const started = Date.now();
  try {
    const raw = await fetchJson<RawMulti>(url);
    const list = Array.isArray(raw) ? raw : [raw];
    const cells: GridCell[] = list.map((entry, i) => {
      const p = points[i] ?? points[0];
      const c = entry.current ?? {};
      const h = entry.hourly ?? {};
      const now = Date.now();
      let rainNext6h = 0;
      let rainNext24h = 0;
      let rainPast24h = 0;
      let cape: number | null = null;
      (h.time ?? []).forEach((t, idx) => {
        const ts = new Date(String(t)).getTime();
        if (!Number.isFinite(ts)) return;
        const diffH = (ts - now) / 3600000;
        const val = num(h.precipitation?.[idx]) ?? 0;
        if (diffH >= 0 && diffH < 6) rainNext6h += val;
        if (diffH >= 0 && diffH < 24) rainNext24h += val;
        if (diffH < 0 && diffH >= -24) rainPast24h += val;
        if (cape === null && diffH >= 0 && diffH < 12) cape = num(h.cape?.[idx]);
      });
      return {
        name: p.name,
        district: p.district,
        lat: num(entry.latitude) ?? p.lat,
        lon: num(entry.longitude) ?? p.lon,
        temperature: num(c.temperature_2m),
        precipitation: num(c.precipitation),
        cloudCover: num(c.cloud_cover),
        windSpeed: num(c.wind_speed_10m),
        windDirection: num(c.wind_direction_10m),
        humidity: num(c.relative_humidity_2m),
        uvIndex: null,
        cape,
        weatherCode: num(c.weather_code),
        rainNext24h: Math.round(rainNext24h * 10) / 10,
        rainNext6h: Math.round(rainNext6h * 10) / 10,
        rainPast24h: Math.round(rainPast24h * 10) / 10,
      };
    });
    cacheSet(key, { cells }, 600);
    recordIntegration("open-meteo-forecast", FORECAST_BASE, "forecast", "ok", Date.now() - started, null);
    return { cells, provenance: provenance("Best-match NWP blend via Open-Meteo", Date.now(), 600) };
  } catch (err) {
    const message = err instanceof Error ? err.message : "grid fetch failed";
    recordIntegration("open-meteo-forecast", FORECAST_BASE, "forecast", "down", Date.now() - started, message);
    throw new Error(message);
  }
}

/** Hourly precipitation time series for the animated model timeline layer. */
export async function fetchGridTimeline(points: { name: string; lat: number; lon: number; district: string }[]) {
  const lats = points.map((p) => p.lat.toFixed(4)).join(",");
  const lons = points.map((p) => p.lon.toFixed(4)).join(",");
  const url =
    `${FORECAST_BASE}?latitude=${lats}&longitude=${lons}` +
    `&hourly=precipitation,cloud_cover&past_days=1&forecast_days=3&timezone=Asia%2FColombo`;
  const key = `grid-timeline:${points.length}:${points[0]?.lat.toFixed(2)}`;
  const cached = cacheGet<{ times: string[]; series: { name: string; district: string; lat: number; lon: number; precipitation: (number | null)[]; cloudCover: (number | null)[] }[] }>(key);
  if (cached) return cached.value;
  const raw = await fetchJson<RawMulti>(url);
  const list = Array.isArray(raw) ? raw : [raw];
  const series = list.map((entry, i) => {
    const p = points[i] ?? points[0];
    return {
      name: p.name,
      district: p.district,
      lat: num(entry.latitude) ?? p.lat,
      lon: num(entry.longitude) ?? p.lon,
      precipitation: (entry.hourly?.precipitation ?? []).map((v) => num(v)),
      cloudCover: (entry.hourly?.cloud_cover ?? []).map((v) => num(v)),
    };
  });
  const times = (list[0]?.hourly?.time ?? []).map((t) => String(t));
  const value = { times, series };
  cacheSet(key, value, 900);
  return value;
}

export async function recordIntegration(
  provider: string,
  endpoint: string,
  kind: string,
  status: string,
  latencyMs: number,
  error: string | null,
) {
  try {
    const { db } = await import("@/db");
    const { integrationStatus } = await import("@/db/schema");
    const now = new Date();
    await db
      .insert(integrationStatus)
      .values({ provider, endpoint, kind, status, latencyMs, lastError: error, lastOkAt: status === "ok" ? now : null, lastCheckedAt: now })
      .onConflictDoUpdate({
        target: integrationStatus.provider,
        set: {
          status,
          latencyMs,
          lastError: error,
          lastCheckedAt: now,
          ...(status === "ok" ? { lastOkAt: now, endpoint, kind } : {}),
        },
      });
  } catch {
    // Integration health logging must never break a user-facing request.
  }
}
