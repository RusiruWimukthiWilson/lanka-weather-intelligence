import type { AirQuality, CurrentWeather, DailyPoint, HourlyPoint, Provenance } from "@/lib/weather/openmeteo";

export type WeatherResponse = {
  location: { name: string; lat: number; lon: number; district: string; province: string; elevation: number | null; timezone: string };
  current: CurrentWeather | null;
  hourly: HourlyPoint[];
  daily: DailyPoint[];
  airQuality: AirQuality | null;
  advisories: {
    dedupeKey: string;
    hazard: string;
    severity: string;
    title: string;
    summary: string;
    impacts: string[];
    actions: string[];
    areas: string[];
    authority: string;
    origin: string;
    expiresAt: string;
    evidence: Record<string, unknown>;
  }[];
  provenance: Provenance;
};

export type AlertRow = {
  id: number;
  dedupeKey: string;
  source: string;
  origin: string;
  authority: string;
  title: string;
  hazard: string;
  severity: string;
  summary: string;
  impacts: unknown;
  actions: unknown;
  areas: unknown;
  lat: number | null;
  lon: number | null;
  issuedAt: string;
  effectiveAt: string;
  expiresAt: string;
  evidence: Record<string, unknown>;
  isActive: boolean;
  fetchedAt: string;
};

export type AlertsResponse = {
  counts: { active: number; official: number; model: number };
  officialFeed: { status: string; note: string; checkedAt: string | null };
  alerts: AlertRow[];
  history: AlertRow[];
};

export type GridResponse = {
  cells: {
    name: string;
    district: string;
    lat: number;
    lon: number;
    temperature: number | null;
    precipitation: number | null;
    cloudCover: number | null;
    windSpeed: number | null;
    windDirection: number | null;
    humidity: number | null;
    uvIndex: number | null;
    cape: number | null;
    weatherCode: number | null;
    rainNext24h: number | null;
    rainNext6h: number | null;
    rainPast24h: number | null;
  }[];
  advisories: { dedupeKey: string; hazard: string; severity: string; title: string; areas: string[] }[];
  timeline: { times: string[]; series: { name: string; district: string; lat: number; lon: number; precipitation: (number | null)[]; cloudCover: (number | null)[] }[] } | null;
  provenance: Provenance;
  layerNotice: string;
  error?: string;
};

export type MarineResponse = {
  location: { name: string; lat: number; lon: number; district: string; province: string };
  marineArea: string | null;
  coastal: boolean;
  marine: {
    available: boolean;
    reason?: string;
    current: { time: string | null; waveHeight: number | null; waveDirection: number | null; wavePeriod: number | null; swellHeight: number | null; seaSurfaceTemperature: number | null; oceanCurrent: number | null };
    hourly: { time: string; waveHeight: number | null; wavePeriod: number | null; waveDirection: number | null; swellHeight: number | null }[];
    provenance: Provenance;
  };
  wind: {
    current: { speed: number | null; direction: number | null; gust: number | null } | null;
    hourly: { time: string; speed: number | null; gust: number | null; direction: number | null }[];
    daily: { date: string; windSpeedMax: number | null; windGustsMax: number | null; windDirectionDominant: number | null; precipitationSum: number | null }[];
  };
  provenance: Provenance[];
};

export type CommunityReport = {
  id: number;
  reporterName: string;
  category: string;
  intensity: string;
  note: string | null;
  placeLabel: string;
  district: string | null;
  lat: number;
  lon: number;
  status: string;
  credibility: number;
  upvotes: number;
  downvotes: number;
  hasPhoto: boolean;
  isDemo: boolean;
  moderationNote: string | null;
  observedAt: string;
  createdAt: string;
};

export type CommunityResponse = {
  categories: { id: string; label: string }[];
  reports: CommunityReport[];
  stats: { category: string; count: number }[];
  notice: string;
};
