import type { WeatherBundle, GridCell } from "@/lib/weather/openmeteo";
import { getDistrict, DISTRICTS } from "@/lib/lk-geo";
import { intensityFromMm, beaufortLabel } from "@/lib/weather/codes";

export type Severity = "advisory" | "watch" | "warning";

export type DerivedAdvisory = {
  dedupeKey: string;
  hazard: string;
  severity: Severity;
  title: string;
  summary: string;
  impacts: string[];
  actions: string[];
  areas: string[];
  authority: string;
  origin: "model";
  issuedAt: string;
  effectiveAt: string;
  expiresAt: string;
  evidence: Record<string, number | string | null>;
};

export const HAZARD_LABELS: Record<string, string> = {
  rain: "Heavy rainfall",
  flood: "Flood risk",
  landslide: "Landslide susceptibility",
  lightning: "Thunderstorm / lightning",
  wind: "Strong winds",
  cyclone: "Cyclonic conditions",
  heat: "Heat stress",
  marine: "Rough seas",
};

export const SEVERITY_ORDER: Record<Severity, number> = { advisory: 1, watch: 2, warning: 3 };

/**
 * Model-derived, impact-based screening advisories.
 *
 * These are NOT official warnings. They are computed transparently from live
 * Open-Meteo numbers using published thresholds, and every record carries the
 * measured evidence so a reader can audit why it was raised.
 */
export function deriveAdvisories(bundle: WeatherBundle, now = new Date()): DerivedAdvisory[] {
  const out: DerivedAdvisory[] = [];
  const district = getDistrict(bundle.location.district);
  const areaLabel = district ? `${district.name} District` : bundle.location.name;
  const provinceLabel = district ? `${district.province} Province` : "";
  const hourly = bundle.hourly;
  const nowMs = now.getTime();

  const next = (hours: number, pick: (p: (typeof hourly)[number]) => number | null) => {
    let sum = 0;
    let count = 0;
    for (const p of hourly) {
      const diff = (new Date(p.time).getTime() - nowMs) / 3600000;
      if (diff < 0 || diff >= hours) continue;
      const v = pick(p);
      if (v !== null) {
        sum += v;
        count += 1;
      }
    }
    return { sum, count };
  };

  const maxIn = (hours: number, pick: (p: (typeof hourly)[number]) => number | null) => {
    let max: number | null = null;
    for (const p of hourly) {
      const diff = (new Date(p.time).getTime() - nowMs) / 3600000;
      if (diff < 0 || diff >= hours) continue;
      const v = pick(p);
      if (v !== null && (max === null || v > max)) max = v;
    }
    return max;
  };

  const rain24 = next(24, (p) => p.precipitation);
  const rain48 = next(48, (p) => p.precipitation);
  const maxGust48 = maxIn(48, (p) => p.windGust);
  const maxWind48 = maxIn(48, (p) => p.windSpeed);
  const maxCape24 = maxIn(24, (p) => p.cape);
  const maxApparent24 = maxIn(24, (p) => p.apparentTemperature);
  const maxUvToday = bundle.daily[0]?.uvIndexMax ?? null;
  const dayKey = new Date().toISOString().slice(0, 10);
  const expires = new Date(nowMs + 24 * 3600 * 1000).toISOString();

  const base = {
    authority: "Lanka Weather Intelligence model screening (Open-Meteo data)",
    origin: "model" as const,
    issuedAt: now.toISOString(),
    effectiveAt: now.toISOString(),
    expiresAt: expires,
  };

  // --- Rainfall ---
  if (rain24.count > 6) {
    const mm = Math.round(rain24.sum * 10) / 10;
    if (mm >= 50) {
      const severity: Severity = mm >= 100 ? "warning" : mm >= 75 ? "watch" : "advisory";
      const intensity = intensityFromMm(mm / Math.max(rain24.count, 1));
      out.push({
        ...base,
        dedupeKey: `model-rain-${areaLabel}-${dayKey}-${severity}`,
        hazard: "rain",
        severity,
        title: `Model screening: ${intensity.label.toLowerCase()} rainfall expected in ${areaLabel}`,
        summary: `Hourly forecast precipitation totals about ${mm} mm over the next 24 hours for ${areaLabel}${provinceLabel ? ` (${provinceLabel})` : ""}. Peak hourly intensity is modelled as ${intensity.label.toLowerCase()}. This is a model-derived screening, not an official warning.`,
        impacts: [
          "Localised waterlogging on low-lying roads and underpasses is possible.",
          mm >= 75
            ? "Reduced visibility and slower traffic; expect delays on main and rural routes."
            : "Occasional wet roads; allow extra travel time.",
          "Outdoor work, school travel and evening markets may be disrupted during peak showers.",
        ],
        actions: [
          "Keep drains and gutters clear around your home or shop.",
          "Avoid wading or driving through flooded stretches.",
          mm >= 75 ? "Move vehicles and goods above expected water level." : "Carry rain protection when travelling.",
          "Follow the Disaster Management Centre (DMC) for official instructions.",
        ],
        areas: [areaLabel, provinceLabel].filter(Boolean) as string[],
        evidence: { forecastPrecipitation24hMm: mm, hoursWithData: rain24.count, source: "Open-Meteo hourly precipitation" },
      });
    }

    // --- Flood susceptibility screening ---
    const past24 = bundle.hourly
      .filter((p) => nowMs - new Date(p.time).getTime() > 0 && nowMs - new Date(p.time).getTime() <= 24 * 3600 * 1000)
      .reduce((acc, p) => acc + (p.precipitation ?? 0), 0);
    if (mm >= 100 || past24 >= 100) {
      out.push({
        ...base,
        dedupeKey: `model-flood-${areaLabel}-${dayKey}`,
        hazard: "flood",
        severity: mm >= 150 || past24 >= 150 ? "watch" : "advisory",
        title: `Flood susceptibility raised for ${areaLabel}`,
        summary: `Modelled rainfall (${mm} mm expected in the next 24 h; ${Math.round(past24 * 10) / 10} mm observed by the model in the past 24 h) reaches the range where streams and urban drains can overflow. This is an automated susceptibility screening only — river-level and evacuation decisions belong to the Irrigation Department and DMC.`,
        impacts: ["Overflow of small streams, canals and urban drainage.", "Access to low-lying housing lanes may be cut temporarily."],
        actions: ["Move to higher ground if water enters your compound.", "Do not enter moving water on foot or by vehicle.", "Monitor DMC and Irrigation Department announcements."],
        areas: [areaLabel, provinceLabel].filter(Boolean) as string[],
        evidence: { forecastPrecipitation24hMm: Math.round(mm * 10) / 10, modelPast24hMm: Math.round(past24 * 10) / 10, source: "Open-Meteo" },
      });
    }

    // --- Landslide susceptibility screening ---
    if (district && (district.terrain === "hill-country" || district.terrain === "highland") && mm >= 75) {
      out.push({
        ...base,
        dedupeKey: `model-landslide-${areaLabel}-${dayKey}`,
        hazard: "landslide",
        severity: mm >= 150 ? "watch" : "advisory",
        title: `Slope-stability screening raised for ${areaLabel}`,
        summary: `Sustained modelled rainfall of about ${mm} mm in 24 hours over ${district.terrain === "highland" ? "highland" : "hill-country"} terrain in ${areaLabel}. Landslide-prone slopes can become unstable under this kind of loading. NBRO issues the official landslide warnings for Sri Lanka; treat this screening as background information only.`,
        impacts: ["Possible rockfall, cut-slope failure or earth slips on steep sections.", "Hill-country bus and rail routes may face temporary blockages."],
        actions: ["Avoid steep cut slopes and overhanging rock during and after heavy rain.", "Report earth slips to the local Grama Niladhari and NBRO.", "Check official NBRO landslide advisories before travelling in hill country."],
        areas: [areaLabel, provinceLabel].filter(Boolean) as string[],
        evidence: { forecastPrecipitation24hMm: mm, terrain: district.terrain, source: "Open-Meteo + LWI terrain classification" },
      });
    }
  }

  // --- Thunderstorm / lightning ---
  if (maxCape24 !== null && maxCape24 >= 1200) {
    const severity: Severity = maxCape24 >= 2500 ? "watch" : "advisory";
    out.push({
      ...base,
      dedupeKey: `model-lightning-${areaLabel}-${dayKey}-${severity}`,
      hazard: "lightning",
      severity,
      title: `Thunderstorm potential modelled for ${areaLabel}`,
      summary: `Atmospheric instability (CAPE ≈ ${Math.round(maxCape24)} J/kg) in the next 24 hours supports thunderstorm development over ${areaLabel}. CAPE indicates potential, not a certainty; lightning detection requires a dedicated detection network.`,
      impacts: ["Risk to people in open fields, water and small boats.", "Possible damage to electrical equipment and power interruptions."],
      actions: ["Seek substantial shelter at the first thunder.", "Unplug sensitive appliances.", "Avoid tall isolated trees, metal fences and open water."],
      areas: [areaLabel, provinceLabel].filter(Boolean) as string[],
      evidence: { maxCapeJkg: Math.round(maxCape24), source: "Open-Meteo hourly CAPE" },
    });
  }

  // --- Wind ---
  if (maxWind48 !== null && maxWind48 >= 40) {
    const severity: Severity = maxWind48 >= 90 ? "warning" : maxWind48 >= 62 ? "watch" : "advisory";
    const isMarineish = maxWind48 >= 50;
    out.push({
      ...base,
      dedupeKey: `model-wind-${areaLabel}-${dayKey}-${severity}`,
      hazard: maxWind48 >= 90 ? "cyclone" : "wind",
      severity,
      title: maxWind48 >= 90 ? `Severe wind screening for ${areaLabel}` : `Strong wind screening for ${areaLabel}`,
      summary: `Modelled sustained winds reach about ${Math.round(maxWind48)} km/h${maxGust48 ? ` with gusts near ${Math.round(maxGust48)} km/h` : ""} within 48 hours (${beaufortLabel(maxWind48)}). ${maxWind48 >= 90 ? "Winds of this strength are associated with organised storm systems; verify against official Department of Meteorology advisories immediately." : ""}`,
      impacts: [
        "Loose sheets, hoardings and tree branches may become hazardous.",
        isMarineish ? "Small craft and fishing operations face worsening sea states." : "Cycling and two-wheel travel becomes harder.",
        maxWind48 >= 62 ? "Possible localised power interruptions from fallen lines." : "Occasional buffeting on exposed roads.",
      ],
      actions: ["Secure loose outdoor items.", "Park away from large trees and unstable structures.", maxWind48 >= 50 ? "Fishermen and small craft should check the marine section and official naval advisories." : "Take care on exposed causeways and overpasses."],
      areas: [areaLabel, provinceLabel].filter(Boolean) as string[],
      evidence: { maxSustainedKmh: Math.round(maxWind48), maxGustKmh: maxGust48 === null ? null : Math.round(maxGust48), source: "Open-Meteo 10 m wind" },
    });
  }

  // --- Heat ---
  if (maxApparent24 !== null && maxApparent24 >= 36) {
    const severity: Severity = maxApparent24 >= 43 ? "warning" : maxApparent24 >= 39 ? "watch" : "advisory";
    out.push({
      ...base,
      dedupeKey: `model-heat-${areaLabel}-${dayKey}-${severity}`,
      hazard: "heat",
      severity,
      title: `Heat-stress screening for ${areaLabel}`,
      summary: `Apparent temperature is modelled to reach about ${Math.round(maxApparent24)}°C in the next 24 hours over ${areaLabel}${maxUvToday ? `, with a UV index up to ${maxUvToday}` : ""}.`,
      impacts: ["Heat exhaustion risk for outdoor workers, children and older adults.", "Livestock and poultry heat stress; higher irrigation demand."],
      actions: ["Drink water regularly even without thirst.", "Schedule heavy outdoor work before 10 am or after 4 pm.", "Check on elderly neighbours and never leave children in parked vehicles."],
      areas: [areaLabel, provinceLabel].filter(Boolean) as string[],
      evidence: { maxApparentTemperatureC: Math.round(maxApparent24 * 10) / 10, uvIndexMax: maxUvToday, source: "Open-Meteo" },
    });
  }

  return out;
}

/**
 * Aggregated-cell variant: computes the same impact-based screening from the
 * 24 h precipitation/wind/CAPE aggregates produced by the nationwide grid
 * request. Used for the alerts module and the map so that a single upstream
 * request covers every district.
 */
export function deriveCellAdvisories(cell: GridCell, now = new Date()): DerivedAdvisory[] {
  const district = getDistrict(cell.district);
  if (!district) return [];
  const areaLabel = `${district.name} District`;
  const provinceLabel = `${district.province} Province`;
  const dayKey = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Colombo" }).format(now);
  const base = {
    authority: "Lanka Weather Intelligence model screening (Open-Meteo data)",
    origin: "model" as const,
    issuedAt: now.toISOString(),
    effectiveAt: now.toISOString(),
    expiresAt: new Date(now.getTime() + 12 * 3600 * 1000).toISOString(),
  };
  const out: DerivedAdvisory[] = [];
  const mm = cell.rainNext24h ?? 0;

  if (mm >= 50) {
    const severity: Severity = mm >= 100 ? "warning" : mm >= 75 ? "watch" : "advisory";
    out.push({
      ...base,
      dedupeKey: `model-rain-${areaLabel}-${dayKey}-${severity}`,
      hazard: "rain",
      severity,
      title: `Model screening: rainfall near ${Math.round(mm)} mm/24 h in ${areaLabel}`,
      summary: `Open-Meteo hourly precipitation aggregates to about ${Math.round(mm)} mm over the next 24 hours for ${areaLabel}. Model-derived screening — not an official warning.`,
      impacts: ["Waterlogging on low-lying roads.", "Disruption to outdoor work and school travel during peak showers."],
      actions: ["Clear drains around your premises.", "Avoid flooded stretches.", "Confirm with DMC for official instructions."],
      areas: [areaLabel, provinceLabel],
      evidence: { forecastPrecipitation24hMm: Math.round(mm * 10) / 10, source: "Open-Meteo" },
    });
    if (mm >= 100 || (cell.rainPast24h ?? 0) >= 100) {
      out.push({
        ...base,
        dedupeKey: `model-flood-${areaLabel}-${dayKey}`,
        hazard: "flood",
        severity: "advisory",
        title: `Flood susceptibility raised for ${areaLabel}`,
        summary: `Combined modelled rainfall (${Math.round(mm)} mm next 24 h, ${Math.round(cell.rainPast24h ?? 0)} mm previous 24 h) is in the range where streams and urban drains can overflow. River-level decisions rest with the Irrigation Department and DMC.`,
        impacts: ["Overflow of streams, canals and drains.", "Temporary loss of access to low-lying lanes."],
        actions: ["Move to higher ground if water enters your compound.", "Never enter moving water.", "Follow official DMC guidance."],
        areas: [areaLabel, provinceLabel],
        evidence: { forecastPrecipitation24hMm: Math.round(mm * 10) / 10, modelPast24hMm: Math.round(cell.rainPast24h ?? 0) },
      });
    }
    if ((district.terrain === "hill-country" || district.terrain === "highland") && mm >= 75) {
      out.push({
        ...base,
        dedupeKey: `model-landslide-${areaLabel}-${dayKey}`,
        hazard: "landslide",
        severity: mm >= 150 ? "watch" : "advisory",
        title: `Slope-stability screening raised for ${areaLabel}`,
        summary: `About ${Math.round(mm)} mm of modelled rain in 24 h over ${district.terrain} terrain. NBRO issues the official landslide warnings for Sri Lanka.`,
        impacts: ["Cut-slope failure, rockfall or earth slips possible.", "Hill-country road and rail blockages possible."],
        actions: ["Avoid steep cut slopes.", "Report earth slips to your Grama Niladhari and NBRO.", "Check official NBRO advisories before hill travel."],
        areas: [areaLabel, provinceLabel],
        evidence: { forecastPrecipitation24hMm: Math.round(mm * 10) / 10, terrain: district.terrain },
      });
    }
  }

  const wind = cell.windSpeed ?? 0;
  if (wind >= 40) {
    const severity: Severity = wind >= 90 ? "warning" : wind >= 62 ? "watch" : "advisory";
    out.push({
      ...base,
      dedupeKey: `model-wind-${areaLabel}-${dayKey}-${severity}`,
      hazard: wind >= 90 ? "cyclone" : "wind",
      severity,
      title: `Strong wind screening for ${areaLabel}`,
      summary: `Modelled sustained winds near ${Math.round(wind)} km/h (${beaufortLabel(wind)}).`,
      impacts: ["Loose sheets and branches become hazardous.", wind >= 50 ? "Small craft face worsening sea states." : "Two-wheel travel becomes harder."],
      actions: ["Secure loose items.", "Park away from trees.", wind >= 50 ? "Check the marine section and official sea bulletins." : "Take care on exposed roads."],
      areas: [areaLabel, provinceLabel],
      evidence: { maxSustainedKmh: Math.round(wind), source: "Open-Meteo" },
    });
    if (district.coastal && wind >= 40) {
      out.push({
        ...base,
        dedupeKey: `model-marine-${areaLabel}-${dayKey}-${severity}`,
        hazard: "marine",
        severity,
        title: `Sea-area wind screening: ${district.marineArea ?? district.name}`,
        summary: `Coastal winds near ${Math.round(wind)} km/h around ${district.marineArea ?? district.name}. Official sea-area bulletins are issued by the Department of Meteorology.`,
        impacts: ["Rough seas for multiday boats and small craft.", "Difficult landing on open beaches."],
        actions: ["Check the official sea bulletin before sailing.", "Wear life jackets; monitor VHF channel 08."],
        areas: [district.marineArea ?? district.name, areaLabel],
        evidence: { maxSustainedKmh: Math.round(wind), source: "Open-Meteo coastal grid" },
      });
    }
  }

  if ((cell.cape ?? 0) >= 1200) {
    const severity: Severity = (cell.cape ?? 0) >= 2500 ? "watch" : "advisory";
    out.push({
      ...base,
      dedupeKey: `model-lightning-${areaLabel}-${dayKey}-${severity}`,
      hazard: "lightning",
      severity,
      title: `Thunderstorm potential modelled for ${areaLabel}`,
      summary: `Instability (CAPE ≈ ${Math.round(cell.cape ?? 0)} J/kg) supports thunderstorm development. CAPE indicates potential, not certainty.`,
      impacts: ["Risk to people in open fields, water and small boats.", "Possible power interruptions."],
      actions: ["Shelter at the first thunder.", "Unplug sensitive appliances.", "Avoid isolated trees and open water."],
      areas: [areaLabel, provinceLabel],
      evidence: { maxCapeJkg: Math.round(cell.cape ?? 0), source: "Open-Meteo CAPE" },
    });
  }

  return out;
}

/** Marine screening advisories derived from coastal grid cells. */
export function deriveMarineAdvisories(cells: GridCell[], now = new Date()): DerivedAdvisory[] {
  const dayKey = now.toISOString().slice(0, 10);
  const out: DerivedAdvisory[] = [];
  const windy = cells.filter((c) => (c.windSpeed ?? 0) >= 40 && (c.precipitation ?? 0) !== null);
  const grouped = new Map<string, number>();
  for (const c of windy) {
    const district = getDistrict(c.district);
    if (!district?.coastal) continue;
    grouped.set(district.marineArea ?? district.name, Math.max(grouped.get(district.marineArea ?? district.name) ?? 0, c.windSpeed ?? 0));
  }
  for (const [area, speed] of grouped) {
    const severity: Severity = speed >= 70 ? "watch" : "advisory";
    out.push({
      authority: "Lanka Weather Intelligence model screening (Open-Meteo data)",
      origin: "model",
      hazard: "marine",
      severity,
      dedupeKey: `model-marine-${area}-${dayKey}-${severity}`,
      title: `Sea-area wind screening: ${area}`,
      summary: `Modelled coastal winds near ${Math.round(speed)} km/h around ${area}. Sea state deteriorates quickly above 40 km/h for small craft. Official sea-area bulletins are issued by the Department of Meteorology.`,
      impacts: ["Rough seas for multiday boats and small craft.", "Difficult landing conditions on open beaches."],
      actions: ["Check the official naval and Met Department sea bulletin before sailing.", "Wear life jackets; keep VHF channel 08 monitored."],
      areas: [area],
      issuedAt: now.toISOString(),
      effectiveAt: now.toISOString(),
      expiresAt: new Date(now.getTime() + 24 * 3600 * 1000).toISOString(),
      evidence: { maxSustainedKmh: Math.round(speed), source: "Open-Meteo coastal grid" },
    });
  }
  return out;
}

/* ------------------------- Official alert ingestion ------------------------- */

export type OfficialFeedResult = {
  status: "ok" | "unavailable" | "error";
  reason?: string;
  checkedAt: string;
  items: {
    externalId: string;
    source: string;
    authority: string;
    title: string;
    summary: string;
    publishedAt: string | null;
    link: string | null;
  }[];
};

const OFFICIAL_SOURCES = [
  {
    id: "dmc",
    authority: "Sri Lanka Disaster Management Centre",
    url: "https://www.dmc.gov.lk/index.php/component/content/category/98-weather-forecast?format=feed&type=rss",
  },
  {
    id: "meteo",
    authority: "Sri Lanka Department of Meteorology",
    url: "https://www.meteo.gov.lk/index.php?option=com_content&view=featured&format=feed&type=rss&Itemid=435",
  },
];

function stripTags(html: string) {
  return html
    .replace(/<[^>]*>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&quot;/g, '"')
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * Attempts to read the official public RSS feeds of the DMC and the
 * Department of Meteorology. If the feed is unreachable, blocked or malformed
 * we say so instead of inventing content.
 */
export async function fetchOfficialFeeds(): Promise<OfficialFeedResult> {
  const checkedAt = new Date().toISOString();
  const items: OfficialFeedResult["items"] = [];
  const failures: string[] = [];

  await Promise.all(
    OFFICIAL_SOURCES.map(async (src) => {
      try {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 7000);
        const res = await fetch(src.url, { signal: controller.signal, cache: "no-store", headers: { accept: "application/rss+xml, application/xml, text/xml, */*" } });
        clearTimeout(timer);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const xml = await res.text();
        const blocks = xml.split(/<item[\s>]/i).slice(1, 21);
        if (!blocks.length) throw new Error("feed contained no <item> entries");
        for (const block of blocks) {
          const pick = (tag: string) => {
            const m = block.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)</${tag}>`, "i"));
            return m ? stripTags(m[1]) : "";
          };
          const title = pick("title");
          if (!title) continue;
          const description = pick("description");
          const pubDate = pick("pubDate");
          const link = pick("link");
          items.push({
            externalId: `${src.id}:${title.slice(0, 120)}`,
            source: src.id,
            authority: src.authority,
            title,
            summary: description.slice(0, 900),
            publishedAt: pubDate && !Number.isNaN(new Date(pubDate).getTime()) ? new Date(pubDate).toISOString() : null,
            link: link || null,
          });
        }
      } catch (err) {
        failures.push(`${src.id}: ${err instanceof Error ? err.message : "unknown error"}`);
      }
    }),
  );

  if (!items.length) {
    return {
      status: "unavailable",
      reason: failures.length
        ? `Official feeds not reachable from this deployment (${failures.join("; ")}). Official advisories must be confirmed directly with DMC / Met Department.`
        : "Official feeds returned no parseable advisories.",
      checkedAt,
      items: [],
    };
  }
  return { status: "ok", checkedAt, items };
}

export function severityFromText(text: string): Severity {
  const t = text.toLowerCase();
  if (/(red|level 3|level-3|severe|evacuat)/.test(t)) return "warning";
  if (/(amber|level 2|watch|caution)/.test(t)) return "watch";
  return "advisory";
}

export function districtFromText(text: string): string[] {
  const found = new Set<string>();
  for (const d of DISTRICTS) {
    if (new RegExp(`\\b${d.name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "i").test(text)) found.add(d.name);
  }
  return [...found];
}
