export function round(v: number | null | undefined, digits = 0): number | null {
  if (v === null || v === undefined || !Number.isFinite(v)) return null;
  const f = 10 ** digits;
  return Math.round(v * f) / f;
}

export function fmtTemp(v: number | null | undefined, digits = 0): string {
  if (v === null || v === undefined || !Number.isFinite(v)) return "—";
  return `${Math.round(v * 10 ** digits) / 10 ** digits}°C`;
}

export function fmtNum(v: number | null | undefined, digits = 0, unit = ""): string {
  if (v === null || v === undefined || !Number.isFinite(v)) return "—";
  return `${Math.round(v * 10 ** digits) / 10 ** digits}${unit ? ` ${unit}` : ""}`;
}

/** Formats an ISO-ish local timestamp string (Open-Meteo returns local time without TZ offset). */
export function parseLocal(input: string | null | undefined): Date | null {
  if (!input) return null;
  const d = new Date(input);
  return Number.isNaN(d.getTime()) ? null : d;
}

export function fmtTime(input: string | Date | null | undefined, opts: { hour12?: boolean } = {}): string {
  const d = typeof input === "string" ? parseLocal(input) : input;
  if (!d) return "—";
  return d.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", hour12: opts.hour12 ?? false });
}

export function fmtDay(input: string | Date | null | undefined, style: "short" | "long" = "short"): string {
  const d = typeof input === "string" ? parseLocal(input) : input;
  if (!d) return "—";
  return d.toLocaleDateString("en-GB", { weekday: style, day: "numeric", month: "short" });
}

export function fmtDateTime(input: string | Date | null | undefined): string {
  const d = typeof input === "string" ? parseLocal(input) : input;
  if (!d) return "—";
  return `${d.toLocaleDateString("en-GB", { day: "numeric", month: "short" })} ${d.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })}`;
}

export function timeAgo(iso: string | Date | null | undefined): string {
  const d = typeof iso === "string" ? parseLocal(iso) : iso;
  if (!d) return "unknown";
  const secs = Math.round((Date.now() - d.getTime()) / 1000);
  if (secs < 45) return "just now";
  if (secs < 3600) return `${Math.round(secs / 60)} min ago`;
  if (secs < 86400) return `${Math.round(secs / 3600)} h ago`;
  return `${Math.round(secs / 86400)} d ago`;
}

export function relativeMinutes(iso: string | null | undefined): number | null {
  const d = parseLocal(iso);
  if (!d) return null;
  return Math.round((Date.now() - d.getTime()) / 60000);
}

export function severityColor(severity: string): string {
  switch (severity) {
    case "warning":
      return "#f43f5e";
    case "watch":
      return "#f97316";
    case "advisory":
      return "#eab308";
    default:
      return "#38bdf8";
  }
}

export function severityLabel(severity: string): string {
  switch (severity) {
    case "warning":
      return "Warning";
    case "watch":
      return "Watch";
    case "advisory":
      return "Advisory";
    default:
      return "Notice";
  }
}

export const COLOMBO_TZ = "Asia/Colombo";

export function colomboNow(): Date {
  return new Date();
}

export function dayKeyIn(d: Date, offsetDays = 0): string {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: COLOMBO_TZ,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date(d.getTime() + offsetDays * 86400000));
  return parts;
}
