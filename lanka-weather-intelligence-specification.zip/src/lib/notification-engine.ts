import { db } from "@/db";
import { notifications, subscriptions, users, ingestRuns } from "@/db/schema";
import { and, desc, eq, sql } from "drizzle-orm";
import { listAlerts } from "@/lib/alerts-service";
import { SEVERITY_ORDER, type Severity } from "@/lib/advisory";

const CATEGORY_TO_HAZARD: Record<string, string[]> = {
  rain: ["rain", "flood"],
  flood: ["flood"],
  landslide: ["landslide"],
  lightning: ["lightning"],
  wind: ["wind", "cyclone"],
  heat: ["heat"],
  marine: ["marine"],
};

export type EngineResult = {
  checkedSubscriptions: number;
  notificationsCreated: number;
  skippedQuietHours: number;
  examples: { userId: number; title: string; body: string }[];
};

/**
 * Personalised notification engine.
 *
 * Matches stored user subscriptions against the active alert records
 * (official + model screening) and writes in-app notifications with a
 * deterministic dedupe key so the same advisory is never delivered twice.
 */
export async function runNotificationEngine(): Promise<EngineResult> {
  const active = await listAlerts({});
  const subs = await db.select().from(subscriptions).where(eq(subscriptions.active, true));
  const nowColomboHour = Number(
    new Intl.DateTimeFormat("en-GB", { timeZone: "Asia/Colombo", hour: "2-digit", hour12: false }).format(new Date()),
  );

  const result: EngineResult = { checkedSubscriptions: subs.length, notificationsCreated: 0, skippedQuietHours: 0, examples: [] };

  for (const sub of subs) {
    const userRows = await db.select().from(users).where(eq(users.id, sub.userId)).limit(1);
    const user = userRows[0];
    if (!user || !user.isActive) continue;

    const categories = Array.isArray(sub.categories) ? (sub.categories as string[]) : [];
    const wantedHazards = new Set(categories.flatMap((c) => CATEGORY_TO_HAZARD[c] ?? []));
    const minSeverity = (SEVERITY_ORDER[(sub.minimumSeverity as Severity) ?? "advisory"] ?? 1) as number;

    const quiet = user.quietHoursEnabled;
    const inQuietHours = quiet
      ? user.quietHoursStart <= user.quietHoursEnd
        ? nowColomboHour >= user.quietHoursStart && nowColomboHour < user.quietHoursEnd
        : nowColomboHour >= user.quietHoursStart || nowColomboHour < user.quietHoursEnd
      : false;

    const matched = active.filter((alert) => {
      if (SEVERITY_ORDER[(alert.severity as Severity) ?? "advisory"] < minSeverity) return false;
      if (wantedHazards.size && !wantedHazards.has(alert.hazard)) return false;
      const areas = Array.isArray(alert.areas) ? (alert.areas as string[]) : [];
      if (sub.scopeType === "district") return areas.some((a) => a.toLowerCase().includes((sub.district ?? "").toLowerCase()));
      if (sub.scopeType === "location") {
        if (areas.length === 0) return true;
        return areas.some((a) => a.toLowerCase().includes((sub.scopeLabel ?? "").toLowerCase()));
      }
      return true;
    });

    if (!matched.length) continue;

    const top = matched[0];
    if (inQuietHours) {
      result.skippedQuietHours += 1;
      continue;
    }

    const dedupeKey = `notif:${sub.id}:${top.dedupeKey}`.slice(0, 240);
    const inserted = await db
      .insert(notifications)
      .values({
        userId: user.id,
        title: top.origin === "official" ? `Official: ${top.title}`.slice(0, 180) : top.title.slice(0, 180),
        body: top.summary.slice(0, 700),
        category: top.hazard,
        severity: top.severity,
        kind: "advisory",
        origin: top.origin,
        source: top.authority,
        dedupeKey,
        link: top.origin === "official" ? "/alerts" : "/alerts",
      })
      .onConflictDoNothing({ target: notifications.dedupeKey })
      .returning({ id: notifications.id });

    if (inserted.length) {
      result.notificationsCreated += 1;
      if (result.examples.length < 5) {
        result.examples.push({ userId: user.id, title: top.title, body: top.summary.slice(0, 160) });
      }
    }
  }

  const lastRun = await db.select().from(ingestRuns).orderBy(desc(ingestRuns.startedAt)).limit(1);
  if (lastRun[0]) {
    await db
      .update(ingestRuns)
      .set({ notificationsCreated: result.notificationsCreated })
      .where(eq(ingestRuns.id, lastRun[0].id));
  }

  return result;
}

export async function listNotifications(userId: number, limit = 60) {
  return db.select().from(notifications).where(eq(notifications.userId, userId)).orderBy(desc(notifications.createdAt)).limit(limit);
}

export async function unreadCount(userId: number) {
  const rows = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(notifications)
    .where(and(eq(notifications.userId, userId), sql`${notifications.readAt} is null`));
  return rows[0]?.count ?? 0;
}
