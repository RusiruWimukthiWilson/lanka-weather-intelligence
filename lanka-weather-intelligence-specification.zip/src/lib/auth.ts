import { randomBytes, scryptSync, timingSafeEqual } from "crypto";
import { cookies } from "next/headers";
import { eq, and, gt } from "drizzle-orm";
import { db } from "@/db";
import { sessions, users } from "@/db/schema";

export const SESSION_COOKIE = "lwi_session";
const SESSION_DAYS = 30;

export type SessionUser = {
  id: number;
  email: string;
  name: string;
  role: string;
  language: string;
  units: string;
  reduceMotion: boolean;
  highContrast: boolean;
  quietHoursEnabled: boolean;
  quietHoursStart: number;
  quietHoursEnd: number;
  pushEnabled: boolean;
  homeLabel: string | null;
  homeLat: number | null;
  homeLon: number | null;
};

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const candidate = scryptSync(password, salt, 64);
  const expected = Buffer.from(hash, "hex");
  if (candidate.length !== expected.length) return false;
  return timingSafeEqual(candidate, expected);
}

export async function createSession(userId: number): Promise<string> {
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 86400 * 1000);
  await db.insert(sessions).values({ token, userId, expiresAt });
  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    secure: process.env.NODE_ENV === "production",
    expires: expiresAt,
  });
  return token;
}

export async function destroySession(): Promise<void> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (token) {
    await db.delete(sessions).where(eq(sessions.token, token)).catch(() => undefined);
  }
  store.delete(SESSION_COOKIE);
}

export async function getSessionUser(): Promise<SessionUser | null> {
  try {
    const store = await cookies();
    const token = store.get(SESSION_COOKIE)?.value;
    if (!token) return null;
    const rows = await db
      .select({
        id: users.id,
        email: users.email,
        name: users.name,
        role: users.role,
        language: users.language,
        units: users.units,
        reduceMotion: users.reduceMotion,
        highContrast: users.highContrast,
        quietHoursEnabled: users.quietHoursEnabled,
        quietHoursStart: users.quietHoursStart,
        quietHoursEnd: users.quietHoursEnd,
        pushEnabled: users.pushEnabled,
        homeLabel: users.homeLabel,
        homeLat: users.homeLat,
        homeLon: users.homeLon,
        isActive: users.isActive,
      })
      .from(sessions)
      .innerJoin(users, eq(users.id, sessions.userId))
      .where(and(eq(sessions.token, token), gt(sessions.expiresAt, new Date())))
      .limit(1);
    const row = rows[0];
    if (!row || !row.isActive) return null;
    const { isActive: _isActive, ...user } = row;
    return user;
  } catch {
    return null;
  }
}

export async function requireUser(): Promise<{ user: SessionUser } | { error: Response }> {
  const user = await getSessionUser();
  if (!user) {
    return { error: Response.json({ error: "Authentication required" }, { status: 401 }) };
  }
  return { user };
}

export async function requireAdmin(): Promise<{ user: SessionUser } | { error: Response }> {
  const result = await requireUser();
  if ("error" in result) return result;
  if (result.user.role !== "admin") {
    return { error: Response.json({ error: "Administrator role required" }, { status: 403 }) };
  }
  return result;
}

export async function audit(entry: {
  userId?: number | null;
  actorLabel?: string;
  action: string;
  entity?: string | null;
  meta?: Record<string, unknown>;
  ip?: string | null;
}) {
  try {
    const { auditLogs } = await import("@/db/schema");
    await db.insert(auditLogs).values({
      userId: entry.userId ?? null,
      actorLabel: entry.actorLabel ?? "system",
      action: entry.action,
      entity: entry.entity ?? null,
      meta: entry.meta ?? {},
      ip: entry.ip ?? null,
    });
  } catch {
    // auditing must not break requests
  }
}
