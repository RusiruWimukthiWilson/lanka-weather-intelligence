"use client";

import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

const AXIS = { stroke: "#7c93bd", fontSize: 10 };
const GRID = "rgba(124,147,189,0.14)";

const tooltipStyle = {
  contentStyle: {
    background: "rgba(8,18,42,0.96)",
    border: "1px solid rgba(120,160,230,0.28)",
    borderRadius: "0.6rem",
    fontSize: 11,
    color: "#e6edf9",
  },
  labelStyle: { color: "#9fb4d8", fontSize: 10 },
} as const;

export type SeriesPoint = Record<string, number | string | null>;

export function TempTrendChart({ data, height = 190 }: { data: SeriesPoint[]; height?: number }) {
  if (!data.length) return null;
  return (
    <ResponsiveContainer width="100%" height={height}>
      <AreaChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: -18 }}>
        <defs>
          <linearGradient id="tempFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#fbbf24" stopOpacity={0.55} />
            <stop offset="100%" stopColor="#fbbf24" stopOpacity={0.02} />
          </linearGradient>
          <linearGradient id="feelFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#38bdf8" stopOpacity={0.35} />
            <stop offset="100%" stopColor="#38bdf8" stopOpacity={0.02} />
          </linearGradient>
        </defs>
        <CartesianGrid stroke={GRID} vertical={false} />
        <XAxis dataKey="label" tick={AXIS} tickLine={false} axisLine={false} minTickGap={24} />
        <YAxis tick={AXIS} tickLine={false} axisLine={false} width={40} unit="°" />
        <Tooltip {...tooltipStyle} />
        <Area type="monotone" dataKey="feelsLike" name="Feels like (°C)" stroke="#38bdf8" fill="url(#feelFill)" strokeWidth={1.6} dot={false} />
        <Area type="monotone" dataKey="temperature" name="Temperature (°C)" stroke="#fbbf24" fill="url(#tempFill)" strokeWidth={2} dot={false} />
      </AreaChart>
    </ResponsiveContainer>
  );
}

export function RainChart({ data, height = 190 }: { data: SeriesPoint[]; height?: number }) {
  if (!data.length) return null;
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: -18 }}>
        <CartesianGrid stroke={GRID} vertical={false} />
        <XAxis dataKey="label" tick={AXIS} tickLine={false} axisLine={false} minTickGap={24} />
        <YAxis tick={AXIS} tickLine={false} axisLine={false} width={40} unit="%" domain={[0, 100]} />
        <Tooltip {...tooltipStyle} />
        <Legend wrapperStyle={{ fontSize: 10, color: "#93a4c4" }} />
        <Bar dataKey="probability" name="Rain chance (%)" radius={[3, 3, 0, 0]}>
          {data.map((d, i) => (
            <Cell key={i} fill={Number(d.probability ?? 0) >= 60 ? "#0ea5e9" : Number(d.probability ?? 0) >= 30 ? "#38bdf8" : "#1e3a5f"} />
          ))}
        </Bar>
        <Bar dataKey="mm" name="Forecast rain (mm)" fill="#a78bfa" radius={[3, 3, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function WindChart({ data, height = 180 }: { data: SeriesPoint[]; height?: number }) {
  if (!data.length) return null;
  return (
    <ResponsiveContainer width="100%" height={height}>
      <LineChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: -18 }}>
        <CartesianGrid stroke={GRID} vertical={false} />
        <XAxis dataKey="label" tick={AXIS} tickLine={false} axisLine={false} minTickGap={24} />
        <YAxis tick={AXIS} tickLine={false} axisLine={false} width={40} unit=" km/h" />
        <Tooltip {...tooltipStyle} />
        <Legend wrapperStyle={{ fontSize: 10, color: "#93a4c4" }} />
        <Line type="monotone" dataKey="gust" name="Gusts (km/h)" stroke="#fb7185" strokeWidth={1.4} dot={false} />
        <Line type="monotone" dataKey="speed" name="Sustained (km/h)" stroke="#34d399" strokeWidth={2} dot={false} />
      </LineChart>
    </ResponsiveContainer>
  );
}

export function WaveChart({ data, height = 180 }: { data: SeriesPoint[]; height?: number }) {
  if (!data.length) return null;
  return (
    <ResponsiveContainer width="100%" height={height}>
      <AreaChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: -18 }}>
        <defs>
          <linearGradient id="waveFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#22d3ee" stopOpacity={0.5} />
            <stop offset="100%" stopColor="#22d3ee" stopOpacity={0.03} />
          </linearGradient>
        </defs>
        <CartesianGrid stroke={GRID} vertical={false} />
        <XAxis dataKey="label" tick={AXIS} tickLine={false} axisLine={false} minTickGap={24} />
        <YAxis tick={AXIS} tickLine={false} axisLine={false} width={40} unit=" m" />
        <Tooltip {...tooltipStyle} />
        <Area type="monotone" dataKey="waveHeight" name="Wave height (m)" stroke="#22d3ee" fill="url(#waveFill)" strokeWidth={2} dot={false} />
      </AreaChart>
    </ResponsiveContainer>
  );
}

export function CompareChart({ data, height = 220 }: { data: SeriesPoint[]; height?: number }) {
  if (!data.length) return null;
  return (
    <ResponsiveContainer width="100%" height={height}>
      <LineChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: -18 }}>
        <CartesianGrid stroke={GRID} vertical={false} />
        <XAxis dataKey="label" tick={AXIS} tickLine={false} axisLine={false} minTickGap={20} />
        <YAxis tick={AXIS} tickLine={false} axisLine={false} width={40} unit="°" />
        <Tooltip {...tooltipStyle} />
        <Legend wrapperStyle={{ fontSize: 10, color: "#93a4c4" }} />
        {Object.keys(data[0])
          .filter((k) => k !== "label")
          .map((k, i) => (
            <Line key={k} type="monotone" dataKey={k} stroke={["#38bdf8", "#fbbf24", "#a78bfa", "#34d399"][i % 4]} strokeWidth={2} dot={false} />
          ))}
      </LineChart>
    </ResponsiveContainer>
  );
}

export function MiniBarChart({ data, height = 160 }: { data: SeriesPoint[]; height?: number }) {
  if (!data.length) return null;
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data} margin={{ top: 6, right: 6, bottom: 0, left: -22 }}>
        <CartesianGrid stroke={GRID} vertical={false} />
        <XAxis dataKey="label" tick={AXIS} tickLine={false} axisLine={false} minTickGap={10} />
        <YAxis tick={AXIS} tickLine={false} axisLine={false} width={38} />
        <Tooltip {...tooltipStyle} />
        <Bar dataKey="value" name="mm" fill="#0ea5e9" radius={[3, 3, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}
