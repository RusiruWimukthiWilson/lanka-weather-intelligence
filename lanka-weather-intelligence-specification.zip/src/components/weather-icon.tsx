"use client";

import { groupOf } from "@/lib/weather/codes";

type Props = { code: number | null | undefined; isDay?: boolean; size?: number; className?: string };

/** Animated SVG weather glyphs driven by the real WMO condition code. */
export function WeatherIcon({ code, isDay = true, size = 72, className = "" }: Props) {
  const group = groupOf(code ?? 3);
  const s = size;

  const sun = (
    <g className="anim-spin-slow" style={{ transformOrigin: "center" }}>
      <circle cx="32" cy="32" r="11" fill="url(#sunGrad)" />
      {Array.from({ length: 8 }).map((_, i) => (
        <line
          key={i}
          x1="32"
          y1="13"
          x2="32"
          y2="7"
          stroke="#fcd34d"
          strokeWidth="2.6"
          strokeLinecap="round"
          transform={`rotate(${i * 45} 32 32)`}
        />
      ))}
    </g>
  );

  const moon = (
    <g className="anim-float">
      <path d="M40 20a13 13 0 1 0 6 24 15 15 0 1 1-6-24z" fill="url(#moonGrad)" />
      <circle cx="18" cy="16" r="1.6" fill="#e2e8f5" opacity="0.9" />
      <circle cx="24" cy="10" r="1.1" fill="#e2e8f5" opacity="0.7" />
      <circle cx="14" cy="26" r="1" fill="#e2e8f5" opacity="0.6" />
    </g>
  );

  const cloud = (x = 0, y = 0, scale = 1, opacity = 1, key = "c") => (
    <g key={key} className="anim-drift" transform={`translate(${x} ${y}) scale(${scale})`} opacity={opacity}>
      <path
        d="M18 40c-4.4 0-8-3.6-8-8s3.6-8 8-8c.6 0 1.2.06 1.76.18C21.2 19.7 25.3 16.6 30 16.6c6.2 0 11.3 4.9 11.7 11.02C45.4 28.2 48 31.3 48 35c0 4.4-3.6 5-8 5H18z"
        fill="url(#cloudGrad)"
      />
    </g>
  );

  const drops = (color: string, count = 3, key = "d") => (
    <g key={key}>
      {Array.from({ length: count }).map((_, i) => (
        <line
          key={i}
          x1={22 + i * 8}
          y1="44"
          x2={20 + i * 8}
          y2="52"
          stroke={color}
          strokeWidth="2.4"
          strokeLinecap="round"
          className="anim-drop"
          style={{ animationDelay: `${i * 0.28}s` }}
        />
      ))}
    </g>
  );

  return (
    <svg width={s} height={s} viewBox="0 0 64 64" className={className} role="img" aria-label={`Weather condition: ${group}`}>
      <defs>
        <linearGradient id="sunGrad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#fde68a" />
          <stop offset="100%" stopColor="#f59e0b" />
        </linearGradient>
        <linearGradient id="moonGrad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#f8fafc" />
          <stop offset="100%" stopColor="#c7d2fe" />
        </linearGradient>
        <linearGradient id="cloudGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#e2e8f5" />
          <stop offset="100%" stopColor="#93a4c4" />
        </linearGradient>
        <linearGradient id="darkCloudGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#94a3b8" />
          <stop offset="100%" stopColor="#475569" />
        </linearGradient>
      </defs>

      {group === "clear" ? (isDay ? sun : moon) : null}

      {group === "mainly-clear" ? (
        <>
          {isDay ? <g transform="translate(-6 -6) scale(0.85)">{sun}</g> : <g transform="translate(-4 -6) scale(0.8)">{moon}</g>}
          {cloud(10, 12, 0.72, 0.95, "c1")}
        </>
      ) : null}

      {group === "partly-cloudy" ? (
        <>
          {isDay ? <g transform="translate(0 -8) scale(0.8)">{sun}</g> : <g transform="translate(2 -8) scale(0.75)">{moon}</g>}
          {cloud(4, 10, 0.95, 1, "c2")}
        </>
      ) : null}

      {group === "cloudy" ? (
        <>
          {cloud(2, 2, 0.8, 0.65, "c3")}
          {cloud(4, 10, 1, 1, "c4")}
        </>
      ) : null}

      {group === "fog" ? (
        <>
          {cloud(2, 0, 0.9, 0.8, "c5")}
          {[0, 1, 2].map((i) => (
            <line key={i} x1="12" y1={44 + i * 6} x2="52" y2={44 + i * 6} stroke="#cbd5e1" strokeWidth="2.6" strokeLinecap="round" opacity={0.8 - i * 0.2} className="anim-drift" style={{ animationDelay: `${i * 0.4}s` }} />
          ))}
        </>
      ) : null}

      {group === "drizzle" ? (
        <>
          {cloud(2, 2, 0.95, 0.95, "c6")}
          {drops("#7dd3fc", 3, "d1")}
        </>
      ) : null}

      {group === "rain" ? (
        <>
          {cloud(2, 0, 1, 1, "c7")}
          {drops("#38bdf8", 4, "d2")}
        </>
      ) : null}

      {group === "showers" ? (
        <>
          {isDay ? <g transform="translate(2 -8) scale(0.72)">{sun}</g> : null}
          {cloud(2, 4, 0.95, 1, "c8")}
          {drops("#22d3ee", 3, "d3")}
        </>
      ) : null}

      {group === "thunderstorm" ? (
        <>
          {cloud(2, -2, 1, 1, "c9")}
          <path d="M32 40l-8 12h7l-3 10 12-15h-7l4-7z" fill="#fbbf24" className="anim-flash" />
          {drops("#60a5fa", 2, "d4")}
        </>
      ) : null}

      {group === "freezing" ? (
        <>
          {cloud(2, 0, 1, 1, "c10")}
          {drops("#a5f3fc", 3, "d5")}
        </>
      ) : null}

      {group === "snow" ? (
        <>
          {cloud(2, 0, 1, 1, "c11")}
          {[0, 1, 2].map((i) => (
            <circle key={i} cx={24 + i * 8} cy="48" r="2" fill="#e0f2fe" className="anim-drop" style={{ animationDelay: `${i * 0.3}s` }} />
          ))}
        </>
      ) : null}
    </svg>
  );
}
