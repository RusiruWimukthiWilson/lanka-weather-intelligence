"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState, type ReactNode } from "react";
import { AppProvider, useApp } from "@/components/location-context";
import { LANGS } from "@/lib/i18n";
import type { Lang } from "@/lib/i18n";

type SearchResult = { name: string; type: string; district: string; province: string; lat: number; lon: number };

const NAV = [
  { href: "/", label: "Home", icon: "M3 11.5 12 4l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z" },
  { href: "/explore", label: "Explore", icon: "M12 21s7-6.1 7-11a7 7 0 1 0-14 0c0 4.9 7 11 7 11zm0-8.5a2.5 2.5 0 1 1 0-5 2.5 2.5 0 0 1 0 5z" },
  { href: "/forecast", label: "Forecast", icon: "M4 18h3v-6H4zm6 0h3V7h-3zm6 0h3v-9h-3zM3 21h18v-1.5H3z" },
  { href: "/alerts", label: "Alerts", icon: "M12 2 2 20h20zm0 5 6.2 11H5.8zM11 9h2v5h-2zm0 6h2v2h-2z" },
  { href: "/assistant", label: "AI Assistant", icon: "M12 3a4 4 0 0 1 4 4v1h1a2 2 0 0 1 2 2v3a5 5 0 0 1-5 5h-1l-3 3v-3H9a5 5 0 0 1-5-5v-3a2 2 0 0 1 2-2h1V7a4 4 0 0 1 4-4z" },
  { href: "/travel", label: "Travel", icon: "M2 16l20-8-4 9-5-2-3 4-1-5z" },
  { href: "/agriculture", label: "Agriculture", icon: "M12 22V8m0 0c0-3 2-5 6-5 0 4-2 6-6 6zm0 0c0-3-2-5-6-5 0 4 2 6 6 6zM4 22h16" },
  { href: "/marine", label: "Marine", icon: "M3 17c2 0 3 1.5 4.5 1.5S10 17 12 17s3 1.5 4.5 1.5S19 17 21 17M3 12c2 0 3 1.5 4.5 1.5S10 12 12 12s3 1.5 4.5 1.5S19 12 21 12M12 3v9" },
  { href: "/community", label: "Community", icon: "M8 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm8 0a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM2 20c0-3 3-5 6-5s6 2 6 5zm12 0c0-2 .8-3.6 2.2-4.5 3 .2 5.8 2 5.8 4.5z" },
  { href: "/profile", label: "Profile", icon: "M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm0 2c-4 0-8 2-8 5v1h16v-1c0-3-4-5-8-5z" },
];

const MOBILE_NAV = ["/", "/explore", "/forecast", "/alerts", "/assistant"];

function Icon({ path }: { path: string }) {
  return (
    <svg viewBox="0 0 24 24" className="h-[18px] w-[18px]" fill="currentColor" aria-hidden>
      <path d={path} />
    </svg>
  );
}

function SearchBox() {
  const { setLocation, geolocate, geoStatus, geoError } = useApp();
  const [q, setQ] = useState("");
  const [results, setResults] = useState<SearchResult[]>([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const boxRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!q.trim()) {
      setResults([]);
      return;
    }
    const timer = setTimeout(async () => {
      setLoading(true);
      try {
        const res = await fetch(`/api/geo/search?q=${encodeURIComponent(q)}`, { cache: "no-store" });
        const data = (await res.json()) as { results: SearchResult[] };
        setResults(data.results ?? []);
        setOpen(true);
      } catch {
        setResults([]);
      } finally {
        setLoading(false);
      }
    }, 220);
    return () => clearTimeout(timer);
  }, [q]);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (boxRef.current && !boxRef.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  return (
    <div ref={boxRef} className="relative w-full max-w-md">
      <div className="flex items-center gap-2 rounded-xl border border-sky-400/20 bg-[#0a1733]/80 px-3 py-2">
        <svg viewBox="0 0 24 24" className="h-4 w-4 text-sky-300" fill="none" stroke="currentColor" strokeWidth="2">
          <circle cx="11" cy="11" r="7" />
          <path d="m20 20-3.5-3.5" />
        </svg>
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          onFocus={() => results.length && setOpen(true)}
          placeholder="Search any Sri Lankan city or district…"
          aria-label="Search Sri Lankan locations"
          className="w-full bg-transparent text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none"
        />
        <button
          onClick={() => void geolocate()}
          className="focus-ring shrink-0 rounded-lg border border-sky-400/30 bg-sky-500/10 px-2 py-1 text-[11px] font-medium text-sky-200 hover:bg-sky-500/20"
          title="Use my location"
        >
          {geoStatus === "locating" ? "Locating…" : "Use my location"}
        </button>
      </div>
      {geoError ? <p className="mt-1 text-[11px] text-rose-300">{geoError}</p> : null}
      {open && (results.length > 0 || loading) ? (
        <div className="glass absolute z-50 mt-2 w-full overflow-hidden p-1.5">
          {loading ? <p className="px-3 py-2 text-xs text-muted">Searching…</p> : null}
          {results.map((r) => (
            <button
              key={`${r.name}-${r.type}`}
              onClick={() => {
                setLocation({ name: r.name, lat: r.lat, lon: r.lon, district: r.district, province: r.province });
                setOpen(false);
                setQ("");
              }}
              className="focus-ring flex w-full items-center justify-between gap-3 rounded-lg px-3 py-2 text-left text-sm hover:bg-sky-500/10"
            >
              <span className="min-w-0">
                <span className="block truncate text-slate-100">{r.name}</span>
                <span className="block truncate text-[11px] text-muted">
                  {r.district} District · {r.province} Province
                </span>
              </span>
              <span className="shrink-0 rounded-full border border-sky-400/25 px-2 py-0.5 text-[10px] uppercase tracking-wider text-sky-200">{r.type}</span>
            </button>
          ))}
        </div>
      ) : null}
    </div>
  );
}

function NotificationBell() {
  const { unread, user } = useApp();
  return (
    <Link
      href={user ? "/profile#notifications" : "/login"}
      className="focus-ring relative grid h-9 w-9 place-items-center rounded-xl border border-sky-400/20 bg-[#0a1733]/80 text-sky-200 hover:bg-sky-500/10"
      aria-label={`Notifications${unread ? `, ${unread} unread` : ""}`}
    >
      <Icon path="M12 2a6 6 0 0 0-6 6v3.5L4 15h16l-2-3.5V8a6 6 0 0 0-6-6zm0 20a3 3 0 0 0 3-3H9a3 3 0 0 0 3 3z" />
      {unread > 0 ? (
        <span className="absolute -right-1 -top-1 grid h-4 min-w-4 place-items-center rounded-full bg-rose-500 px-1 text-[10px] font-semibold text-white">{unread > 9 ? "9+" : unread}</span>
      ) : null}
    </Link>
  );
}

function Shell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const { lang, setLang, user, location } = useApp();
  const [moreOpen, setMoreOpen] = useState(false);

  if (pathname.startsWith("/admin")) {
    return <div className="min-h-screen">{children}</div>;
  }

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-40 border-b border-sky-400/10 bg-[#050d20]/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-[1500px] flex-wrap items-center gap-3 px-4 py-3">
          <Link href="/" className="focus-ring flex items-center gap-2.5">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-sky-400/30 to-violet-500/30 ring-1 ring-sky-300/30">
              <svg viewBox="0 0 24 24" className="h-5 w-5 text-sky-200" fill="currentColor">
                <path d="M6.5 18a4.5 4.5 0 0 1-.4-8.98A6 6 0 0 1 17.7 9.2A3.9 3.9 0 0 1 17.5 18z" />
              </svg>
            </span>
            <span className="leading-tight">
              <span className="block text-[15px] font-semibold brand-gradient">Lanka Weather Intelligence</span>
              <span className="hidden text-[10px] uppercase tracking-[0.18em] text-muted sm:block">Understand Your Weather. Protect Your Tomorrow.</span>
            </span>
          </Link>

          <div className="order-3 w-full sm:order-2 sm:w-auto sm:flex-1 sm:px-4">
            <SearchBox />
          </div>

          <div className="order-2 ml-auto flex items-center gap-2 sm:order-3">
            <div className="hidden items-center gap-1 rounded-xl border border-sky-400/20 bg-[#0a1733]/80 p-1 md:flex">
              {LANGS.map((l) => (
                <button
                  key={l.code}
                  onClick={() => setLang(l.code as Lang)}
                  className={`focus-ring rounded-lg px-2 py-1 text-[11px] font-medium ${lang === l.code ? "bg-sky-500/25 text-sky-100" : "text-slate-400 hover:text-slate-200"}`}
                  title={l.label}
                >
                  {l.native}
                </button>
              ))}
            </div>
            <NotificationBell />
            {user ? (
              <Link href="/profile" className="focus-ring flex items-center gap-2 rounded-xl border border-sky-400/20 bg-[#0a1733]/80 px-2.5 py-1.5 text-xs text-slate-200 hover:bg-sky-500/10">
                <span className="grid h-6 w-6 place-items-center rounded-full bg-gradient-to-br from-sky-400/40 to-violet-500/40 text-[10px] font-semibold text-white">
                  {user.name.slice(0, 1).toUpperCase()}
                </span>
                <span className="hidden sm:inline">{user.name.split(" ")[0]}</span>
              </Link>
            ) : (
              <Link href="/login" className="focus-ring rounded-xl border border-sky-400/30 bg-sky-500/15 px-3 py-1.5 text-xs font-medium text-sky-100 hover:bg-sky-500/25">
                Sign in
              </Link>
            )}
          </div>
        </div>
      </header>

      <div className="mx-auto flex max-w-[1500px] gap-6 px-4 py-6">
        <aside className="hidden w-56 shrink-0 lg:block">
          <nav className="glass sticky top-24 p-2.5">
            {NAV.map((n) => {
              const active = pathname === n.href;
              return (
                <Link
                  key={n.href}
                  href={n.href}
                  className={`focus-ring mb-1 flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition ${
                    active ? "bg-gradient-to-r from-sky-500/25 to-violet-500/15 text-white ring-1 ring-sky-300/25" : "text-slate-300 hover:bg-sky-500/10"
                  }`}
                >
                  <Icon path={n.icon} />
                  {n.label}
                </Link>
              );
            })}
            {user?.role === "admin" ? (
              <Link href="/admin" className="focus-ring mt-2 flex items-center gap-3 rounded-xl border border-amber-300/25 bg-amber-400/10 px-3 py-2.5 text-sm text-amber-200">
                <Icon path="M12 2 2 20h20zm0 5 6.2 11H5.8zM11 9h2v5h-2zm0 6h2v2h-2z" />
                Admin console
              </Link>
            ) : null}
            <div className="mt-3 border-t border-sky-400/10 px-3 pt-3 text-[11px] text-muted">
              <p className="font-medium text-slate-300">Selected</p>
              <p className="mt-0.5">{location.name}</p>
              <p className="mt-0.5">{location.district || "—"} · {location.province || "—"}</p>
              <p className="mt-1 font-mono text-[10px]">{location.lat.toFixed(3)}, {location.lon.toFixed(3)}</p>
            </div>
          </nav>
        </aside>

        <main className="min-w-0 flex-1 pb-24 lg:pb-6">{children}</main>
      </div>

      <nav className="fixed bottom-0 left-0 right-0 z-40 border-t border-sky-400/10 bg-[#050d20]/95 px-2 py-1.5 backdrop-blur-xl lg:hidden">
        <div className="flex items-center justify-between">
          {NAV.filter((n) => MOBILE_NAV.includes(n.href)).map((n) => {
            const active = pathname === n.href;
            return (
              <Link key={n.href} href={n.href} className={`focus-ring flex flex-1 flex-col items-center gap-1 rounded-lg py-1.5 text-[10px] ${active ? "text-sky-200" : "text-slate-400"}`}>
                <Icon path={n.icon} />
                {n.label.split(" ")[0]}
              </Link>
            );
          })}
          <button onClick={() => setMoreOpen((v) => !v)} className={`focus-ring flex flex-1 flex-col items-center gap-1 rounded-lg py-1.5 text-[10px] ${moreOpen ? "text-sky-200" : "text-slate-400"}`}>
            <Icon path="M4 6h16v2H4zm0 5h16v2H4zm0 5h16v2H4z" />
            More
          </button>
        </div>
        {moreOpen ? (
          <div className="glass mt-1 grid grid-cols-3 gap-1.5 p-2">
            {NAV.filter((n) => !MOBILE_NAV.includes(n.href)).map((n) => (
              <Link key={n.href} href={n.href} onClick={() => setMoreOpen(false)} className="focus-ring flex items-center gap-2 rounded-lg px-2 py-2 text-[11px] text-slate-300 hover:bg-sky-500/10">
                <Icon path={n.icon} />
                {n.label}
              </Link>
            ))}
          </div>
        ) : null}
      </nav>

      <footer className="border-t border-sky-400/10 px-4 py-6 text-center text-[11px] text-muted">
        <p>
          Weather data: Open-Meteo (CC BY 4.0) · Air quality: CAMS via Open-Meteo · Wave model: ECMWF WAM via Open-Meteo Marine · Boundaries: geoBoundaries
        </p>
        <p className="mt-1">
          Model screenings shown here are not official warnings. For official advisories, always confirm with the Sri Lanka Department of Meteorology, DMC and NBRO.
        </p>
      </footer>
    </div>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <AppProvider>
      <Shell>{children}</Shell>
    </AppProvider>
  );
}
