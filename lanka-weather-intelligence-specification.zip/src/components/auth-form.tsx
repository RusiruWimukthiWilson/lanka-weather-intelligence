"use client";

import Link from "next/link";
import { useState } from "react";
import { Card, SectionTitle } from "@/components/ui";

type Mode = "login" | "register";

export function AuthForm({ mode }: { mode: Mode }) {
  const [form, setForm] = useState({ email: "", password: "", name: "", language: "en" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(`/api/auth/${mode}`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(mode === "login" ? { email: form.email, password: form.password } : form),
      });
      const body = (await res.json()) as { error?: string };
      if (!res.ok) {
        setError(body.error ?? "Authentication failed.");
        return;
      }
      window.location.assign("/profile");
    } catch {
      setError("Network error — please try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Card className="mx-auto max-w-md">
      <SectionTitle
        title={mode === "login" ? "Sign in" : "Create your account"}
        subtitle={
          mode === "login"
            ? "Access saved locations, district subscriptions and your notification history."
            : "Registration is optional. Weather information stays free and open without an account."
        }
      />
      <form onSubmit={submit} className="space-y-3">
        {mode === "register" ? (
          <label className="block text-xs text-muted">
            Full name
            <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="focus-ring mt-1 w-full rounded-lg border border-sky-400/20 bg-[#0a1733] px-3 py-2 text-sm text-slate-100" />
          </label>
        ) : null}
        <label className="block text-xs text-muted">
          Email
          <input required type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="focus-ring mt-1 w-full rounded-lg border border-sky-400/20 bg-[#0a1733] px-3 py-2 text-sm text-slate-100" />
        </label>
        <label className="block text-xs text-muted">
          Password {mode === "register" ? <span className="text-slate-500">(minimum 8 characters)</span> : null}
          <input required type="password" minLength={8} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} className="focus-ring mt-1 w-full rounded-lg border border-sky-400/20 bg-[#0a1733] px-3 py-2 text-sm text-slate-100" />
        </label>
        {mode === "register" ? (
          <label className="block text-xs text-muted">
            Preferred language
            <select value={form.language} onChange={(e) => setForm({ ...form, language: e.target.value })} className="focus-ring mt-1 w-full rounded-lg border border-sky-400/20 bg-[#0a1733] px-3 py-2 text-sm text-slate-100">
              <option value="en">English</option>
              <option value="si">සිංහල (Sinhala)</option>
              <option value="ta">தமிழ் (Tamil)</option>
            </select>
          </label>
        ) : null}
        <button type="submit" disabled={busy} className="focus-ring w-full rounded-lg bg-gradient-to-r from-sky-500 to-violet-500 px-4 py-2.5 text-sm font-medium text-white disabled:opacity-50">
          {busy ? "Please wait…" : mode === "login" ? "Sign in" : "Create account"}
        </button>
        {error ? <p className="text-xs text-rose-300">{error}</p> : null}
      </form>
      <p className="mt-4 text-xs text-muted">
        {mode === "login" ? (
          <>
            No account yet?{" "}
            <Link href="/register" className="text-sky-300 underline">
              Register
            </Link>
          </>
        ) : (
          <>
            Already registered?{" "}
            <Link href="/login" className="text-sky-300 underline">
              Sign in
            </Link>
          </>
        )}
        {" · "}
        <Link href="/" className="text-sky-300 underline">
          Continue without an account
        </Link>
      </p>
      {mode === "login" ? (
        <p className="mt-3 rounded-lg border border-sky-400/15 bg-sky-500/5 p-2 text-[11px] text-muted">
          Demo administrator: <span className="text-slate-300">admin@lkweather.lk</span> / <span className="text-slate-300">Admin@12345</span> · demo citizen:{" "}
          <span className="text-slate-300">nuwan@example.lk</span> / <span className="text-slate-300">Citizen@12345</span>
        </p>
      ) : null}
    </Card>
  );
}
