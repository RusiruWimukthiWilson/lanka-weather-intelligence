"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { Lang } from "@/lib/i18n";
import { t as translate } from "@/lib/i18n";

export type SelectedLocation = {
  name: string;
  lat: number;
  lon: number;
  district: string;
  province: string;
};

export type SessionUser = {
  id: number;
  email: string;
  name: string;
  role: string;
  language: string;
  units: string;
  reduceMotion: boolean;
  highContrast: boolean;
  quietHoursEnabled: boolean;
  quietHoursStart: number;
  quietHoursEnd: number;
  pushEnabled: boolean;
  homeLabel: string | null;
  homeLat: number | null;
  homeLon: number | null;
};

export type SavedLocation = {
  id: number;
  label: string;
  district: string | null;
  province: string | null;
  lat: number;
  lon: number;
  isDefault: boolean;
};

type Store = {
  location: SelectedLocation;
  setLocation: (loc: Partial<SelectedLocation>) => void;
  lang: Lang;
  setLang: (lang: Lang) => void;
  t: (key: string) => string;
  user: SessionUser | null;
  refreshUser: () => Promise<void>;
  favourites: SavedLocation[];
  refreshFavourites: () => Promise<void>;
  geolocate: () => Promise<void>;
  geoStatus: "idle" | "locating" | "ok" | "error";
  geoError: string | null;
  unread: number;
  setUnread: (n: number) => void;
  reduceMotion: boolean;
  setReduceMotion: (v: boolean) => void;
};

const DEFAULT_LOCATION: SelectedLocation = {
  name: "Colombo",
  lat: 6.9271,
  lon: 79.8612,
  district: "Colombo",
  province: "Western",
};

const Ctx = createContext<Store | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [location, setLocationState] = useState<SelectedLocation>(DEFAULT_LOCATION);
  const [lang, setLangState] = useState<Lang>("en");
  const [user, setUser] = useState<SessionUser | null>(null);
  const [favourites, setFavourites] = useState<SavedLocation[]>([]);
  const [unread, setUnread] = useState(0);
  const [reduceMotion, setReduceMotionState] = useState(false);
  const [geoStatus, setGeoStatus] = useState<"idle" | "locating" | "ok" | "error">("idle");
  const [geoError, setGeoError] = useState<string | null>(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem("lwi:location");
      if (raw) setLocationState({ ...DEFAULT_LOCATION, ...(JSON.parse(raw) as SelectedLocation) });
      const l = localStorage.getItem("lwi:lang") as Lang | null;
      if (l && ["en", "si", "ta"].includes(l)) setLangState(l);
      const rm = localStorage.getItem("lwi:reduceMotion");
      if (rm) setReduceMotionState(rm === "true");
    } catch {
      // ignore
    }
  }, []);

  const refreshUser = useCallback(async () => {
    try {
      const res = await fetch("/api/auth/me", { cache: "no-store" });
      const data = (await res.json()) as { user: SessionUser | null };
      setUser(data.user);
      if (data.user?.language && ["en", "si", "ta"].includes(data.user.language)) setLangState(data.user.language as Lang);
    } catch {
      setUser(null);
    }
  }, []);

  const refreshFavourites = useCallback(async () => {
    try {
      const res = await fetch("/api/locations", { cache: "no-store" });
      if (!res.ok) {
        setFavourites([]);
        return;
      }
      const data = (await res.json()) as { locations: SavedLocation[] };
      setFavourites(data.locations ?? []);
    } catch {
      setFavourites([]);
    }
  }, []);

  useEffect(() => {
    void refreshUser();
    void refreshFavourites();
  }, [refreshUser, refreshFavourites]);

  const refreshUnread = useCallback(async () => {
    try {
      const res = await fetch("/api/notifications", { cache: "no-store" });
      if (!res.ok) return;
      const data = (await res.json()) as { unread: number };
      setUnread(data.unread ?? 0);
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    if (!user) {
      setUnread(0);
      return;
    }
    void refreshUnread();
    const timer = setInterval(() => void refreshUnread(), 120000);
    return () => clearInterval(timer);
  }, [user, refreshUnread]);

  const setLocation = useCallback((loc: Partial<SelectedLocation>) => {
    setLocationState((prev) => {
      const next = { ...prev, ...loc };
      try {
        localStorage.setItem("lwi:location", JSON.stringify(next));
      } catch {
        // ignore
      }
      return next;
    });
  }, []);

  const setLang = useCallback((next: Lang) => {
    setLangState(next);
    try {
      localStorage.setItem("lwi:lang", next);
    } catch {
      // ignore
    }
    void fetch("/api/profile", {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ language: next }),
    }).catch(() => undefined);
  }, []);

  const setReduceMotion = useCallback((v: boolean) => {
    setReduceMotionState(v);
    try {
      localStorage.setItem("lwi:reduceMotion", String(v));
    } catch {
      // ignore
    }
  }, []);

  const geolocate = useCallback(async () => {
    if (typeof navigator === "undefined" || !navigator.geolocation) {
      setGeoStatus("error");
      setGeoError("This browser does not expose geolocation.");
      return;
    }
    setGeoStatus("locating");
    setGeoError(null);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const lat = Number(pos.coords.latitude.toFixed(4));
        const lon = Number(pos.coords.longitude.toFixed(4));
        try {
          const res = await fetch(`/api/geo/search?mode=reverse&lat=${lat}&lon=${lon}`, { cache: "no-store" });
          const data = (await res.json()) as { results?: { name: string; district: string; province: string }[] };
          const hit = data.results?.[0];
          setLocation({ name: hit?.name ?? "My location", lat, lon, district: hit?.district ?? "", province: hit?.province ?? "" });
          setGeoStatus("ok");
        } catch {
          setLocation({ name: "My location", lat, lon, district: "", province: "" });
          setGeoStatus("ok");
        }
      },
      (err) => {
        setGeoStatus("error");
        setGeoError(err.message || "Location permission was denied.");
      },
      { enableHighAccuracy: false, timeout: 12000, maximumAge: 600000 },
    );
  }, [setLocation]);

  const value = useMemo<Store>(
    () => ({
      location,
      setLocation,
      lang,
      setLang,
      t: (key: string) => translate(lang, key),
      user,
      refreshUser,
      favourites,
      refreshFavourites,
      geolocate,
      geoStatus,
      geoError,
      unread,
      setUnread,
      reduceMotion,
      setReduceMotion,
    }),
    [location, setLocation, lang, setLang, user, refreshUser, favourites, refreshFavourites, geolocate, geoStatus, geoError, unread, reduceMotion, setReduceMotion],
  );

  return (
    <Ctx.Provider value={value}>
      <div data-reduce-motion={reduceMotion ? "true" : "false"} data-high-contrast={user?.highContrast ? "true" : "false"}>
        {children}
      </div>
    </Ctx.Provider>
  );
}

export function useApp(): Store {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useApp must be used inside AppProvider");
  return ctx;
}

export { DEFAULT_LOCATION };
