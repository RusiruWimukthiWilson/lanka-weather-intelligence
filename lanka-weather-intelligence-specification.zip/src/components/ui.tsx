"use client";

import type { ReactNode } from "react";

export function Card({ children, className = "", as = "div" }: { children: ReactNode; className?: string; as?: "div" | "section" | "article" }) {
  const Tag = as;
  return <Tag className={`glass p-5 ${className}`}>{children}</Tag>;
}

export function SectionTitle({ title, subtitle, right }: { title: string; subtitle?: string; right?: ReactNode }) {
  return (
    <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h2 className="text-lg font-semibold tracking-tight text-slate-50">{title}</h2>
        {subtitle ? <p className="mt-1 max-w-2xl text-sm text-muted">{subtitle}</p> : null}
      </div>
      {right}
    </div>
  );
}

export function Stat({ label, value, unit, hint, tone = "default" }: { label: string; value: ReactNode; unit?: string; hint?: string; tone?: "default" | "warn" | "bad" | "good" }) {
  const toneClass =
    tone === "warn" ? "text-amber-300" : tone === "bad" ? "text-rose-300" : tone === "good" ? "text-emerald-300" : "text-slate-50";
  return (
    <div className="glass-soft p-4">
      <p className="text-[11px] uppercase tracking-[0.14em] text-muted">{label}</p>
      <p className={`mt-1.5 text-xl font-semibold ${toneClass}`}>
        {value}
        {unit ? <span className="ml-1 text-sm font-normal text-muted">{unit}</span> : null}
      </p>
      {hint ? <p className="mt-1 text-[11px] leading-snug text-muted">{hint}</p> : null}
    </div>
  );
}

export function Badge({ children, color = "#38bdf8", soft = true }: { children: ReactNode; color?: string; soft?: boolean }) {
  return (
    <span
      className="inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-medium"
      style={
        soft
          ? { backgroundColor: `${color}1f`, color, border: `1px solid ${color}44` }
          : { backgroundColor: color, color: "#05122b" }
      }
    >
      {children}
    </span>
  );
}

export function Spinner({ label }: { label?: string }) {
  return (
    <div className="flex items-center gap-3 text-sm text-muted">
      <span className="relative flex h-4 w-4">
        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-sky-400/60" />
        <span className="relative inline-flex h-4 w-4 rounded-full bg-sky-400" />
      </span>
      {label ?? "Loading live data…"}
    </div>
  );
}

export function ErrorState({ title, message, onRetry }: { title: string; message: string; onRetry?: () => void }) {
  return (
    <div className="glass p-6">
      <div className="flex items-start gap-3">
        <span className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-full bg-rose-500/15 text-rose-300">!</span>
        <div className="min-w-0">
          <p className="font-semibold text-rose-200">{title}</p>
          <p className="mt-1 text-sm text-muted">{message}</p>
          {onRetry ? (
            <button onClick={onRetry} className="focus-ring mt-3 rounded-lg border border-sky-400/40 bg-sky-500/10 px-3 py-1.5 text-xs font-medium text-sky-200 hover:bg-sky-500/20">
              Retry
            </button>
          ) : null}
        </div>
      </div>
    </div>
  );
}

export function EmptyState({ title, message, action }: { title: string; message: string; action?: ReactNode }) {
  return (
    <div className="glass-soft p-6 text-center">
      <p className="font-medium text-slate-200">{title}</p>
      <p className="mx-auto mt-1 max-w-md text-sm text-muted">{message}</p>
      {action ? <div className="mt-3 flex justify-center">{action}</div> : null}
    </div>
  );
}

export function ProvenanceBadge({
  provider,
  model,
  fetchedAt,
  stale,
  degraded,
}: {
  provider: string;
  model?: string | null;
  fetchedAt?: string | null;
  stale?: boolean;
  degraded?: string | null;
}) {
  const color = stale ? "#fbbf24" : "#34d399";
  return (
    <div className="flex flex-wrap items-center gap-2 text-[11px]">
      <Badge color={color}>{stale ? "Cached / older than refresh target" : "Live"}</Badge>
      <span className="text-muted">
        {provider}
        {model ? ` · ${model}` : ""}
        {fetchedAt ? ` · updated ${new Date(fetchedAt).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })}` : ""}
      </span>
      {degraded ? <span className="text-amber-300/90">{degraded}</span> : null}
    </div>
  );
}

export function OriginTag({ origin, authority }: { origin: string; authority?: string | null }) {
  if (origin === "official") return <Badge color="#34d399">OFFICIAL · {authority ?? "Sri Lankan authority"}</Badge>;
  if (origin === "model") return <Badge color="#fbbf24">MODEL SCREENING · {authority ?? "LWI (Open-Meteo)"}</Badge>;
  if (origin === "community") return <Badge color="#f472b6">UNVERIFIED COMMUNITY REPORT</Badge>;
  return <Badge color="#94a3b8">{origin}</Badge>;
}

export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className="focus-ring flex items-center gap-2 text-sm text-slate-200"
    >
      <span className={`relative h-5 w-9 rounded-full transition ${checked ? "bg-sky-500" : "bg-slate-600/70"}`}>
        <span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white transition ${checked ? "left-4.5" : "left-0.5"}`} style={{ left: checked ? 18 : 2 }} />
      </span>
      {label}
    </button>
  );
}
