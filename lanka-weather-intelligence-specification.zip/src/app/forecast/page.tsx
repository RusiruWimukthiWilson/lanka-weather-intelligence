"use client";

import { useMemo, useState } from "react";
import { useApp } from "@/components/location-context";
import { useApi } from "@/components/use-api";
import { WeatherIcon } from "@/components/weather-icon";
import { Card, ErrorState, EmptyState, ProvenanceBadge, SectionTitle, Spinner, Stat, Badge } from "@/components/ui";
import { RainChart, TempTrendChart, WindChart } from "@/components/charts";
import type { WeatherResponse } from "@/lib/types";
import { compassDirection, describeCode, intensityFromMm, beaufortLabel, uvCategory } from "@/lib/weather/codes";
import { fmtDay, fmtNum, fmtTemp, fmtTime } from "@/lib/format";

type RainWindow = { start: string; end: string; mm: number; peak: number };

function findRainWindows(hours: { time: string; precipitation: number | null; precipitationProbability: number | null }[]): RainWindow[] {
  const windows: RainWindow[] = [];
  let current: { times: string[]; mm: number; peak: number } | null = null;
  for (const h of hours) {
    const wet = (h.precipitation ?? 0) >= 0.2;
    if (wet) {
      current = current ?? { times: [], mm: 0, peak: 0 };
      current.times.push(h.time);
      current.mm += h.precipitation ?? 0;
      current.peak = Math.max(current.peak, h.precipitation ?? 0);
    } else if (current) {
      windows.push({ start: current.times[0], end: current.times[current.times.length - 1], mm: current.mm, peak: current.peak });
      current = null;
    }
  }
  if (current) windows.push({ start: current.times[0], end: current.times[current.times.length - 1], mm: current.mm, peak: current.peak });
  return windows.filter((w) => w.end !== w.start || true).slice(0, 6);
}

export default function ForecastPage() {
  const { location } = useApp();
  const [range, setRange] = useState<24 | 48 | 72>(48);
  const url = `/api/weather?lat=${location.lat}&lon=${location.lon}&name=${encodeURIComponent(location.name)}&district=${encodeURIComponent(location.district)}`;
  const { data, error, loading, reload, loadedAt } = useApi<WeatherResponse>(url, [location.lat, location.lon, location.name]);

  const future = useMemo(() => (data?.hourly ?? []).filter((h) => new Date(h.time).getTime() >= Date.now() - 3600 * 1000), [data]);
  const slice = future.slice(0, range);
  const windows = useMemo(() => findRainWindows(future.slice(0, 72)), [future]);

  if (error) return <ErrorState title="Forecast unavailable" message={`${error} No simulated forecast is substituted.`} onRetry={reload} />;
  if (!data || loading) return <Card><Spinner label="Loading hourly and daily model forecast…" /></Card>;

  const total72 = future.slice(0, 72).reduce((a, h) => a + (h.precipitation ?? 0), 0);
  const firstRain = future.find((h) => (h.precipitation ?? 0) >= 0.2);
  const maxUvDay = data.daily[0]?.uvIndexMax ?? null;

  return (
    <div className="space-y-5">
      <Card>
        <SectionTitle
          title={`Forecast intelligence — ${data.location.name}`}
          subtitle={`${data.location.district} District, ${data.location.province} Province · hourly and daily model output with rain-window analysis`}
          right={<ProvenanceBadge provider={data.provenance.provider} model={data.provenance.model} fetchedAt={loadedAt ?? data.provenance.fetchedAt} stale={data.provenance.stale} degraded={data.provenance.degraded} />}
        />
        <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
          <Stat label="Next 72 h rain" value={fmtNum(total72, 1)} unit="mm" hint={intensityFromMm(total72 / 3).label} />
          <Stat label="Modelled rain start" value={firstRain ? fmtTime(firstRain.time) : "none"} hint={firstRain ? `${fmtDay(firstRain.time)} · ${intensityFromMm(firstRain.precipitation ?? 0).label}` : "No rain expected in 72 h"} />
          <Stat label="Peak rain chance" value={fmtNum(Math.max(...future.slice(0, 24).map((h) => h.precipitationProbability ?? 0), 0), 0)} unit="%" />
          <Stat label="UV max today" value={fmtNum(maxUvDay, 1)} hint={uvCategory(maxUvDay).label} />
          <Stat label="Wind peak 24 h" value={fmtNum(Math.max(...future.slice(0, 24).map((h) => h.windSpeed ?? 0), 0), 0)} unit="km/h" hint={beaufortLabel(Math.max(...future.slice(0, 24).map((h) => h.windSpeed ?? 0), 0))} />
        </div>
      </Card>

      <Card>
        <SectionTitle
          title="Weather timeline"
          subtitle="When rain is expected to begin, how intense it may get, and when conditions improve."
          right={
            <div className="flex gap-1.5">
              {([24, 48, 72] as const).map((r) => (
                <button key={r} onClick={() => setRange(r)} className={`focus-ring rounded-lg px-2.5 py-1 text-xs ${range === r ? "bg-sky-500/25 text-sky-100" : "border border-sky-400/20 text-slate-300"}`}>
                  {r} h
                </button>
              ))}
            </div>
          }
        />
        <div className="grid gap-4 lg:grid-cols-2">
          <div>
            <p className="mb-1 text-xs text-muted">Temperature vs feels-like (°C)</p>
            <TempTrendChart data={slice.map((h) => ({ label: fmtTime(h.time), temperature: h.temperature, feelsLike: h.apparentTemperature }))} height={210} />
          </div>
          <div>
            <p className="mb-1 text-xs text-muted">Rain chance (%) and amount (mm)</p>
            <RainChart data={slice.map((h) => ({ label: fmtTime(h.time), probability: h.precipitationProbability, mm: h.precipitation }))} height={210} />
          </div>
          <div>
            <p className="mb-1 text-xs text-muted">Wind sustained vs gusts (km/h)</p>
            <WindChart data={slice.map((h) => ({ label: fmtTime(h.time), speed: h.windSpeed, gust: h.windGust }))} height={200} />
          </div>
          <div>
            <p className="mb-1 text-xs text-muted">Humidity (%) and cloud cover (%)</p>
            <WindChart data={slice.map((h) => ({ label: fmtTime(h.time), speed: h.humidity, gust: h.cloudCover }))} height={200} />
          </div>
        </div>
        <p className="mt-2 text-[11px] text-muted">Humidity and cloud panels reuse the wind chart renderer; the legend labels there apply to the wind panel only.</p>
      </Card>

      <Card>
        <SectionTitle title="Rain windows" subtitle="Contiguous modelled wet periods in the next 72 hours, derived directly from hourly precipitation values." />
        {windows.length ? (
          <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            {windows.map((w) => (
              <div key={`${w.start}-${w.end}`} className="glass-soft p-4">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium text-slate-100">
                    {fmtDay(w.start, "short")} · {fmtTime(w.start)} → {fmtTime(w.end)}
                  </p>
                  <Badge color="#38bdf8">{fmtNum(w.mm, 1, "mm")}</Badge>
                </div>
                <p className="mt-1.5 text-xs text-muted">
                  Duration {Math.round((new Date(w.end).getTime() - new Date(w.start).getTime()) / 3600000) + 1} h · peak hourly intensity {intensityFromMm(w.peak).label.toLowerCase()} ({fmtNum(w.peak, 1, "mm/h")})
                </p>
                <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-slate-700/60">
                  <div className="h-full rounded-full bg-gradient-to-r from-sky-400 to-violet-400" style={{ width: `${Math.min(100, (w.mm / 30) * 100)}%` }} />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <EmptyState title="No modelled rain windows" message="Hourly precipitation stays below 0.2 mm for the next 72 hours at this location." />
        )}
      </Card>

      <Card>
        <SectionTitle title="Hourly detail" subtitle="Full model columns — scroll horizontally on small screens." />
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px] text-left text-xs">
            <thead className="text-[10px] uppercase tracking-wider text-muted">
              <tr>
                <th className="px-2 py-2">Time</th>
                <th className="px-2 py-2">Condition</th>
                <th className="px-2 py-2">Temp</th>
                <th className="px-2 py-2">Feels</th>
                <th className="px-2 py-2">Rain %</th>
                <th className="px-2 py-2">Rain mm</th>
                <th className="px-2 py-2">Wind</th>
                <th className="px-2 py-2">RH</th>
                <th className="px-2 py-2">Cloud</th>
                <th className="px-2 py-2">UV</th>
              </tr>
            </thead>
            <tbody className="text-slate-200">
              {slice.map((h) => (
                <tr key={h.time} className="border-t border-sky-400/10">
                  <td className="whitespace-nowrap px-2 py-1.5">
                    {fmtDay(h.time, "short")} {fmtTime(h.time)}
                  </td>
                  <td className="px-2 py-1.5">
                    <span className="inline-flex items-center gap-1.5">
                      <WeatherIcon code={h.weatherCode} isDay={h.isDay} size={20} />
                      {describeCode(h.weatherCode ?? 3, h.isDay)}
                    </span>
                  </td>
                  <td className="px-2 py-1.5">{fmtTemp(h.temperature)}</td>
                  <td className="px-2 py-1.5 text-muted">{fmtTemp(h.apparentTemperature)}</td>
                  <td className="px-2 py-1.5 text-sky-300">{fmtNum(h.precipitationProbability, 0, "%")}</td>
                  <td className="px-2 py-1.5">{fmtNum(h.precipitation, 1)}</td>
                  <td className="px-2 py-1.5">
                    {fmtNum(h.windSpeed, 0, "km/h")} {compassDirection(h.windDirection)}
                  </td>
                  <td className="px-2 py-1.5">{fmtNum(h.humidity, 0, "%")}</td>
                  <td className="px-2 py-1.5">{fmtNum(h.cloudCover, 0, "%")}</td>
                  <td className="px-2 py-1.5">{fmtNum(h.uvIndex, 1)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <Card>
        <SectionTitle title="Daily forecast (14 days)" subtitle="Extended range. Confidence drops after day 7 — treat as guidance." />
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {data.daily.map((d, i) => (
            <div key={d.date} className="glass-soft p-4">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium text-slate-100">{i === 0 ? "Today" : fmtDay(d.date, "long")}</p>
                <WeatherIcon code={d.weatherCode} isDay size={36} />
              </div>
              <p className="mt-1 text-xs text-muted">{describeCode(d.weatherCode ?? 3, true)}</p>
              <div className="mt-2 flex items-baseline gap-2">
                <span className="text-lg font-semibold text-slate-50">{fmtTemp(d.tempMax)}</span>
                <span className="text-sm text-muted">{fmtTemp(d.tempMin)}</span>
              </div>
              <div className="mt-2 grid grid-cols-2 gap-2 text-[11px] text-muted">
                <span>Rain {fmtNum(d.precipitationSum, 1, "mm")}</span>
                <span className="text-sky-300">{fmtNum(d.precipitationProbabilityMax, 0, "%")} chance</span>
                <span>Wind {fmtNum(d.windSpeedMax, 0, "km/h")}</span>
                <span>Gusts {fmtNum(d.windGustsMax, 0, "km/h")}</span>
                <span>UV {fmtNum(d.uvIndexMax, 1)}</span>
                <span>{fmtTime(d.sunrise)} / {fmtTime(d.sunset)}</span>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
