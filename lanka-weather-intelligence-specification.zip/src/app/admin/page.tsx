"use client";

import Link from "next/link";
import { useState } from "react";
import { useApi } from "@/components/use-api";
import { Badge, Card, EmptyState, ErrorState, OriginTag, SectionTitle, Spinner, Stat } from "@/components/ui";
import { MiniBarChart } from "@/components/charts";
import { fmtDateTime, timeAgo } from "@/lib/format";
import { useApp } from "@/components/location-context";

type AdminData = {
  users: { id: number; email: string; name: string; role: string; language: string; isActive: boolean; createdAt: string }[];
  reports: {
    id: number;
    reporterName: string;
    category: string;
    intensity: string;
    note: string | null;
    placeLabel: string;
    district: string | null;
    status: string;
    credibility: number;
    upvotes: number;
    downvotes: number;
    createdAt: string;
    moderationNote: string | null;
  }[];
  integrations: { id: number; provider: string; endpoint: string; kind: string; status: string; lastOkAt: string | null; lastCheckedAt: string | null; lastError: string | null; latencyMs: number | null }[];
  runs: { id: number; startedAt: string; finishedAt: string | null; alertsFound: number; alertsActive: number; notificationsCreated: number; officialFeedStatus: string; notes: string | null }[];
  logs: { id: number; actorLabel: string; action: string; entity: string | null; createdAt: string; ip: string | null }[];
  stats: { users: number; reports: number; pendingReports: number; assistantMessages: number; subscriptions: number; notifications: number; byDistrict: { district: string | null; c: number }[] };
};

export default function AdminPage() {
  const { user } = useApp();
  const { data, error, loading, reload } = useApi<AdminData & { error?: string }>("/api/admin", [user?.id]);
  const [busy, setBusy] = useState(false);
  const [flash, setFlash] = useState<string | null>(null);

  if (!user) {
    return (
      <div className="mx-auto max-w-lg space-y-4 py-10">
        <Card>
          <SectionTitle title="Administrator sign-in required" subtitle="Role-based access control protects the admin console. Sign in with an administrator account to continue." />
          <Link href="/login?next=/admin" className="focus-ring inline-block rounded-lg border border-sky-400/30 bg-sky-500/15 px-4 py-2 text-sm text-sky-100">
            Go to sign in
          </Link>
        </Card>
      </div>
    );
  }

  async function act(body: Record<string, unknown>) {
    setBusy(true);
    try {
      const res = await fetch("/api/admin", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
      const body2 = (await res.json()) as { error?: string; ingestion?: { officialStatus: string; officialItems: number; modelItems: number }; engine?: { notificationsCreated: number } };
      if (!res.ok) {
        setFlash(body2.error ?? "Action failed.");
        if (res.status === 401 || res.status === 403) window.location.assign("/login?next=/admin");
        return;
      }
      if (body2.ingestion) {
        setFlash(`Ingestion finished — official status: ${body2.ingestion.officialStatus}, official items: ${body2.ingestion.officialItems}, model screenings stored: ${body2.ingestion.modelItems}, notifications created: ${body2.engine?.notificationsCreated ?? 0}.`);
      } else {
        setFlash("Done.");
      }
      await reload();
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-5">
      <Card>
        <SectionTitle
          title="Administration console"
          subtitle="Users, community moderation, integration health, alert ingestion and audit trails."
          right={
            <div className="flex gap-2">
              <button onClick={reload} className="focus-ring rounded-lg border border-sky-400/25 px-3 py-1.5 text-xs text-slate-200">
                Refresh
              </button>
              <button onClick={() => void act({ action: "ingest" })} disabled={busy} className="focus-ring rounded-lg border border-sky-400/30 bg-sky-500/15 px-3 py-1.5 text-xs text-sky-100 disabled:opacity-50">
                {busy ? "Running…" : "Run alert + notification ingestion"}
              </button>
            </div>
          }
        />
        {flash ? <p className="rounded-lg border border-sky-400/20 bg-sky-500/10 px-3 py-2 text-xs text-sky-100">{flash}</p> : null}
        <div className="mt-4 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
          <Stat label="Users" value={data?.stats.users ?? 0} />
          <Stat label="Subscriptions" value={data?.stats.subscriptions ?? 0} />
          <Stat label="Notifications" value={data?.stats.notifications ?? 0} />
          <Stat label="Community reports" value={data?.stats.reports ?? 0} hint={`${data?.stats.pendingReports ?? 0} pending`} tone={(data?.stats.pendingReports ?? 0) > 0 ? "warn" : "good"} />
          <Stat label="Assistant messages" value={data?.stats.assistantMessages ?? 0} />
          <Stat label="Integrations OK" value={(data?.integrations ?? []).filter((i) => i.status === "ok").length} hint={`${(data?.integrations ?? []).length} tracked`} />
        </div>
      </Card>

      {error ? <ErrorState title="Admin API error" message={error} onRetry={reload} /> : null}
      {loading ? <Card><Spinner label="Loading platform statistics…" /></Card> : null}

      {data ? (
        <>
          <div className="grid gap-4 xl:grid-cols-2">
            <Card>
              <SectionTitle title="Weather data integrations" subtitle="Every provider call is health-checked; failures surface here instead of fake data." />
              <div className="space-y-2">
                {data.integrations.map((i) => (
                  <div key={i.id} className="glass-soft p-3">
                    <div className="flex flex-wrap items-center gap-2">
                      <Badge color={i.status === "ok" ? "#34d399" : i.status === "degraded" ? "#fbbf24" : "#f43f5e"}>{i.status}</Badge>
                      <span className="text-sm text-slate-100">{i.provider}</span>
                      <Badge color="#94a3b8">{i.kind}</Badge>
                      <span className="ml-auto text-[10px] text-muted">{i.latencyMs ?? "—"} ms · checked {i.lastCheckedAt ? timeAgo(i.lastCheckedAt) : "—"}</span>
                    </div>
                    <p className="mt-1 truncate text-[11px] text-muted">{i.endpoint}</p>
                    {i.lastError ? <p className="mt-1 text-[11px] text-amber-200">{i.lastError.slice(0, 180)}</p> : null}
                  </div>
                ))}
                {!data.integrations.length ? <EmptyState title="No integration checks recorded yet" message="Load the dashboard or alerts page to trigger provider calls." /> : null}
              </div>
            </Card>

            <Card>
              <SectionTitle title="Recent ingestion runs" subtitle="Alert feed harvests and screening cycles." />
              <div className="space-y-2">
                {data.runs.map((r) => (
                  <div key={r.id} className="glass-soft p-3 text-xs">
                    <div className="flex flex-wrap items-center gap-2">
                      <Badge color={r.officialFeedStatus === "ok" ? "#34d399" : "#fbbf24"}>feed: {r.officialFeedStatus}</Badge>
                      <span className="text-slate-200">{fmtDateTime(r.startedAt)}</span>
                      <span className="ml-auto text-muted">{r.alertsFound} records · {r.notificationsCreated} notifications</span>
                    </div>
                    {r.notes ? <p className="mt-1 text-[11px] text-amber-200">{r.notes.slice(0, 220)}</p> : null}
                  </div>
                ))}
                {!data.runs.length ? <EmptyState title="No runs yet" message="Run ingestion to populate alert records." /> : null}
              </div>
            </Card>
          </div>

          <Card>
            <SectionTitle title="Community report moderation" subtitle="Verify genuine observations, reject spam. Verified reports carry a higher credibility weight." />
            <div className="grid gap-3 md:grid-cols-2">
              {data.reports.map((r) => (
                <div key={r.id} className="glass-soft p-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge color={r.status === "verified" ? "#34d399" : r.status === "rejected" ? "#f43f5e" : "#fbbf24"}>{r.status}</Badge>
                    <span className="text-sm text-slate-100">#{r.id} {r.category}</span>
                    <Badge color="#a78bfa">{r.intensity}</Badge>
                    <span className="ml-auto text-[10px] text-muted">{timeAgo(r.createdAt)}</span>
                  </div>
                  <p className="mt-1.5 text-xs text-slate-200">{r.note}</p>
                  <p className="mt-1 text-[11px] text-muted">
                    {r.placeLabel}, {r.district} · {r.reporterName} · credibility {r.credibility} (▲{r.upvotes} ▼{r.downvotes})
                  </p>
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    <button onClick={() => void act({ action: "moderate", id: r.id, status: "verified", note: "Confirmed by moderator" })} disabled={busy} className="focus-ring rounded-lg border border-emerald-400/30 bg-emerald-400/10 px-2.5 py-1 text-[11px] text-emerald-200">
                      Verify
                    </button>
                    <button onClick={() => void act({ action: "moderate", id: r.id, status: "rejected", note: "Not credible / spam" })} disabled={busy} className="focus-ring rounded-lg border border-rose-400/30 bg-rose-400/10 px-2.5 py-1 text-[11px] text-rose-200">
                      Reject
                    </button>
                    <button onClick={() => void act({ action: "moderate", id: r.id, status: "pending", note: "Reopened" })} disabled={busy} className="focus-ring rounded-lg border border-sky-400/25 px-2.5 py-1 text-[11px] text-slate-300">
                      Reopen
                    </button>
                  </div>
                  {r.moderationNote ? <p className="mt-1.5 text-[11px] text-amber-200">Note: {r.moderationNote}</p> : null}
                </div>
              ))}
              {!data.reports.length ? <EmptyState title="No community reports" message="Reports submitted by users will appear here for moderation." /> : null}
            </div>
          </Card>

          <div className="grid gap-4 xl:grid-cols-2">
            <Card>
              <SectionTitle title="Users" subtitle="Role-based access control — promote or disable accounts." />
              <div className="overflow-x-auto">
                <table className="w-full min-w-[520px] text-left text-xs">
                  <thead className="text-[10px] uppercase tracking-wider text-muted">
                    <tr>
                      <th className="px-2 py-2">User</th>
                      <th className="px-2 py-2">Role</th>
                      <th className="px-2 py-2">Lang</th>
                      <th className="px-2 py-2">Joined</th>
                      <th className="px-2 py-2">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="text-slate-200">
                    {data.users.map((u) => (
                      <tr key={u.id} className="border-t border-sky-400/10">
                        <td className="px-2 py-2">
                          <span className="block text-slate-100">{u.name}</span>
                          <span className="block text-[10px] text-muted">{u.email}</span>
                        </td>
                        <td className="px-2 py-2">
                          <Badge color={u.role === "admin" ? "#fbbf24" : "#38bdf8"}>{u.role}</Badge>
                        </td>
                        <td className="px-2 py-2">{u.language}</td>
                        <td className="px-2 py-2 text-muted">{fmtDateTime(u.createdAt)}</td>
                        <td className="px-2 py-2">
                          <div className="flex flex-wrap gap-1.5">
                            <button onClick={() => void act({ action: "user_role", id: u.id, role: u.role === "admin" ? "user" : "admin" })} className="focus-ring rounded-lg border border-sky-400/25 px-2 py-1 text-[10px]">
                              {u.role === "admin" ? "Demote" : "Promote"}
                            </button>
                            <button onClick={() => void act({ action: "user_active", id: u.id, isActive: !u.isActive })} className="focus-ring rounded-lg border border-rose-400/25 px-2 py-1 text-[10px] text-rose-200">
                              {u.isActive ? "Disable" : "Enable"}
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>

            <div className="space-y-4">
              <Card>
                <SectionTitle title="Reports by district" subtitle="Geographical distribution of community observations." />
                <MiniBarChart data={data.stats.byDistrict.filter((d) => d.district).slice(0, 10).map((d) => ({ label: d.district ?? "", value: d.c }))} />
              </Card>
              <Card>
                <SectionTitle title="Audit log" subtitle="Security-relevant actions with actor, entity and timestamp." />
                <div className="max-h-72 space-y-1.5 overflow-y-auto text-[11px]">
                  {data.logs.map((l) => (
                    <div key={l.id} className="flex flex-wrap items-center gap-2 border-b border-sky-400/10 pb-1.5">
                      <OriginTag origin={l.actorLabel.includes("@") ? "official" : "model"} authority={l.actorLabel} />
                      <span className="text-slate-200">{l.action}</span>
                      {l.entity ? <span className="text-muted">#{l.entity}</span> : null}
                      <span className="ml-auto text-muted">{fmtDateTime(l.createdAt)}</span>
                    </div>
                  ))}
                  {!data.logs.length ? <EmptyState title="No audit entries yet" message="Sign-ins, moderations and ingestion runs are recorded here." /> : null}
                </div>
              </Card>
            </div>
          </div>
        </>
      ) : null}
    </div>
  );
}
