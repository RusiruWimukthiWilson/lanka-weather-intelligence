"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useApp } from "@/components/location-context";
import { useApi } from "@/components/use-api";
import { Badge, Card, EmptyState, ErrorState, OriginTag, SectionTitle, Spinner, Toggle } from "@/components/ui";
import { LANGS, type Lang } from "@/lib/i18n";
import { DISTRICTS } from "@/lib/lk-geo";
import { fmtDateTime, timeAgo } from "@/lib/format";
import { HAZARD_LABELS } from "@/lib/advisory";

type NotificationRow = {
  id: number;
  title: string;
  body: string;
  category: string;
  severity: string;
  kind: string;
  origin: string;
  source: string;
  link: string | null;
  readAt: string | null;
  createdAt: string;
};

export default function ProfilePage() {
  const { user, refreshUser, lang, setLang, favourites, refreshFavourites, location, reduceMotion, setReduceMotion, unread, setUnread } = useApp();
  const [saving, setSaving] = useState<string | null>(null);
  const [flash, setFlash] = useState<string | null>(null);
  const [pw, setPw] = useState({ currentPassword: "", newPassword: "" });
  const [subs, setSubs] = useState<{ id: number; scopeType: string; scopeLabel: string; categories: string[]; minimumSeverity: string; active: boolean }[]>([]);
  const [newSub, setNewSub] = useState({ district: location.district || "Colombo", categories: ["rain", "wind", "heat", "lightning", "flood", "marine"] as string[], minimumSeverity: "advisory" });

  const notifUrl = user ? "/api/notifications" : null;
  const { data: notifData, error: notifError, loading: notifLoading, reload: reloadNotifs } = useApi<{ notifications: NotificationRow[]; unread: number }>(notifUrl, [user?.id]);

  useEffect(() => {
    if (!notifData) return;
    setUnread(notifData.unread ?? 0);
  }, [notifData, setUnread]);

  useEffect(() => {
    if (!user) {
      setSubs([]);
      return;
    }
    void (async () => {
      const res = await fetch("/api/subscriptions", { cache: "no-store" });
      if (!res.ok) return;
      const body = (await res.json()) as { subscriptions: typeof subs };
      setSubs(body.subscriptions ?? []);
    })();
  }, [user, flash]);

  async function patchProfile(patch: Record<string, unknown>, label: string) {
    setSaving(label);
    setFlash(null);
    try {
      const res = await fetch("/api/profile", { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify(patch) });
      const body = (await res.json()) as { error?: string };
      if (!res.ok) {
        setFlash(body.error ?? "Could not save.");
        if (res.status === 401) window.location.assign("/login?next=/profile");
      } else {
        setFlash("Saved.");
        await refreshUser();
      }
    } finally {
      setSaving(null);
    }
  }

  async function saveCurrentLocation() {
    setSaving("location");
    try {
      const res = await fetch("/api/locations", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ label: location.name, lat: location.lat, lon: location.lon, district: location.district }),
      });
      if (res.status === 401) {
        window.location.assign("/login?next=/profile");
        return;
      }
      await refreshFavourites();
      setFlash(`${location.name} saved to your locations.`);
    } finally {
      setSaving(null);
    }
  }

  async function removeLocation(id: number) {
    await fetch(`/api/locations?id=${id}`, { method: "DELETE" });
    await refreshFavourites();
  }

  async function addSubscription() {
    setSaving("sub");
    try {
      const d = DISTRICTS.find((x) => x.name === newSub.district);
      const res = await fetch("/api/subscriptions", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ scopeType: "district", scopeLabel: newSub.district, district: newSub.district, lat: d?.lat, lon: d?.lon, categories: newSub.categories, minimumSeverity: newSub.minimumSeverity }),
      });
      const body = (await res.json()) as { error?: string };
      if (!res.ok) {
        setFlash(body.error ?? "Could not subscribe.");
        if (res.status === 401) window.location.assign("/login?next=/profile");
        return;
      }
      const list = await fetch("/api/subscriptions", { cache: "no-store" });
      const body2 = (await list.json()) as { subscriptions: typeof subs };
      setSubs(body2.subscriptions ?? []);
      setFlash(`Subscribed to ${newSub.district}.`);
    } finally {
      setSaving(null);
    }
  }

  async function toggleSub(id: number, active: boolean) {
    await fetch("/api/subscriptions", { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ id, active }) });
    setSubs((prev) => prev.map((s) => (s.id === id ? { ...s, active } : s)));
  }

  async function deleteSub(id: number) {
    await fetch(`/api/subscriptions?id=${id}`, { method: "DELETE" });
    setSubs((prev) => prev.filter((s) => s.id !== id));
  }

  async function changePassword(e: React.FormEvent) {
    e.preventDefault();
    setSaving("password");
    try {
      const res = await fetch("/api/auth/password", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(pw) });
      const body = (await res.json()) as { error?: string };
      setFlash(res.ok ? "Password changed." : (body.error ?? "Could not change password."));
      if (res.ok) setPw({ currentPassword: "", newPassword: "" });
    } finally {
      setSaving(null);
    }
  }

  async function markAllRead() {
    await fetch("/api/notifications", { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ all: true }) });
    await reloadNotifs();
    setUnread(0);
  }

  async function runEngine() {
    setSaving("engine");
    try {
      await fetch("/api/notifications", { method: "POST" });
      await reloadNotifs();
      setFlash("Notification engine checked your subscriptions.");
    } finally {
      setSaving(null);
    }
  }

  if (!user) {
    return (
      <div className="space-y-4">
        <Card>
          <SectionTitle title="Your profile" subtitle="Weather browsing works without an account — sign in to unlock saved locations, subscriptions and notifications." />
          <div className="flex flex-wrap gap-2">
            <Link href="/login?next=/profile" className="focus-ring rounded-lg border border-sky-400/30 bg-sky-500/15 px-4 py-2 text-sm text-sky-100">
              Sign in
            </Link>
            <Link href="/register" className="focus-ring rounded-lg border border-sky-400/20 px-4 py-2 text-sm text-slate-200">
              Create an account
            </Link>
          </div>
          <p className="mt-4 text-xs text-muted">
            Current language preference (stored on this device): <span className="text-slate-200">{lang}</span>. You can change it in the header at any time.
          </p>
        </Card>
        <Card>
          <SectionTitle title="Accessibility" />
          <Toggle checked={reduceMotion} onChange={setReduceMotion} label="Reduce animation (also respects your OS setting)" />
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <Card>
        <SectionTitle title={`Signed in as ${user.name}`} subtitle={`${user.email} · role: ${user.role}`} right={user.role === "admin" ? <Link href="/admin" className="focus-ring rounded-lg border border-amber-300/30 bg-amber-400/10 px-3 py-1.5 text-xs text-amber-200">Admin console</Link> : undefined} />
        {flash ? <p className="mb-3 rounded-lg border border-sky-400/20 bg-sky-500/10 px-3 py-2 text-xs text-sky-100">{flash}</p> : null}
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-3">
            <label className="block text-xs text-muted">
              Display name
              <input defaultValue={user.name} onBlur={(e) => void patchProfile({ name: e.target.value }, "name")} className="focus-ring mt-1 w-full rounded-lg border border-sky-400/20 bg-[#0a1733] px-3 py-2 text-sm text-slate-100" />
            </label>
            <div className="text-xs text-muted">
              Language
              <div className="mt-1 flex gap-1.5">
                {LANGS.map((l) => (
                  <button key={l.code} onClick={() => setLang(l.code as Lang)} className={`focus-ring flex-1 rounded-lg px-2 py-2 text-xs ${lang === l.code ? "bg-sky-500/25 text-sky-100" : "border border-sky-400/20 text-slate-300"}`}>
                    {l.native}
                  </button>
                ))}
              </div>
            </div>
            <Toggle checked={reduceMotion} onChange={(v) => { setReduceMotion(v); void patchProfile({ reduceMotion: v }, "motion"); }} label="Reduce animation" />
            <Toggle checked={user.highContrast} onChange={(v) => void patchProfile({ highContrast: v }, "contrast")} label="High-contrast text" />
          </div>

          <div className="glass-soft space-y-3 p-4">
            <p className="text-xs font-medium text-slate-200">Quiet hours (Asia/Colombo)</p>
            <Toggle checked={user.quietHoursEnabled} onChange={(v) => void patchProfile({ quietHoursEnabled: v }, "quiet")} label="Suppress non-critical notifications" />
            <div className="flex items-center gap-2 text-xs text-muted">
              <label>
                From
                <input type="number" min={0} max={23} defaultValue={user.quietHoursStart} onBlur={(e) => void patchProfile({ quietHoursStart: Number(e.target.value) }, "qs")} className="focus-ring ml-1 w-16 rounded-lg border border-sky-400/20 bg-[#0a1733] px-2 py-1 text-xs text-slate-100" />
              </label>
              <label>
                To
                <input type="number" min={0} max={23} defaultValue={user.quietHoursEnd} onBlur={(e) => void patchProfile({ quietHoursEnd: Number(e.target.value) }, "qe")} className="focus-ring ml-1 w-16 rounded-lg border border-sky-400/20 bg-[#0a1733] px-2 py-1 text-xs text-slate-100" />
              </label>
            </div>
            <p className="text-[11px] text-muted">
              In-app notifications are used in this deployment. Firebase Cloud Messaging can be enabled with a server key; the engine, dedupe and quiet-hour logic are already active.
            </p>
          </div>
        </div>
      </Card>

      <Card>
        <SectionTitle
          title="Saved locations"
          subtitle="Quickly switch between the places you monitor."
          right={
            <button onClick={() => void saveCurrentLocation()} disabled={saving !== null} className="focus-ring rounded-lg border border-sky-400/30 bg-sky-500/15 px-3 py-1.5 text-xs text-sky-100 disabled:opacity-50">
              {saving === "location" ? "Saving…" : `Save ${location.name}`}
            </button>
          }
        />
        {favourites.length ? (
          <div className="grid gap-2 md:grid-cols-2 xl:grid-cols-3">
            {favourites.map((f) => (
              <div key={f.id} className="glass-soft flex items-center justify-between gap-2 p-3">
                <div className="min-w-0">
                  <p className="truncate text-sm text-slate-100">
                    {f.label} {f.isDefault ? <Badge color="#34d399">default</Badge> : null}
                  </p>
                  <p className="truncate text-[11px] text-muted">
                    {f.district ?? "—"} · {f.lat.toFixed(2)}, {f.lon.toFixed(2)}
                  </p>
                </div>
                <div className="flex shrink-0 gap-1.5">
                  <button
                    onClick={() => {
                      const params = new URLSearchParams({ lat: String(f.lat), lon: String(f.lon), name: f.label, district: f.district ?? "" });
                      window.location.assign(`/?${params.toString()}`);
                    }}
                    className="focus-ring rounded-lg border border-sky-400/20 px-2 py-1 text-[11px] text-slate-300"
                  >
                    View
                  </button>
                  <button onClick={() => void removeLocation(f.id)} className="focus-ring rounded-lg border border-rose-400/25 px-2 py-1 text-[11px] text-rose-200">
                    Remove
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <EmptyState title="No saved locations" message="Save your home town and workplace to switch quickly from the header search." />
        )}
      </Card>

      <Card>
        <SectionTitle title="Notification subscriptions" subtitle="Choose districts, hazard categories and the minimum severity that should reach you." />
        <div className="mb-4 flex flex-wrap items-end gap-2">
          <label className="text-xs text-muted">
            District
            <select value={newSub.district} onChange={(e) => setNewSub({ ...newSub, district: e.target.value })} className="focus-ring mt-1 block w-44 rounded-lg border border-sky-400/20 bg-[#0a1733] px-2.5 py-2 text-xs text-slate-100">
              {DISTRICTS.map((d) => (
                <option key={d.name} value={d.name}>
                  {d.name}
                </option>
              ))}
            </select>
          </label>
          <label className="text-xs text-muted">
            Minimum severity
            <select value={newSub.minimumSeverity} onChange={(e) => setNewSub({ ...newSub, minimumSeverity: e.target.value })} className="focus-ring mt-1 block w-36 rounded-lg border border-sky-400/20 bg-[#0a1733] px-2.5 py-2 text-xs text-slate-100">
              <option value="advisory">Advisory+</option>
              <option value="watch">Watch+</option>
              <option value="warning">Warning only</option>
            </select>
          </label>
          <div className="flex flex-wrap gap-1.5">
            {Object.entries(HAZARD_LABELS).map(([key, label]) => (
              <button
                key={key}
                onClick={() => setNewSub((s) => ({ ...s, categories: s.categories.includes(key) ? s.categories.filter((c) => c !== key) : [...s.categories, key] }))}
                className={`focus-ring rounded-full px-2.5 py-1.5 text-[11px] ${newSub.categories.includes(key) ? "bg-sky-500/25 text-sky-100" : "border border-sky-400/20 text-slate-300"}`}
              >
                {label}
              </button>
            ))}
          </div>
          <button onClick={() => void addSubscription()} disabled={saving !== null} className="focus-ring rounded-lg bg-gradient-to-r from-sky-500 to-violet-500 px-3 py-2 text-xs font-medium text-white disabled:opacity-50">
            Subscribe
          </button>
        </div>
        {subs.length ? (
          <div className="space-y-2">
            {subs.map((s) => (
              <div key={s.id} className="glass-soft flex flex-wrap items-center gap-3 p-3">
                <div className="min-w-[150px]">
                  <p className="text-sm text-slate-100">{s.scopeLabel}</p>
                  <p className="text-[11px] text-muted">{s.minimumSeverity}+ · {s.categories.length} categories</p>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {s.categories.map((c) => (
                    <Badge key={c} color="#38bdf8">
                      {HAZARD_LABELS[c] ?? c}
                    </Badge>
                  ))}
                </div>
                <div className="ml-auto flex items-center gap-2">
                  <Toggle checked={s.active} onChange={(v) => void toggleSub(s.id, v)} label={s.active ? "Active" : "Paused"} />
                  <button onClick={() => void deleteSub(s.id)} className="focus-ring rounded-lg border border-rose-400/25 px-2 py-1 text-[11px] text-rose-200">
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <EmptyState title="No subscriptions yet" message="Subscribe to at least one district, then run the engine to build your notification feed." />
        )}
        <button onClick={() => void runEngine()} disabled={saving !== null} className="focus-ring mt-3 rounded-lg border border-sky-400/30 bg-sky-500/15 px-3 py-2 text-xs text-sky-100">
          {saving === "engine" ? "Checking…" : "Check my subscriptions now"}
        </button>
      </Card>

      <Card>
        <div id="notifications" />
        <SectionTitle
          title={`Notification history ${unread ? `(${unread} unread)` : ""}`}
          subtitle="Every advisory delivered to you is stored here with its origin label."
          right={
            <button onClick={() => void markAllRead()} className="focus-ring rounded-lg border border-sky-400/25 px-3 py-1.5 text-xs text-slate-200">
              Mark all read
            </button>
          }
        />
        {notifError ? <ErrorState title="Could not load notifications" message={notifError} onRetry={reloadNotifs} /> : null}
        {notifLoading ? <Spinner label="Loading notification history…" /> : null}
        {notifData && !notifData.notifications.length ? <EmptyState title="Nothing yet" message="Run the engine after subscribing, or wait for the next scheduled check." /> : null}
        <div className="space-y-2">
          {(notifData?.notifications ?? []).map((n) => (
            <div key={n.id} className={`glass-soft p-3 ${n.readAt ? "opacity-70" : ""}`}>
              <div className="flex flex-wrap items-center gap-2">
                <OriginTag origin={n.origin} authority={n.source} />
                <Badge color={n.severity === "warning" ? "#f43f5e" : n.severity === "watch" ? "#f97316" : "#eab308"}>{HAZARD_LABELS[n.category] ?? n.category}</Badge>
                {!n.readAt ? <Badge color="#38bdf8">new</Badge> : null}
                <span className="ml-auto text-[10px] text-muted">{timeAgo(n.createdAt)}</span>
              </div>
              <p className="mt-1.5 text-sm text-slate-100">{n.title}</p>
              <p className="mt-1 text-xs text-muted">{n.body}</p>
              <p className="mt-1 text-[10px] text-muted">Delivered {fmtDateTime(n.createdAt)}</p>
            </div>
          ))}
        </div>
      </Card>

      <Card>
        <SectionTitle title="Password" subtitle="Passwords are stored as salted scrypt hashes; sessions are httpOnly cookies." />
        <form onSubmit={changePassword} className="flex flex-wrap items-end gap-2">
          <label className="text-xs text-muted">
            Current password
            <input type="password" value={pw.currentPassword} onChange={(e) => setPw({ ...pw, currentPassword: e.target.value })} className="focus-ring mt-1 block w-48 rounded-lg border border-sky-400/20 bg-[#0a1733] px-3 py-2 text-sm text-slate-100" />
          </label>
          <label className="text-xs text-muted">
            New password
            <input type="password" value={pw.newPassword} onChange={(e) => setPw({ ...pw, newPassword: e.target.value })} className="focus-ring mt-1 block w-48 rounded-lg border border-sky-400/20 bg-[#0a1733] px-3 py-2 text-sm text-slate-100" />
          </label>
          <button type="submit" disabled={saving !== null} className="focus-ring rounded-lg border border-sky-400/30 bg-sky-500/15 px-3 py-2 text-xs text-sky-100">
            Change password
          </button>
        </form>
        <button
          onClick={async () => {
            await fetch("/api/auth/logout", { method: "POST" });
            await refreshUser();
            window.location.assign("/");
          }}
          className="focus-ring mt-3 rounded-lg border border-rose-400/25 px-3 py-2 text-xs text-rose-200"
        >
          Sign out
        </button>
      </Card>
    </div>
  );
}
