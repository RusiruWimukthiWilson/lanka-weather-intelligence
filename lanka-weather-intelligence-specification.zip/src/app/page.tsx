"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { useApp } from "@/components/location-context";
import { useApi } from "@/components/use-api";
import { WeatherIcon } from "@/components/weather-icon";
import { Badge, Card, ErrorState, EmptyState, OriginTag, ProvenanceBadge, SectionTitle, Spinner, Stat } from "@/components/ui";
import { RainChart, TempTrendChart } from "@/components/charts";
import type { WeatherResponse } from "@/lib/types";
import { aqiBand, beaufortLabel, compassDirection, describeCode, groupOf, intensityFromMm, uvCategory } from "@/lib/weather/codes";
import { fmtNum, fmtTemp, fmtTime, fmtDay, timeAgo } from "@/lib/format";
import { HAZARD_LABELS } from "@/lib/advisory";
import { t } from "@/lib/i18n";

export default function DashboardPage() {
  const { location, lang, user } = useApp();
  const url = `/api/weather?lat=${location.lat}&lon=${location.lon}&name=${encodeURIComponent(location.name)}&district=${encodeURIComponent(location.district)}`;
  const { data, error, loading, reload, loadedAt } = useApi<WeatherResponse>(url, [location.lat, location.lon, location.name]);

  const [showExtended, setShowExtended] = useState(false);
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 60000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (typeof document === "undefined" || !data?.current) return;
    const g = groupOf(data.current.weatherCode);
    const bg = g === "thunderstorm" ? "storm" : ["rain", "showers", "drizzle"].includes(g) ? "rain" : ["clear", "mainly-clear"].includes(g) ? "clear" : "cloud";
    document.documentElement.setAttribute("data-weather-bg", bg);
  }, [data]);

  const hourlyNext = useMemo(() => {
    if (!data) return [];
    return data.hourly.filter((h) => new Date(h.time).getTime() >= now - 3600 * 1000).slice(0, 24);
  }, [data, now]);

  const currentVisibility = useMemo(() => {
    if (!data?.hourly.length) return null;
    const upcoming = data.hourly.find((h) => new Date(h.time).getTime() >= now - 3600 * 1000);
    return upcoming?.visibility ?? null;
  }, [data, now]);

  const rainNext6h = useMemo(() => hourlyNext.slice(0, 6).reduce((a, h) => a + (h.precipitation ?? 0), 0), [hourlyNext]);
  const maxChance6h = useMemo(() => hourlyNext.slice(0, 6).reduce((a, h) => Math.max(a, h.precipitationProbability ?? 0), 0), [hourlyNext]);

  if (error) {
    return (
      <div className="space-y-4">
        <ErrorState
          title="Live weather service unreachable"
          message={`${error} No substitute or simulated readings are shown — Lanka Weather Intelligence never displays invented weather data.`}
          onRetry={reload}
        />
        <Card>
          <SectionTitle title="What you can still do" />
          <ul className="list-disc space-y-1 pl-5 text-sm text-muted">
            <li>Check the <Link className="text-sky-300 underline" href="/alerts">Alerts</Link> section, which also serves cached advisory records from the database.</li>
            <li>Browse saved locations and preferences in <Link className="text-sky-300 underline" href="/profile">Profile</Link>.</li>
            <li>Ask the <Link className="text-sky-300 underline" href="/assistant">AI assistant</Link> — it will tell you honestly when it cannot verify conditions.</li>
          </ul>
        </Card>
      </div>
    );
  }

  if (!data || loading) {
    return (
      <div className="space-y-4">
        <Card><Spinner label={`Fetching live conditions for ${location.name}…`} /></Card>
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="glass-soft h-24 animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  const cur = data.current;
  const uv = data.airQuality?.uvIndex ?? data.daily[0]?.uvIndexMax ?? null;
  const uvCat = uvCategory(uv);
  const aq = data.airQuality;
  const aqBandValue = aqiBand(aq?.europeanAqi ?? null);
  const intensity = intensityFromMm(rainNext6h / 6);
  const bg = groupOf(cur?.weatherCode ?? 3);

  return (
    <div className="space-y-5">
      {/* Hero */}
      <Card className="relative overflow-hidden">
        <div className="pointer-events-none absolute -right-10 -top-16 h-56 w-56 rounded-full bg-gradient-to-br from-sky-400/20 to-violet-500/10 blur-2xl" />
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="min-w-0">
            <p className="text-[11px] uppercase tracking-[0.18em] text-muted">{t(lang, "nav_home")} · live conditions</p>
            <h1 className="mt-1 truncate text-2xl font-semibold text-slate-50 sm:text-3xl">
              {data.location.name}
              <span className="ml-2 text-sm font-normal text-muted">
                {data.location.district ? `${data.location.district} District` : "Sri Lanka"}
                {data.location.province ? `, ${data.location.province} Province` : ""}
              </span>
            </h1>
            <p className="mt-1 text-sm text-muted">
              {describeCode(cur?.weatherCode ?? 3, cur?.isDay ?? true, lang)} · {fmtNum(data.location.elevation, 0, "m elevation")} · local time{" "}
              {fmtTime(cur?.time)}
            </p>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              {data.advisories.length ? (
                data.advisories.slice(0, 2).map((a) => (
                  <Link key={a.dedupeKey} href="/alerts" className="focus-ring">
                    <Badge color={a.severity === "warning" ? "#f43f5e" : a.severity === "watch" ? "#f97316" : "#eab308"}>
                      {HAZARD_LABELS[a.hazard] ?? a.hazard} · {a.severity}
                    </Badge>
                  </Link>
                ))
              ) : (
                <Badge color="#34d399">No model screening thresholds crossed</Badge>
              )}
              <Badge color={cur?.isDay ? "#38bdf8" : "#a78bfa"}>{cur?.isDay ? "Daytime" : "Night"}</Badge>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <WeatherIcon code={cur?.weatherCode} isDay={cur?.isDay ?? true} size={104} />
            <div>
              <p className="text-5xl font-semibold tracking-tight text-slate-50">{fmtTemp(cur?.temperature)}</p>
              <p className="mt-1 text-sm text-muted">
                {t(lang, "feels_like")} {fmtTemp(cur?.apparentTemperature)}
              </p>
              <p className="text-[11px] text-muted">
                {intensity.label} rain next 6 h · {fmtNum(rainNext6h, 1, "mm")} · peak chance {fmtNum(maxChance6h, 0, "%")}
              </p>
            </div>
          </div>
        </div>
      </Card>

      {/* Stat grid */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-6">
        <Stat label={t(lang, "humidity")} value={fmtNum(cur?.humidity, 0)} unit="%" hint={cur?.dewPoint !== null && cur?.dewPoint !== undefined ? `Dew point ${fmtTemp(cur.dewPoint)}` : undefined} />
        <Stat label={t(lang, "wind")} value={fmtNum(cur?.windSpeed, 0)} unit="km/h" hint={`${compassDirection(cur?.windDirection)} · ${beaufortLabel(cur?.windSpeed ?? 0)} · gusts ${fmtNum(cur?.windGust, 0, "km/h")}`} />
        <Stat label={t(lang, "pressure")} value={fmtNum(cur?.pressure, 0)} unit="hPa" hint="Mean sea level pressure" />
        <Stat
          label={t(lang, "uv_index")}
          value={fmtNum(uv, 1)}
          tone={uv !== null && uv >= 8 ? "bad" : uv !== null && uv >= 6 ? "warn" : "good"}
          hint={`${uvCat.label} — ${uvCat.advice}`}
        />
        <Stat
          label={t(lang, "visibility")}
          value={currentVisibility !== null ? (currentVisibility / 1000).toFixed(1) : "—"}
          unit="km"
          hint={currentVisibility !== null && currentVisibility < 4000 ? "Reduced visibility — drive with headlights on" : "Clear line of sight"}
        />
        <Stat label={t(lang, "rain_chance")} value={fmtNum(maxChance6h, 0)} unit="%" hint={`Modelled ${fmtNum(rainNext6h, 1, "mm")} in next 6 h`} />
      </div>

      {/* Air quality + sun times */}
      <div className="grid gap-4 lg:grid-cols-3">
        <Card>
          <SectionTitle title={t(lang, "air_quality")} subtitle={aq?.available ? "CAMS global composition analysis" : "Not available for this point right now"} />
          {aq?.available ? (
            <>
              <div className="flex items-end gap-3">
                <p className="text-3xl font-semibold" style={{ color: aqBandValue.color }}>
                  {Math.round(aq.europeanAqi ?? 0)}
                </p>
                <div className="pb-1">
                  <p className="text-sm font-medium" style={{ color: aqBandValue.color }}>{aqBandValue.label}</p>
                  <p className="text-[11px] text-muted">European AQI · US AQI {fmtNum(aq.usAqi, 0)}</p>
                </div>
              </div>
              <p className="mt-2 text-xs text-muted">{aqBandValue.advice}</p>
              <div className="mt-3 grid grid-cols-3 gap-2 text-center text-[11px]">
                {[
                  { k: "PM2.5", v: aq.pm2_5, u: "µg/m³" },
                  { k: "PM10", v: aq.pm10, u: "µg/m³" },
                  { k: "O₃", v: aq.ozone, u: "µg/m³" },
                  { k: "NO₂", v: aq.no2, u: "µg/m³" },
                  { k: "SO₂", v: aq.so2, u: "µg/m³" },
                  { k: "Dust", v: aq.dust, u: "µg/m³" },
                ].map((m) => (
                  <div key={m.k} className="glass-soft px-2 py-2">
                    <p className="text-muted">{m.k}</p>
                    <p className="mt-0.5 font-medium text-slate-100">{fmtNum(m.v as number | null, 1)}</p>
                    <p className="text-[9px] text-muted">{m.u}</p>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <EmptyState title="Air-quality readings unavailable" message={aq?.reason ?? "The CAMS service did not return data for this coordinate. Nothing is estimated in its place."} />
          )}
        </Card>

        <Card>
          <SectionTitle title="Sun & daylight" subtitle="Astronomical values for the selected coordinate" />
          <div className="grid grid-cols-2 gap-3">
            <Stat label={t(lang, "sunrise")} value={fmtTime(data.daily[0]?.sunrise)} />
            <Stat label={t(lang, "sunset")} value={fmtTime(data.daily[0]?.sunset)} />
            <Stat label="Daylight" value={data.daily[0]?.daylightSeconds ? `${Math.floor((data.daily[0].daylightSeconds ?? 0) / 3600)}h ${Math.round((((data.daily[0].daylightSeconds ?? 0) % 3600) / 60))}m` : "—"} />
            <Stat label="Cloud cover" value={fmtNum(cur?.cloudCover, 0)} unit="%" />
          </div>
          <p className="mt-3 text-[11px] text-muted">
            Daylight length changes by roughly a minute per day at Sri Lanka&apos;s latitude, so sunrise and sunset stay close to 6 am / 6 pm local time all year.
          </p>
        </Card>

        <Card>
          <SectionTitle title="Condition explanation" subtitle="What the numbers mean for you today" />
          <p className="text-sm leading-relaxed text-slate-200">
            {bg === "clear" || bg === "mainly-clear"
              ? `Skies are largely clear over ${data.location.name} with ${fmtNum(cur?.cloudCover, 0, "%")} cloud cover. UV peaks around midday — ${uvCat.advice.toLowerCase()}`
              : bg === "thunderstorm"
                ? `Thunderstorm conditions are reported or modelled. Expect sudden downpours, gusty outflow winds and lightning risk. Move indoors at the first thunder and unplug sensitive equipment.`
                : bg === "rain" || bg === "showers" || bg === "drizzle"
                  ? `Showery weather is affecting ${data.location.name}. About ${fmtNum(rainNext6h, 1, "mm")} is modelled over the next 6 hours (${intensity.label.toLowerCase()} intensity), with a peak hourly chance of ${fmtNum(maxChance6h, 0, "%")}. Roads may stay wet and visibility can drop in heavier bursts.`
                  : `Cloud cover is around ${fmtNum(cur?.cloudCover, 0, "%")} with ${fmtNum(cur?.humidity, 0, "%")} humidity. Showers cannot be ruled out, but no significant rainfall is modelled in the next few hours.`}
          </p>
          <p className="mt-2 text-[11px] text-muted">
            Feels-like {fmtTemp(cur?.apparentTemperature)} reflects humidity and wind on your skin; it can differ from the measured {fmtTemp(cur?.temperature)} air temperature.
          </p>
          {user ? (
            <Link href="/profile" className="focus-ring mt-3 inline-block rounded-lg border border-sky-400/30 bg-sky-500/10 px-3 py-1.5 text-xs text-sky-200">
              Manage saved locations & notifications
            </Link>
          ) : (
            <Link href="/register" className="focus-ring mt-3 inline-block rounded-lg border border-sky-400/30 bg-sky-500/10 px-3 py-1.5 text-xs text-sky-200">
              Create a free account for alerts & saved places
            </Link>
          )}
        </Card>
      </div>

      {/* Advisory strip */}
      {data.advisories.length ? (
        <Card>
          <SectionTitle
            title="Impact-based screening for this area"
            subtitle="Automatically generated from live model values. Not an official warning — confirm with DMC / Met Department."
            right={<Link href="/alerts" className="focus-ring text-xs text-sky-300 underline">All alerts</Link>}
          />
          <div className="grid gap-3 md:grid-cols-2">
            {data.advisories.map((a) => (
              <div key={a.dedupeKey} className="glass-soft p-4">
                <div className="flex flex-wrap items-center gap-2">
                  <OriginTag origin={a.origin} authority={a.authority} />
                  <Badge color={a.severity === "warning" ? "#f43f5e" : a.severity === "watch" ? "#f97316" : "#eab308"}>{HAZARD_LABELS[a.hazard] ?? a.hazard}</Badge>
                </div>
                <p className="mt-2 text-sm font-medium text-slate-100">{a.title}</p>
                <p className="mt-1 text-xs leading-relaxed text-muted">{a.summary}</p>
                <ul className="mt-2 list-disc space-y-1 pl-4 text-[11px] text-slate-300">
                  {a.impacts.slice(0, 2).map((imp) => (
                    <li key={imp}>{imp}</li>
                  ))}
                </ul>
                <p className="mt-2 text-[10px] text-muted">Evidence: {Object.entries(a.evidence).map(([k, v]) => `${k}=${String(v)}`).join(" · ")} · valid until {fmtTime(a.expiresAt)}</p>
              </div>
            ))}
          </div>
        </Card>
      ) : null}

      {/* 24h timeline */}
      <Card>
        <SectionTitle
          title={t(lang, "next_24h")}
          subtitle="Hourly model output — temperature, rain chance and condition. Scroll sideways for the full day."
          right={<ProvenanceBadge provider={data.provenance.provider} model={data.provenance.model} fetchedAt={loadedAt ?? data.provenance.fetchedAt} stale={data.provenance.stale} degraded={data.provenance.degraded} />}
        />
        <div className="no-scrollbar -mx-1 flex gap-2.5 overflow-x-auto px-1 pb-2">
          {hourlyNext.map((h) => {
            const rainChance = h.precipitationProbability ?? 0;
            return (
              <div key={h.time} className="glass-soft w-[104px] shrink-0 p-3 text-center">
                <p className="text-[11px] text-muted">{fmtDay(h.time) === fmtDay(new Date()) ? fmtTime(h.time) : `${fmtDay(h.time).split(" ")[0]} ${fmtTime(h.time)}`}</p>
                <div className="my-1.5 flex justify-center">
                  <WeatherIcon code={h.weatherCode} isDay={h.isDay} size={40} />
                </div>
                <p className="text-sm font-semibold text-slate-50">{fmtTemp(h.temperature)}</p>
                <p className="mt-0.5 text-[10px] text-sky-300">{fmtNum(rainChance, 0, "%")}</p>
                <p className="text-[10px] text-muted">{fmtNum(h.precipitation, 1, "mm")}</p>
              </div>
            );
          })}
        </div>
        <div className="mt-4 grid gap-4 lg:grid-cols-2">
          <div>
            <p className="mb-1 text-xs text-muted">Temperature trend (°C) — measured-style model output</p>
            <TempTrendChart
              data={hourlyNext.map((h) => ({ label: fmtTime(h.time), temperature: h.temperature, feelsLike: h.apparentTemperature }))}
            />
          </div>
          <div>
            <p className="mb-1 text-xs text-muted">Rain chance (%) and forecast amount (mm)</p>
            <RainChart data={hourlyNext.map((h) => ({ label: fmtTime(h.time), probability: h.precipitationProbability, mm: h.precipitation }))} />
          </div>
        </div>
      </Card>

      {/* 7-day */}
      <Card>
        <SectionTitle
          title={t(lang, "next_7_days")}
          subtitle="Daily summaries with sunrise, sunset, rainfall totals and wind. Tap a day to expand."
          right={
            <button onClick={() => setShowExtended((v) => !v)} className="focus-ring rounded-lg border border-sky-400/30 bg-sky-500/10 px-3 py-1.5 text-xs text-sky-200">
              {showExtended ? "Show 7 days" : `Show ${t(lang, "extended")}`}
            </button>
          }
        />
        <div className="space-y-2">
          {data.daily.slice(0, showExtended ? 14 : 7).map((d, idx) => (
            <details key={d.date} className="glass-soft group px-4 py-3" open={idx === 0}>
              <summary className="flex cursor-pointer list-none flex-wrap items-center gap-3">
                <span className="w-24 text-sm font-medium text-slate-100">{idx === 0 ? "Today" : fmtDay(d.date, "short")}</span>
                <WeatherIcon code={d.weatherCode} isDay size={34} />
                <span className="text-sm text-slate-100">
                  {fmtTemp(d.tempMax)} <span className="text-muted">/ {fmtTemp(d.tempMin)}</span>
                </span>
                <span className="text-xs text-sky-300">{fmtNum(d.precipitationProbabilityMax, 0, "%")} rain</span>
                <span className="text-xs text-muted">{fmtNum(d.precipitationSum, 1, "mm")}</span>
                <span className="ml-auto text-[11px] text-muted">{describeCode(d.weatherCode ?? 3, true, lang)}</span>
              </summary>
              <div className="mt-3 grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-6">
                <Stat label="Rain hours" value={fmtNum(d.precipitationHours, 0)} unit="h" />
                <Stat label="Max wind" value={fmtNum(d.windSpeedMax, 0)} unit="km/h" hint={`Gusts ${fmtNum(d.windGustsMax, 0, "km/h")}`} />
                <Stat label="Wind dir" value={compassDirection(d.windDirectionDominant)} />
                <Stat label="UV max" value={fmtNum(d.uvIndexMax, 1)} hint={uvCategory(d.uvIndexMax).label} />
                <Stat label={t(lang, "sunrise")} value={fmtTime(d.sunrise)} />
                <Stat label={t(lang, "sunset")} value={fmtTime(d.sunset)} />
              </div>
              <p className="mt-2 text-[11px] text-muted">
                {intensityFromMm(d.precipitationSum ?? 0).label} daily rainfall total · {beaufortLabel(d.windSpeedMax ?? 0)} winds · {describeCode(d.weatherCode ?? 3, true, lang)}
              </p>
            </details>
          ))}
        </div>
        <p className="mt-3 text-[11px] text-muted">
          Forecast confidence decreases with lead time. Days 1–3 are the most reliable; beyond day 7 treat values as guidance only.
        </p>
      </Card>

      <Card>
        <ProvenanceBadge provider={`${data.provenance.provider} · ${data.provenance.attribution}`} model={data.provenance.model} fetchedAt={loadedAt ?? data.provenance.fetchedAt} stale={data.provenance.stale} degraded={data.provenance.degraded} />
        <p className="mt-2 text-[11px] text-muted">
          Values shown are model output for {data.location.lat.toFixed(3)}°N, {data.location.lon.toFixed(3)}°E (source grid), last retrieved {timeAgo(loadedAt ?? data.provenance.fetchedAt)}.
          Observations from the Sri Lanka Department of Meteorology station network are not published through an open API, so this platform uses model data and labels it as such.
        </p>
      </Card>
    </div>
  );
}
