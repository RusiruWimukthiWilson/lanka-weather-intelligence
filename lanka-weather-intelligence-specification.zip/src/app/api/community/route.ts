import { db } from "@/db";
import { communityReports, reportVotes } from "@/db/schema";
import { and, desc, eq, sql } from "drizzle-orm";
import { audit, getSessionUser, requireUser } from "@/lib/auth";
import { nearestDistrict } from "@/lib/lk-geo";

export const dynamic = "force-dynamic";

export const CATEGORIES = [
  { id: "rain_started", label: "Rain starting", en: "Rain has started", si: "වැසි ඇරඹුණි", ta: "மழை தொடங்கியது" },
  { id: "heavy_rain", label: "Heavy rainfall", en: "Heavy rainfall", si: "බරපතල වැසි", ta: "கனமழை" },
  { id: "flood", label: "Flooding", en: "Flooding / water on the road", si: "ගංවතුර / මාර්ගයේ ජලය", ta: "வெள்ளம் / சாலையில் நீர்" },
  { id: "waterlogging", label: "Waterlogging", en: "Waterlogging", si: "ජල තැම්බීම", ta: "நீர் தேங்குதல்" },
  { id: "strong_wind", label: "Strong winds", en: "Strong winds", si: "දරුණු සුළං", ta: "வலுவான காற்று" },
  { id: "heat", label: "Extreme heat", en: "Extreme heat", si: "දරුණු තාපය", ta: "அதிக வெப்பம்" },
  { id: "other", label: "Other observation", en: "Other observation", si: "වෙනත් නිරීක්ෂණයක්", ta: "பிற கவனிப்பு" },
];

export async function GET(request: Request) {
  const url = new URL(request.url);
  const district = url.searchParams.get("district");
  const category = url.searchParams.get("category");
  const status = url.searchParams.get("status");
  const limit = Math.min(120, Number(url.searchParams.get("limit") ?? 60) || 60);

  const conditions = [];
  if (district) conditions.push(eq(communityReports.district, district));
  if (category) conditions.push(eq(communityReports.category, category));
  if (status) conditions.push(eq(communityReports.status, status));

  const rows = await db
    .select()
    .from(communityReports)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(communityReports.createdAt))
    .limit(limit);

  const stats = await db
    .select({ category: communityReports.category, count: sql<number>`count(*)::int` })
    .from(communityReports)
    .groupBy(communityReports.category);

  return Response.json({
    categories: CATEGORIES,
    reports: rows.map((r) => ({ ...r, photoData: r.photoData ? "present" : null, hasPhoto: Boolean(r.photoData) })),
    stats,
    notice: "Community observations are unverified citizen reports. They are moderated for spam and abuse but are never treated as official weather data.",
  });
}

export async function POST(request: Request) {
  const user = await getSessionUser();
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const category = typeof body.category === "string" ? body.category : "";
  const lat = Number(body.lat);
  const lon = Number(body.lon);
  const placeLabel = typeof body.placeLabel === "string" ? body.placeLabel.trim() : "";
  const note = typeof body.note === "string" ? body.note.trim().slice(0, 800) : "";
  const intensity = ["light", "moderate", "heavy", "extreme"].includes(String(body.intensity)) ? String(body.intensity) : "moderate";
  const photoData = typeof body.photoData === "string" && body.photoData.startsWith("data:image/") ? body.photoData : null;

  if (!CATEGORIES.some((c) => c.id === category)) return Response.json({ error: "Please choose a valid report category." }, { status: 400 });
  if (!Number.isFinite(lat) || !Number.isFinite(lon)) return Response.json({ error: "A valid location is required — use “Use my location” or pick a place." }, { status: 400 });
  if (photoData && photoData.length > 1_400_000) return Response.json({ error: "Photo is too large. Please attach an image under 1 MB." }, { status: 413 });

  const district = nearestDistrict(lat, lon);
  const credibility = user ? 60 : 45;

  const inserted = await db
    .insert(communityReports)
    .values({
      userId: user?.id ?? null,
      reporterName: user?.name ?? (typeof body.reporterName === "string" && body.reporterName.trim() ? body.reporterName.trim().slice(0, 60) : "Anonymous observer"),
      category,
      intensity,
      note,
      placeLabel: placeLabel || district.capital,
      district: district.name,
      lat,
      lon,
      photoData,
      credibility,
      status: "pending",
    })
    .returning({ id: communityReports.id, createdAt: communityReports.createdAt });

  await audit({
    userId: user?.id ?? null,
    actorLabel: user?.email ?? "anonymous",
    action: "community.report_submitted",
    entity: String(inserted[0].id),
    meta: { category, district: district.name },
  });

  return Response.json({ ok: true, id: inserted[0].id, district: district.name, verification: "pending" }, { status: 201 });
}

/** Credibility voting: signed-in users can corroborate or dispute a report. */
export async function PUT(request: Request) {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const id = Number(body.id);
  const value = Number(body.value) > 0 ? 1 : -1;
  if (!Number.isFinite(id)) return Response.json({ error: "id is required" }, { status: 400 });

  const existing = await db
    .select()
    .from(reportVotes)
    .where(and(eq(reportVotes.reportId, id), eq(reportVotes.userId, auth.user.id)))
    .limit(1);

  if (existing.length) {
    if (existing[0].value === value) {
      await db.delete(reportVotes).where(eq(reportVotes.id, existing[0].id));
    } else {
      await db.update(reportVotes).set({ value }).where(eq(reportVotes.id, existing[0].id));
    }
  } else {
    await db.insert(reportVotes).values({ reportId: id, userId: auth.user.id, value });
  }

  const tally = await db
    .select({ up: sql<number>`coalesce(sum(case when ${reportVotes.value} > 0 then 1 else 0 end),0)::int`, down: sql<number>`coalesce(sum(case when ${reportVotes.value} < 0 then 1 else 0 end),0)::int` })
    .from(reportVotes)
    .where(eq(reportVotes.reportId, id));
  const up = tally[0]?.up ?? 0;
  const down = tally[0]?.down ?? 0;
  const credibility = Math.max(0, Math.min(100, 50 + up * 10 - down * 12));
  await db
    .update(communityReports)
    .set({ upvotes: up, downvotes: down, credibility })
    .where(eq(communityReports.id, id));

  return Response.json({ ok: true, upvotes: up, downvotes: down, credibility });
}
