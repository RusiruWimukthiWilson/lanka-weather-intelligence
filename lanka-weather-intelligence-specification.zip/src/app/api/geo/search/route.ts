import { searchPlaces, DISTRICTS, PROVINCES, PLACES, nearestDistrict } from "@/lib/lk-geo";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const q = url.searchParams.get("q")?.trim() ?? "";
  const lat = Number(url.searchParams.get("lat"));
  const lon = Number(url.searchParams.get("lon"));

  if (url.searchParams.get("mode") === "reverse") {
    if (!Number.isFinite(lat) || !Number.isFinite(lon)) {
      return Response.json({ error: "lat and lon are required for reverse lookup" }, { status: 400 });
    }
    const d = nearestDistrict(lat, lon);
    return Response.json({
      results: [
        {
          name: d.capital,
          type: "district",
          district: d.name,
          province: d.province,
          lat,
          lon,
          note: `Nearest modelled district centre: ${d.capital} (${d.name} District)`,
        },
      ],
    });
  }

  const places = searchPlaces(q, 10).map((p) => ({
    name: p.name,
    type: p.kind === "city" ? "city" : "town",
    district: p.district,
    province: p.province,
    lat: p.lat,
    lon: p.lon,
  }));

  const districtMatches = DISTRICTS.filter((d) => d.name.toLowerCase().includes(q.toLowerCase())).map((d) => ({
    name: d.name,
    type: "district",
    district: d.name,
    province: d.province,
    lat: d.lat,
    lon: d.lon,
  }));

  const provinceMatches = PROVINCES.filter((p) => p.name.toLowerCase().includes(q.toLowerCase())).map((p) => ({
    name: `${p.name} Province`,
    type: "province",
    district: DISTRICTS.find((d) => d.province === p.name)?.name ?? "",
    province: p.name,
    lat: PLACES.find((pl) => pl.name === p.capital)?.lat ?? 7.9,
    lon: PLACES.find((pl) => pl.name === p.capital)?.lon ?? 80.7,
  }));

  const seen = new Set<string>();
  const results = [...places, ...districtMatches, ...provinceMatches].filter((r) => {
    const key = `${r.name}|${r.type}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  return Response.json({ query: q, count: results.length, results: results.slice(0, 12) });
}
