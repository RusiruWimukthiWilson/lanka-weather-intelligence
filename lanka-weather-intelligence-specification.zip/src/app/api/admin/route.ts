import { db } from "@/db";
import { auditLogs, communityReports, ingestRuns, integrationStatus, users, assistantMessages, subscriptions, notifications } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";
import { audit, requireAdmin } from "@/lib/auth";
import { runAlertIngestion } from "@/lib/alerts-service";
import { runNotificationEngine } from "@/lib/notification-engine";

export const dynamic = "force-dynamic";

export async function GET() {
  const auth = await requireAdmin();
  if ("error" in auth) return auth.error;

  const [
    userRows,
    reports,
    integrations,
    runs,
    logs,
    userCount,
    reportCount,
    pendingCount,
    messageCount,
    subCount,
    notifCount,
    districtStats,
  ] = await Promise.all([
    db.select({ id: users.id, email: users.email, name: users.name, role: users.role, language: users.language, isActive: users.isActive, createdAt: users.createdAt }).from(users).orderBy(desc(users.createdAt)).limit(50),
    db.select().from(communityReports).orderBy(desc(communityReports.createdAt)).limit(40),
    db.select().from(integrationStatus).orderBy(integrationStatus.provider),
    db.select().from(ingestRuns).orderBy(desc(ingestRuns.startedAt)).limit(10),
    db.select().from(auditLogs).orderBy(desc(auditLogs.createdAt)).limit(40),
    db.select({ c: sql<number>`count(*)::int` }).from(users),
    db.select({ c: sql<number>`count(*)::int` }).from(communityReports),
    db.select({ c: sql<number>`count(*)::int` }).from(communityReports).where(eq(communityReports.status, "pending")),
    db.select({ c: sql<number>`count(*)::int` }).from(assistantMessages),
    db.select({ c: sql<number>`count(*)::int` }).from(subscriptions),
    db.select({ c: sql<number>`count(*)::int` }).from(notifications),
    db.select({ district: communityReports.district, c: sql<number>`count(*)::int` }).from(communityReports).groupBy(communityReports.district),
  ]);

  return Response.json({
    users: userRows,
    reports,
    integrations,
    runs,
    logs,
    stats: {
      users: userCount[0]?.c ?? 0,
      reports: reportCount[0]?.c ?? 0,
      pendingReports: pendingCount[0]?.c ?? 0,
      assistantMessages: messageCount[0]?.c ?? 0,
      subscriptions: subCount[0]?.c ?? 0,
      notifications: notifCount[0]?.c ?? 0,
      byDistrict: districtStats,
    },
  });
}

export async function POST(request: Request) {
  const auth = await requireAdmin();
  if ("error" in auth) return auth.error;
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const action = String(body.action ?? "");

  if (action === "ingest") {
    const ingestion = await runAlertIngestion();
    const engine = await runNotificationEngine();
    await audit({ userId: auth.user.id, actorLabel: auth.user.email, action: "admin.ingest", meta: { ...ingestion, notifications: engine.notificationsCreated } });
    return Response.json({ ok: true, ingestion, engine });
  }

  if (action === "moderate") {
    const id = Number(body.id);
    const status = ["pending", "verified", "rejected"].includes(String(body.status)) ? String(body.status) : "pending";
    const note = typeof body.note === "string" ? body.note.slice(0, 400) : null;
    if (!Number.isFinite(id)) return Response.json({ error: "id is required" }, { status: 400 });
    await db
      .update(communityReports)
      .set({ status, moderationNote: note, moderatedBy: auth.user.id, credibility: status === "verified" ? 90 : status === "rejected" ? 5 : 50 })
      .where(eq(communityReports.id, id));
    await audit({ userId: auth.user.id, actorLabel: auth.user.email, action: "admin.moderate_report", entity: String(id), meta: { status } });
    return Response.json({ ok: true });
  }

  if (action === "user_role" || action === "user_active") {
    const id = Number(body.id);
    if (!Number.isFinite(id)) return Response.json({ error: "id is required" }, { status: 400 });
    if (action === "user_role") {
      const role = body.role === "admin" ? "admin" : "user";
      await db.update(users).set({ role }).where(eq(users.id, id));
      await audit({ userId: auth.user.id, actorLabel: auth.user.email, action: "admin.set_role", entity: String(id), meta: { role } });
    } else {
      const isActive = body.isActive === true;
      await db.update(users).set({ isActive }).where(eq(users.id, id));
      await audit({ userId: auth.user.id, actorLabel: auth.user.email, action: "admin.set_active", entity: String(id), meta: { isActive } });
    }
    return Response.json({ ok: true });
  }

  return Response.json({ error: "Unknown action" }, { status: 400 });
}
