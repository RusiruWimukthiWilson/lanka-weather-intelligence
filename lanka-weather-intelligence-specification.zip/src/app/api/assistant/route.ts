import { db } from "@/db";
import { assistantMessages } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { getSessionUser } from "@/lib/auth";
import { answerQuestion, ASSISTANT_SUGGESTIONS } from "@/lib/assistant";
import type { Lang } from "@/lib/i18n";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const threadId = new URL(request.url).searchParams.get("threadId");
  const user = await getSessionUser();
  if (!threadId) return Response.json({ messages: [], suggestions: ASSISTANT_SUGGESTIONS.en });
  const rows = await db.select().from(assistantMessages).where(eq(assistantMessages.threadId, threadId)).orderBy(asc(assistantMessages.createdAt)).limit(80);
  const lang = (rows[rows.length - 1]?.language ?? user?.language ?? "en") as Lang;
  return Response.json({ messages: rows, suggestions: ASSISTANT_SUGGESTIONS[lang] ?? ASSISTANT_SUGGESTIONS.en });
}

export async function POST(request: Request) {
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const question = typeof body.question === "string" ? body.question.trim().slice(0, 600) : "";
  const lang = (["en", "si", "ta"].includes(String(body.language)) ? String(body.language) : "en") as Lang;
  const threadId = typeof body.threadId === "string" && body.threadId.length ? body.threadId.slice(0, 64) : `t-${Date.now().toString(36)}`;
  const location = (body.location ?? null) as { name?: string; lat?: number; lon?: number; district?: string } | null;
  if (!question) return Response.json({ error: "Please type a question." }, { status: 400 });

  const user = await getSessionUser();
  const result = await answerQuestion({
    question,
    lang,
    location: location && Number.isFinite(Number(location.lat)) && Number.isFinite(Number(location.lon))
      ? { name: location.name ?? "Selected location", lat: Number(location.lat), lon: Number(location.lon), district: location.district }
      : undefined,
  });

  try {
    await db.insert(assistantMessages).values([
      { threadId, userId: user?.id ?? null, role: "user", content: question, language: lang },
      { threadId, userId: user?.id ?? null, role: "assistant", content: result.answer, language: lang, engine: result.engine, citations: result.citations },
    ]);
  } catch {
    // history persistence is best-effort
  }

  return Response.json({ threadId, ...result, suggestions: ASSISTANT_SUGGESTIONS[lang] });
}
