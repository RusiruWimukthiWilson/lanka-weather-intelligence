import { db } from "@/db";
import { users, savedLocations } from "@/db/schema";
import { eq } from "drizzle-orm";
import { audit, createSession, destroySession, getSessionUser, hashPassword, verifyPassword } from "@/lib/auth";

export const dynamic = "force-dynamic";

type Body = Record<string, unknown>;

function str(body: Body, key: string): string {
  const v = body[key];
  return typeof v === "string" ? v.trim() : "";
}

export async function GET(_request: Request, ctx: { params: Promise<{ action: string }> }) {
  const { action } = await ctx.params;
  if (action !== "me") return Response.json({ error: "Unknown action" }, { status: 404 });
  const user = await getSessionUser();
  return Response.json({ user });
}

export async function POST(request: Request, ctx: { params: Promise<{ action: string }> }) {
  const { action } = await ctx.params;
  let body: Body = {};
  try {
    body = (await request.json()) as Body;
  } catch {
    body = {};
  }
  const ip = request.headers.get("x-forwarded-for") ?? null;

  if (action === "logout") {
    const user = await getSessionUser();
    await destroySession();
    if (user) await audit({ userId: user.id, actorLabel: user.email, action: "auth.logout", ip });
    return Response.json({ ok: true });
  }

  if (action === "register") {
    const email = str(body, "email").toLowerCase();
    const name = str(body, "name");
    const password = str(body, "password");
    const language = ["en", "si", "ta"].includes(str(body, "language")) ? str(body, "language") : "en";
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return Response.json({ error: "A valid email address is required." }, { status: 400 });
    if (name.length < 2) return Response.json({ error: "Please provide your name." }, { status: 400 });
    if (password.length < 8) return Response.json({ error: "Password must be at least 8 characters." }, { status: 400 });

    const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
    if (existing.length) return Response.json({ error: "An account already exists for this email." }, { status: 409 });

    const inserted = await db
      .insert(users)
      .values({ email, name, passwordHash: hashPassword(password), language })
      .returning({ id: users.id, email: users.email, name: users.name, role: users.role });
    const user = inserted[0];
    await createSession(user.id);
    await db.insert(savedLocations).values({
      userId: user.id,
      label: "Colombo",
      district: "Colombo",
      province: "Western",
      lat: 6.9271,
      lon: 79.8612,
      isDefault: true,
    });
    await audit({ userId: user.id, actorLabel: email, action: "auth.register", ip });
    return Response.json({ user });
  }

  if (action === "login") {
    const email = str(body, "email").toLowerCase();
    const password = str(body, "password");
    const rows = await db.select().from(users).where(eq(users.email, email)).limit(1);
    const user = rows[0];
    if (!user || !verifyPassword(password, user.passwordHash)) {
      await audit({ actorLabel: email || "unknown", action: "auth.login_failed", ip });
      return Response.json({ error: "Email or password is incorrect." }, { status: 401 });
    }
    if (!user.isActive) return Response.json({ error: "This account has been disabled by an administrator." }, { status: 403 });
    await createSession(user.id);
    await audit({ userId: user.id, actorLabel: email, action: "auth.login", ip });
    return Response.json({ user: { id: user.id, email: user.email, name: user.name, role: user.role } });
  }

  if (action === "password") {
    const current = await getSessionUser();
    if (!current) return Response.json({ error: "Authentication required" }, { status: 401 });
    const currentPassword = str(body, "currentPassword");
    const newPassword = str(body, "newPassword");
    if (newPassword.length < 8) return Response.json({ error: "New password must be at least 8 characters." }, { status: 400 });
    const rows = await db.select().from(users).where(eq(users.id, current.id)).limit(1);
    const user = rows[0];
    if (!user || !verifyPassword(currentPassword, user.passwordHash)) {
      return Response.json({ error: "Current password is incorrect." }, { status: 400 });
    }
    await db.update(users).set({ passwordHash: hashPassword(newPassword) }).where(eq(users.id, current.id));
    await audit({ userId: current.id, actorLabel: current.email, action: "auth.password_changed", ip });
    return Response.json({ ok: true });
  }

  return Response.json({ error: "Unknown action" }, { status: 404 });
}
