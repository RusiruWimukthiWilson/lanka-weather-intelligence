import { db } from "@/db";
import { notifications, users } from "@/db/schema";
import { and, eq, isNull, sql } from "drizzle-orm";
import { audit, requireUser } from "@/lib/auth";
import { listNotifications, runNotificationEngine, unreadCount } from "@/lib/notification-engine";

export const dynamic = "force-dynamic";

export async function GET() {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;
  const [items, unread] = await Promise.all([listNotifications(auth.user.id), unreadCount(auth.user.id)]);
  return Response.json({ notifications: items, unread });
}

/** Runs the personalisation engine on demand and returns the freshly built notifications. */
export async function POST() {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;
  const engine = await runNotificationEngine();
  const items = await listNotifications(auth.user.id);
  await audit({ userId: auth.user.id, actorLabel: auth.user.email, action: "notifications.run", meta: { ...engine, examples: undefined } });
  return Response.json({ engine, notifications: items, unread: await unreadCount(auth.user.id) });
}

export async function PATCH(request: Request) {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  if (body.all === true) {
    await db
      .update(notifications)
      .set({ readAt: new Date() })
      .where(and(eq(notifications.userId, auth.user.id), isNull(notifications.readAt)));
    return Response.json({ ok: true, unread: 0 });
  }
  const id = Number(body.id);
  if (!Number.isFinite(id)) return Response.json({ error: "id is required" }, { status: 400 });
  await db.update(notifications).set({ readAt: new Date() }).where(and(eq(notifications.id, id), eq(notifications.userId, auth.user.id)));
  return Response.json({ ok: true, unread: await unreadCount(auth.user.id) });
}

export async function PUT(request: Request) {
  // Notification preferences (quiet hours, push flag) live on the user record.
  const auth = await requireUser();
  if ("error" in auth) return auth.error;
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const patch: Record<string, unknown> = {};
  if (typeof body.quietHoursEnabled === "boolean") patch.quietHoursEnabled = body.quietHoursEnabled;
  if (Number.isFinite(Number(body.quietHoursStart))) patch.quietHoursStart = Math.max(0, Math.min(23, Number(body.quietHoursStart)));
  if (Number.isFinite(Number(body.quietHoursEnd))) patch.quietHoursEnd = Math.max(0, Math.min(23, Number(body.quietHoursEnd)));
  if (typeof body.pushEnabled === "boolean") patch.pushEnabled = body.pushEnabled;
  if (!Object.keys(patch).length) return Response.json({ error: "nothing to update" }, { status: 400 });
  await db.update(users).set(patch).where(eq(users.id, auth.user.id));
  const unread = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(notifications)
    .where(and(eq(notifications.userId, auth.user.id), isNull(notifications.readAt)));
  return Response.json({ ok: true, unread: unread[0]?.count ?? 0 });
}
