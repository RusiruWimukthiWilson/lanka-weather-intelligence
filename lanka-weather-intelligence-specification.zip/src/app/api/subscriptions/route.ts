import { db } from "@/db";
import { subscriptions } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { audit, requireUser } from "@/lib/auth";
import { getDistrict, nearestDistrict } from "@/lib/lk-geo";

export const dynamic = "force-dynamic";

export async function GET() {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;
  const rows = await db.select().from(subscriptions).where(eq(subscriptions.userId, auth.user.id));
  return Response.json({ subscriptions: rows });
}

export async function POST(request: Request) {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const scopeType = body.scopeType === "district" ? "district" : "location";
  const scopeLabel = typeof body.scopeLabel === "string" ? body.scopeLabel.trim() : "";
  if (!scopeLabel) return Response.json({ error: "scopeLabel is required" }, { status: 400 });
  const categories = Array.isArray(body.categories) ? (body.categories as string[]).filter((c) => typeof c === "string") : [];
  const districtName = typeof body.district === "string" ? body.district : scopeType === "district" ? scopeLabel : null;
  const district = getDistrict(districtName);
  const lat = Number(body.lat);
  const lon = Number(body.lon);

  const inserted = await db
    .insert(subscriptions)
    .values({
      userId: auth.user.id,
      scopeType,
      scopeLabel,
      district: district?.name ?? null,
      lat: Number.isFinite(lat) ? lat : (district?.lat ?? null),
      lon: Number.isFinite(lon) ? lon : (district?.lon ?? nearestDistrict(7.9, 80.7).lon),
      categories: categories.length ? categories : ["rain", "wind", "heat", "lightning", "flood", "marine"],
      minimumSeverity: ["advisory", "watch", "warning"].includes(String(body.minimumSeverity)) ? String(body.minimumSeverity) : "advisory",
    })
    .returning();
  await audit({ userId: auth.user.id, actorLabel: auth.user.email, action: "subscription.created", entity: scopeLabel });
  return Response.json({ subscription: inserted[0] });
}

export async function PATCH(request: Request) {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const id = Number(body.id);
  if (!Number.isFinite(id)) return Response.json({ error: "id is required" }, { status: 400 });
  const patch: Record<string, unknown> = {};
  if (typeof body.active === "boolean") patch.active = body.active;
  if (Array.isArray(body.categories)) patch.categories = body.categories;
  if (["advisory", "watch", "warning"].includes(String(body.minimumSeverity))) patch.minimumSeverity = String(body.minimumSeverity);
  if (!Object.keys(patch).length) return Response.json({ error: "nothing to update" }, { status: 400 });
  await db.update(subscriptions).set(patch).where(and(eq(subscriptions.id, id), eq(subscriptions.userId, auth.user.id)));
  return Response.json({ ok: true });
}

export async function DELETE(request: Request) {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;
  const id = Number(new URL(request.url).searchParams.get("id"));
  if (!Number.isFinite(id)) return Response.json({ error: "id is required" }, { status: 400 });
  await db.delete(subscriptions).where(and(eq(subscriptions.id, id), eq(subscriptions.userId, auth.user.id)));
  return Response.json({ ok: true });
}
