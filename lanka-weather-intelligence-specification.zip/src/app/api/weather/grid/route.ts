import { WEATHER_GRID } from "@/lib/lk-geo";
import { fetchGrid, fetchGridTimeline } from "@/lib/weather/openmeteo";
import { deriveAdvisories, deriveMarineAdvisories } from "@/lib/advisory";
import type { WeatherBundle } from "@/lib/weather/openmeteo";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const wantTimeline = url.searchParams.get("timeline") === "1";

  try {
    const grid = await fetchGrid(WEATHER_GRID);
    const pseudoBundle = (cell: (typeof grid.cells)[number]): WeatherBundle => ({
      location: { name: cell.name, lat: cell.lat, lon: cell.lon, district: cell.district, province: "", elevation: null, timezone: "Asia/Colombo" },
      current: null,
      hourly: [],
      daily: [],
      provenance: grid.provenance,
    });

    const advisories = [
      ...grid.cells.flatMap((c) => deriveAdvisories({ ...pseudoBundle(c), hourly: [] })),
      ...deriveMarineAdvisories(grid.cells),
    ];

    let timeline: Awaited<ReturnType<typeof fetchGridTimeline>> | null = null;
    if (wantTimeline) {
      try {
        timeline = await fetchGridTimeline(WEATHER_GRID);
      } catch {
        timeline = null;
      }
    }

    return Response.json({
      cells: grid.cells,
      advisories: advisories.filter((a) => a.hazard !== "heat" || a.severity !== "advisory"),
      timeline,
      provenance: grid.provenance,
      layerNotice:
        "Map layers are rendered from live Open-Meteo model values sampled at real Sri Lankan locations. There is no Sri Lankan weather-radar feed in this deployment, so the rainfall layer is model precipitation, not observed radar.",
    });
  } catch (err) {
    return Response.json(
      {
        error: `Weather grid unavailable: ${err instanceof Error ? err.message : "unknown error"}. Map layers require the Open-Meteo service and no substitute data is displayed.`,
      },
      { status: 502 },
    );
  }
}
