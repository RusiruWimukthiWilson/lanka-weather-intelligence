import { fetchMarine, fetchWeatherBundle } from "@/lib/weather/openmeteo";
import { resolveLocation, jsonError } from "@/lib/req-location";
import { getDistrict } from "@/lib/lk-geo";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const loc = resolveLocation(url.searchParams);
  const district = getDistrict(loc.district);

  try {
    const [marine, weather] = await Promise.all([
      fetchMarine(loc.lat, loc.lon),
      fetchWeatherBundle({ name: loc.name, lat: loc.lat, lon: loc.lon, district: loc.district, province: loc.province }),
    ]);

    return Response.json({
      location: loc,
      marineArea: district?.marineArea ?? null,
      coastal: district?.coastal ?? false,
      marine,
      wind: {
        current: weather.current
          ? { speed: weather.current.windSpeed, direction: weather.current.windDirection, gust: weather.current.windGust }
          : null,
        hourly: weather.hourly.map((h) => ({ time: h.time, speed: h.windSpeed, gust: h.windGust, direction: h.windDirection })),
        daily: weather.daily.map((d) => ({
          date: d.date,
          windSpeedMax: d.windSpeedMax,
          windGustsMax: d.windGustsMax,
          windDirectionDominant: d.windDirectionDominant,
          precipitationSum: d.precipitationSum,
        })),
      },
      provenance: [weather.provenance, marine.provenance],
    });
  } catch (err) {
    return jsonError(`Marine module unavailable: ${err instanceof Error ? err.message : "unknown error"}`, 502, { location: loc });
  }
}
