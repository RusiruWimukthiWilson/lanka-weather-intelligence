import { fetchWeatherBundle, fetchAirQuality } from "@/lib/weather/openmeteo";
import { resolveLocation, jsonError } from "@/lib/req-location";
import { deriveAdvisories } from "@/lib/advisory";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const loc = resolveLocation(url.searchParams);
  const withAir = url.searchParams.get("air") !== "0";

  try {
    const [bundle, air] = await Promise.all([
      fetchWeatherBundle({ name: loc.name, lat: loc.lat, lon: loc.lon, district: loc.district, province: loc.province }),
      withAir ? fetchAirQuality(loc.lat, loc.lon) : Promise.resolve(null),
    ]);

    return Response.json({
      location: { ...loc, elevation: bundle.location.elevation, timezone: bundle.location.timezone },
      current: bundle.current,
      hourly: bundle.hourly,
      daily: bundle.daily,
      airQuality: air,
      advisories: deriveAdvisories(bundle),
      provenance: bundle.provenance,
    });
  } catch (err) {
    return jsonError(
      `Weather service could not be reached: ${err instanceof Error ? err.message : "unknown error"}. No substitute readings are shown.`,
      502,
      { location: loc },
    );
  }
}
