import { db } from "@/db";
import { savedLocations, users } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { audit, requireUser } from "@/lib/auth";
import { getDistrict, nearestDistrict } from "@/lib/lk-geo";

export const dynamic = "force-dynamic";

export async function GET() {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;
  const rows = await db.select().from(savedLocations).where(eq(savedLocations.userId, auth.user.id));
  return Response.json({ locations: rows });
}

export async function POST(request: Request) {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const label = typeof body.label === "string" ? body.label.trim() : "";
  const lat = Number(body.lat);
  const lon = Number(body.lon);
  if (!label || !Number.isFinite(lat) || !Number.isFinite(lon)) {
    return Response.json({ error: "label, lat and lon are required" }, { status: 400 });
  }
  const district = typeof body.district === "string" ? body.district : nearestDistrict(lat, lon).name;
  const info = getDistrict(district);
  const isDefault = body.isDefault === true;
  const inserted = await db
    .insert(savedLocations)
    .values({
      userId: auth.user.id,
      label,
      district: info?.name ?? null,
      province: info?.province ?? null,
      lat,
      lon,
      isDefault,
    })
    .returning();
  if (isDefault) {
    await db
      .update(savedLocations)
      .set({ isDefault: false })
      .where(and(eq(savedLocations.userId, auth.user.id), eq(savedLocations.isDefault, true)));
    await db.update(users).set({ homeLabel: label, homeLat: lat, homeLon: lon }).where(eq(users.id, auth.user.id));
  }
  await audit({ userId: auth.user.id, actorLabel: auth.user.email, action: "location.saved", entity: label, meta: { lat, lon } });
  return Response.json({ location: inserted[0] });
}

export async function DELETE(request: Request) {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;
  const id = Number(new URL(request.url).searchParams.get("id"));
  if (!Number.isFinite(id)) return Response.json({ error: "id is required" }, { status: 400 });
  await db.delete(savedLocations).where(and(eq(savedLocations.id, id), eq(savedLocations.userId, auth.user.id)));
  await audit({ userId: auth.user.id, actorLabel: auth.user.email, action: "location.deleted", entity: String(id) });
  return Response.json({ ok: true });
}
