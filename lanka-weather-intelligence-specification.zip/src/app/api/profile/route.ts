import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { audit, getSessionUser, requireUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getSessionUser();
  return Response.json({ user });
}

export async function PATCH(request: Request) {
  const auth = await requireUser();
  if ("error" in auth) return auth.error;
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const patch: Record<string, unknown> = {};
  if (typeof body.name === "string" && body.name.trim().length >= 2) patch.name = body.name.trim();
  if (["en", "si", "ta"].includes(String(body.language))) patch.language = String(body.language);
  if (["metric", "imperial"].includes(String(body.units))) patch.units = String(body.units);
  if (typeof body.reduceMotion === "boolean") patch.reduceMotion = body.reduceMotion;
  if (typeof body.highContrast === "boolean") patch.highContrast = body.highContrast;
  if (typeof body.quietHoursEnabled === "boolean") patch.quietHoursEnabled = body.quietHoursEnabled;
  if (Number.isFinite(Number(body.quietHoursStart))) patch.quietHoursStart = Math.max(0, Math.min(23, Number(body.quietHoursStart)));
  if (Number.isFinite(Number(body.quietHoursEnd))) patch.quietHoursEnd = Math.max(0, Math.min(23, Number(body.quietHoursEnd)));
  if (!Object.keys(patch).length) return Response.json({ error: "nothing to update" }, { status: 400 });
  await db.update(users).set(patch).where(eq(users.id, auth.user.id));
  await audit({ userId: auth.user.id, actorLabel: auth.user.email, action: "profile.updated", meta: patch });
  return Response.json({ ok: true, user: { ...auth.user, ...patch } });
}
