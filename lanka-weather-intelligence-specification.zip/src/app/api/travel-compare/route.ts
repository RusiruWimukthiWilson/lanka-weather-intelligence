import { fetchWeatherBundle, type WeatherBundle } from "@/lib/weather/openmeteo";
import { nearestDistrict } from "@/lib/lk-geo";

export const dynamic = "force-dynamic";

type Point = { name: string; lat: number; lon: number };

export async function GET(request: Request) {
  const raw = new URL(request.url).searchParams.get("points") ?? "";
  const points: Point[] = raw
    .split("|")
    .map((chunk) => chunk.split(",").map(Number))
    .filter((nums) => nums.length === 2 && nums.every((n) => Number.isFinite(n)))
    .map(([lat, lon], i) => {
      const district = nearestDistrict(lat, lon);
      return { name: `${district.capital}-${i}`, lat, lon };
    })
    .slice(0, 6);

  if (!points.length) return Response.json({ error: "Provide up to six points as lat,lon|lat,lon" }, { status: 400 });

  const resolved: Point[] =
    new URL(request.url).searchParams.get("names")?.split("|").slice(0, points.length).map((n, i) => ({ ...points[i], name: n })) ?? points;

  try {
    const bundles = await Promise.all(
      resolved.map((p) =>
        fetchWeatherBundle(
          { name: p.name, lat: p.lat, lon: p.lon, district: nearestDistrict(p.lat, p.lon).name, province: nearestDistrict(p.lat, p.lon).province },
          { forecastDays: 7, pastDays: 0 },
        ),
      ),
    );

    return Response.json({
      results: bundles.map((b: WeatherBundle) => ({
        point: { name: b.location.name, lat: b.location.lat, lon: b.location.lon },
        current: b.current,
        hourly: b.hourly.map((h) => ({ time: h.time, temperature: h.temperature, precipitationProbability: h.precipitationProbability, visibility: h.visibility, windSpeed: h.windSpeed, weatherCode: h.weatherCode, isDay: h.isDay, precipitation: h.precipitation })),
        daily: b.daily,
        provenance: b.provenance,
      })),
      provenance: bundles[0]?.provenance ?? null,
      fetchedAt: new Date().toISOString(),
    });
  } catch (err) {
    return Response.json(
      { error: `Destination forecasts unavailable: ${err instanceof Error ? err.message : "unknown error"}` },
      { status: 502 },
    );
  }
}
