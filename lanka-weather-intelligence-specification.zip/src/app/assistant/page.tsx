"use client";

import { useEffect, useRef, useState } from "react";
import { useApp } from "@/components/location-context";
import { Card, SectionTitle, Badge, Spinner } from "@/components/ui";
import { LANGS, type Lang } from "@/lib/i18n";

type Citation = { label: string; source: string; detail: string };
type Msg = { role: "user" | "assistant"; content: string; engine?: string; citations?: Citation[]; unverifiable?: string[] };

export default function AssistantPage() {
  const { location, lang, setLang } = useApp();
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [threadId, setThreadId] = useState<string>("");
  const endRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const id = `t-${Math.random().toString(36).slice(2, 10)}`;
    setThreadId(id);
    setMessages([
      {
        role: "assistant",
        content:
          "Ask me anything about weather in Sri Lanka. I answer only from live model data and stored advisories that I fetch for your question — if I cannot verify something (for example observed rainfall or official river levels), I will say so instead of guessing.",
        engine: "lwi-rules",
      },
    ]);
  }, []);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const res = await fetch(`/api/assistant?threadId=${threadId}`, { cache: "no-store" });
        const data = (await res.json()) as { suggestions?: string[] };
        if (!cancelled && data.suggestions?.length) setSuggestions(data.suggestions);
      } catch {
        // ignore
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [threadId, lang]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, busy]);

  async function ask(question: string) {
    if (!question.trim() || busy) return;
    setBusy(true);
    setInput("");
    setMessages((m) => [...m, { role: "user", content: question }]);
    try {
      const res = await fetch("/api/assistant", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ question, language: lang, threadId, location }),
      });
      const data = (await res.json()) as { answer?: string; error?: string; engine?: string; citations?: Citation[]; unverifiable?: string[]; suggestions?: string[] };
      setMessages((m) => [
        ...m,
        {
          role: "assistant",
          content: data.answer ?? data.error ?? "I could not process that question.",
          engine: data.engine,
          citations: data.citations,
          unverifiable: data.unverifiable,
        },
      ]);
      if (data.suggestions?.length) setSuggestions(data.suggestions);
    } catch {
      setMessages((m) => [...m, { role: "assistant", content: "Network error — I could not reach the data service, so I will not answer with invented conditions." }]);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-4">
      <Card>
        <SectionTitle
          title="AI weather assistant"
          subtitle="Grounded answers: every reply is assembled from the live Open-Meteo data retrieved for your question, plus stored advisory records."
          right={
            <div className="flex gap-1">
              {LANGS.map((l) => (
                <button
                  key={l.code}
                  onClick={() => setLang(l.code as Lang)}
                  className={`focus-ring rounded-lg px-2.5 py-1 text-xs ${lang === l.code ? "bg-sky-500/25 text-sky-100" : "border border-sky-400/20 text-slate-300"}`}
                >
                  {l.native}
                </button>
              ))}
            </div>
          }
        />
        <div className="flex flex-wrap gap-1.5">
          {suggestions.map((s) => (
            <button key={s} onClick={() => void ask(s)} className="focus-ring rounded-full border border-sky-400/25 bg-sky-500/10 px-3 py-1.5 text-[11px] text-sky-100 hover:bg-sky-500/20">
              {s}
            </button>
          ))}
        </div>
        <p className="mt-2 text-[11px] text-muted">
          Context location: <span className="text-slate-300">{location.name}</span> ({location.lat.toFixed(3)}, {location.lon.toFixed(3)}). Mention another town by name to switch.
        </p>
      </Card>

      <Card className="!p-0">
        <div className="max-h-[54vh] space-y-3 overflow-y-auto p-4">
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[88%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${m.role === "user" ? "bg-sky-500/20 text-sky-50" : "glass-soft text-slate-200"}`}>
                <p className="whitespace-pre-wrap">{m.content}</p>
                {m.citations?.length ? (
                  <div className="mt-2 border-t border-sky-400/15 pt-2">
                    <p className="text-[10px] uppercase tracking-wider text-muted">Sources used</p>
                    <ul className="mt-1 space-y-0.5 text-[10px] text-muted">
                      {m.citations.map((c) => (
                        <li key={c.label}>
                          <span className="text-slate-300">{c.label}</span> — {c.source} · {c.detail}
                        </li>
                      ))}
                    </ul>
                  </div>
                ) : null}
                {m.unverifiable?.length ? (
                  <p className="mt-2 text-[10px] text-amber-200">Could not verify: {m.unverifiable.join(", ")}</p>
                ) : null}
                {m.engine ? <p className="mt-1.5 text-[10px] text-muted">engine: {m.engine}</p> : null}
              </div>
            </div>
          ))}
          {busy ? <Spinner label="Fetching live data and composing the answer…" /> : null}
          <div ref={endRef} />
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            void ask(input);
          }}
          className="flex items-end gap-2 border-t border-sky-400/10 p-3"
        >
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                void ask(input);
              }
            }}
            rows={2}
            placeholder="e.g. Will it rain in Kurunegala tomorrow evening?"
            className="focus-ring min-h-[46px] flex-1 resize-none rounded-xl border border-sky-400/20 bg-[#0a1733] px-3 py-2 text-sm text-slate-100 placeholder:text-slate-500"
          />
          <button type="submit" disabled={busy || !input.trim()} className="focus-ring rounded-xl bg-gradient-to-r from-sky-500 to-violet-500 px-4 py-2.5 text-sm font-medium text-white disabled:opacity-40">
            Ask
          </button>
        </form>
      </Card>

      <Card>
        <SectionTitle title="What the assistant will not do" />
        <div className="grid gap-2 text-xs md:grid-cols-2">
          <div className="glass-soft p-3">
            <Badge color="#34d399">Grounded</Badge>
            <p className="mt-1.5 text-muted">Quotes live model values it has just fetched, with the source and retrieval time attached.</p>
          </div>
          <div className="glass-soft p-3">
            <Badge color="#fbbf24">Honest about gaps</Badge>
            <p className="mt-1.5 text-muted">Says so when radar, river levels, soil moisture or official bulletins are unavailable instead of inventing numbers.</p>
          </div>
        </div>
      </Card>
    </div>
  );
}
