"use client";

import { useMemo, useState } from "react";
import { useApp } from "@/components/location-context";
import { useApi } from "@/components/use-api";
import { Badge, Card, EmptyState, ErrorState, SectionTitle, Spinner, Stat } from "@/components/ui";
import type { CommunityResponse } from "@/lib/types";
import { DISTRICTS } from "@/lib/lk-geo";
import { fmtDateTime, timeAgo } from "@/lib/format";

const CATEGORIES: { id: string; label: string; color: string }[] = [
  { id: "rain_started", label: "Rain starting", color: "#38bdf8" },
  { id: "heavy_rain", label: "Heavy rainfall", color: "#0ea5e9" },
  { id: "flood", label: "Flooding", color: "#f43f5e" },
  { id: "waterlogging", label: "Waterlogging", color: "#fbbf24" },
  { id: "strong_wind", label: "Strong winds", color: "#a78bfa" },
  { id: "heat", label: "Extreme heat", color: "#fb7185" },
  { id: "other", label: "Other", color: "#94a3b8" },
];

const INTENSITIES = ["light", "moderate", "heavy", "extreme"];

async function shrinkImage(file: File): Promise<string> {
  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Could not read the file"));
    reader.readAsDataURL(file);
  });
  const img = document.createElement("img");
  await new Promise((resolve, reject) => {
    img.onload = resolve;
    img.onerror = reject;
    img.src = dataUrl;
  });
  const max = 800;
  const scale = Math.min(1, max / Math.max(img.width, img.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(img.width * scale);
  canvas.height = Math.round(img.height * scale);
  const ctx = canvas.getContext("2d");
  if (!ctx) return dataUrl;
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL("image/jpeg", 0.62);
}

export default function CommunityPage() {
  const { location, geolocate, geoStatus, user } = useApp();
  const [district, setDistrict] = useState("");
  const [category, setCategory] = useState("");
  const { data, error, loading, reload } = useApi<CommunityResponse>(`/api/community?limit=60${district ? `&district=${district}` : ""}${category ? `&category=${category}` : ""}`, [district, category]);

  const [form, setForm] = useState({ category: "rain_started", intensity: "moderate", note: "", placeLabel: location.name, lat: location.lat, lon: location.lon, reporterName: "" });
  const [photo, setPhoto] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [flash, setFlash] = useState<{ ok: boolean; text: string } | null>(null);
  const [voted, setVoted] = useState<Record<number, number>>({});

  const stats = useMemo(() => {
    const map = new Map((data?.stats ?? []).map((s) => [s.category, s.count]));
    return CATEGORIES.map((c) => ({ ...c, count: map.get(c.id) ?? 0 }));
  }, [data]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setFlash(null);
    try {
      const res = await fetch("/api/community", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ ...form, photoData: photo }),
      });
      const body = (await res.json()) as { error?: string; id?: number; district?: string };
      if (!res.ok) {
        setFlash({ ok: false, text: body.error ?? "Could not submit the report." });
      } else {
        setFlash({ ok: true, text: `Report #${body.id} recorded for ${body.district}. It is marked unverified until a moderator confirms it.` });
        setForm((f) => ({ ...f, note: "" }));
        setPhoto(null);
        await reload();
      }
    } finally {
      setSubmitting(false);
    }
  }

  async function vote(id: number, value: 1 | -1) {
    const res = await fetch("/api/community", {
      method: "PUT",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ id, value }),
    });
    if (res.status === 401) {
      setFlash({ ok: false, text: "Sign in to corroborate or dispute reports." });
      return;
    }
    setVoted((v) => ({ ...v, [id]: value }));
    await reload();
  }

  return (
    <div className="space-y-5">
      <Card>
        <SectionTitle
          title="Community weather reporting"
          subtitle="Citizen observations fill the gaps between weather stations. Every report is labelled unverified until moderated."
          right={<Badge color="#f472b6">Unverified unless marked verified</Badge>}
        />
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-7">
          {stats.map((s) => (
            <button
              key={s.id}
              onClick={() => setCategory(category === s.id ? "" : s.id)}
              className={`glass-soft p-3 text-left transition ${category === s.id ? "ring-1 ring-pink-300/40" : ""}`}
            >
              <p className="text-[10px] uppercase tracking-wider text-muted">{s.label}</p>
              <p className="mt-1 text-lg font-semibold" style={{ color: s.color }}>
                {s.count}
              </p>
            </button>
          ))}
        </div>
      </Card>

      <div className="grid gap-4 lg:grid-cols-[380px_1fr]">
        <Card>
          <SectionTitle title="Submit an observation" subtitle="Only submit what you can see yourself. False reports reduce your credibility score." />
          <form onSubmit={submit} className="space-y-3">
            <label className="block text-xs text-muted">
              Category
              <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="focus-ring mt-1 w-full rounded-lg border border-sky-400/20 bg-[#0a1733] px-2.5 py-2 text-xs text-slate-100">
                {CATEGORIES.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.label}
                  </option>
                ))}
              </select>
            </label>

            <div className="text-xs text-muted">
              Intensity
              <div className="mt-1 flex gap-1.5">
                {INTENSITIES.map((i) => (
                  <button key={i} type="button" onClick={() => setForm({ ...form, intensity: i })} className={`focus-ring flex-1 rounded-lg px-2 py-1.5 text-[11px] capitalize ${form.intensity === i ? "bg-sky-500/25 text-sky-100" : "border border-sky-400/20 text-slate-300"}`}>
                    {i}
                  </button>
                ))}
              </div>
            </div>

            <label className="block text-xs text-muted">
              Location label
              <input value={form.placeLabel} onChange={(e) => setForm({ ...form, placeLabel: e.target.value })} placeholder="e.g. near Kohuwala junction" className="focus-ring mt-1 w-full rounded-lg border border-sky-400/20 bg-[#0a1733] px-2.5 py-2 text-xs text-slate-100" />
            </label>

            <div className="flex flex-wrap items-center gap-2 text-[11px]">
              <button
                type="button"
                onClick={async () => {
                  await geolocate();
                  setForm((f) => ({ ...f, lat: location.lat, lon: location.lon }));
                }}
                className="focus-ring rounded-lg border border-sky-400/30 bg-sky-500/15 px-3 py-2 text-sky-100"
              >
                {geoStatus === "locating" ? "Locating…" : "Use my GPS position"}
              </button>
              <button type="button" onClick={() => setForm((f) => ({ ...f, lat: location.lat, lon: location.lon, placeLabel: f.placeLabel || location.name }))} className="focus-ring rounded-lg border border-sky-400/20 px-3 py-2 text-slate-300">
                Use selected place ({location.name})
              </button>
              <span className="font-mono text-[10px] text-muted">
                {form.lat.toFixed(3)}, {form.lon.toFixed(3)}
              </span>
            </div>

            <label className="block text-xs text-muted">
              What are you seeing?
              <textarea value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} rows={3} maxLength={600} placeholder="Water up to ankle height on the road, drains overflowing…" className="focus-ring mt-1 w-full resize-none rounded-lg border border-sky-400/20 bg-[#0a1733] px-2.5 py-2 text-xs text-slate-100" />
            </label>

            {!user ? (
              <label className="block text-xs text-muted">
                Your name (optional)
                <input value={form.reporterName} onChange={(e) => setForm({ ...form, reporterName: e.target.value })} placeholder="Anonymous observer" className="focus-ring mt-1 w-full rounded-lg border border-sky-400/20 bg-[#0a1733] px-2.5 py-2 text-xs text-slate-100" />
              </label>
            ) : null}

            <label className="block text-xs text-muted">
              Photo (optional, resized to 800 px)
              <input
                type="file"
                accept="image/*"
                onChange={async (e) => {
                  const file = e.target.files?.[0];
                  if (!file) return;
                  try {
                    setPhoto(await shrinkImage(file));
                    setFlash({ ok: true, text: "Photo attached." });
                  } catch {
                    setFlash({ ok: false, text: "Could not read that image." });
                  }
                }}
                className="mt-1 block w-full text-[11px] text-slate-300"
              />
            </label>
            {photo ? <img src={photo} alt="Attached observation preview" className="h-24 w-full rounded-lg object-cover" /> : null}

            <button type="submit" disabled={submitting} className="focus-ring w-full rounded-lg bg-gradient-to-r from-sky-500 to-violet-500 px-3 py-2.5 text-sm font-medium text-white disabled:opacity-50">
              {submitting ? "Submitting…" : "Submit report"}
            </button>
            {flash ? <p className={`text-[11px] ${flash.ok ? "text-emerald-300" : "text-rose-300"}`}>{flash.text}</p> : null}
          </form>
        </Card>

        <div className="space-y-3">
          <Card>
            <SectionTitle
              title="Latest observations"
              subtitle="Sorted newest first. Community data is never used as an official reading."
              right={
                <div className="flex gap-1.5">
                  <select value={district} onChange={(e) => setDistrict(e.target.value)} className="focus-ring rounded-lg border border-sky-400/20 bg-[#0a1733] px-2 py-1.5 text-[11px] text-slate-100">
                    <option value="">All districts</option>
                    {DISTRICTS.map((d) => (
                      <option key={d.name} value={d.name}>
                        {d.name}
                      </option>
                    ))}
                  </select>
                  <button onClick={reload} className="focus-ring rounded-lg border border-sky-400/25 px-2.5 py-1.5 text-[11px] text-slate-200">
                    Refresh
                  </button>
                </div>
              }
            />
            {error ? <ErrorState title="Could not load reports" message={error} onRetry={reload} /> : null}
            {loading ? <Spinner label="Loading community reports…" /> : null}
            {!loading && !data?.reports.length ? (
              <EmptyState title="No reports yet for this filter" message="Be the first to describe what you can see. Include a landmark so neighbours can relate to it." />
            ) : null}
            <div className="space-y-2.5">
              {(data?.reports ?? []).map((r) => {
                const cat = CATEGORIES.find((c) => c.id === r.category);
                return (
                  <div key={r.id} className="glass-soft p-3.5">
                    <div className="flex flex-wrap items-center gap-2">
                      <Badge color={cat?.color ?? "#94a3b8"}>{cat?.label ?? r.category}</Badge>
                      <Badge color="#a78bfa">{r.intensity}</Badge>
                      {r.status === "verified" ? <Badge color="#34d399">Verified by moderator</Badge> : r.status === "rejected" ? <Badge color="#f43f5e">Rejected</Badge> : <Badge color="#fbbf24">Unverified</Badge>}
                      {r.credibility >= 80 ? <Badge color="#34d399">High credibility {r.credibility}</Badge> : null}
                    </div>
                    <p className="mt-2 text-sm text-slate-100">{r.note || cat?.label}</p>
                    <p className="mt-1 text-[11px] text-muted">
                      {r.placeLabel}, {r.district} District · {r.reporterName} · {timeAgo(r.createdAt)} ({fmtDateTime(r.createdAt)})
                    </p>
                    <div className="mt-2 flex flex-wrap items-center gap-2">
                      <button onClick={() => void vote(r.id, 1)} className={`focus-ring rounded-lg border px-2.5 py-1 text-[11px] ${voted[r.id] === 1 ? "border-emerald-400/40 bg-emerald-400/15 text-emerald-200" : "border-sky-400/20 text-slate-300"}`}>
                        ▲ I saw this too ({r.upvotes})
                      </button>
                      <button onClick={() => void vote(r.id, -1)} className={`focus-ring rounded-lg border px-2.5 py-1 text-[11px] ${voted[r.id] === -1 ? "border-rose-400/40 bg-rose-400/15 text-rose-200" : "border-sky-400/20 text-slate-300"}`}>
                        ▼ Dispute ({r.downvotes})
                      </button>
                      <span className="text-[10px] text-muted">
                        {r.lat.toFixed(3)}, {r.lon.toFixed(3)}
                      </span>
                    </div>
                    {r.moderationNote ? <p className="mt-2 text-[11px] text-amber-200">Moderator: {r.moderationNote}</p> : null}
                  </div>
                );
              })}
            </div>
          </Card>

          <Card>
            <div className="grid gap-3 md:grid-cols-3">
              <Stat label="Reports stored" value={data?.reports.length ?? 0} hint="Most recent 60 shown" />
              <Stat label="Pending moderation" value={(data?.reports ?? []).filter((r) => r.status === "pending").length} />
              <Stat label="Verified" value={(data?.reports ?? []).filter((r) => r.status === "verified").length} />
            </div>
            <p className="mt-3 text-[11px] text-muted">{data?.notice}</p>
          </Card>
        </div>
      </div>
    </div>
  );
}
