"use client";

import { useMemo, useState } from "react";
import { useApp } from "@/components/location-context";
import { useApi } from "@/components/use-api";
import { WeatherIcon } from "@/components/weather-icon";
import { Badge, Card, ErrorState, ProvenanceBadge, SectionTitle, Spinner, Stat } from "@/components/ui";
import { CompareChart } from "@/components/charts";
import type { WeatherResponse } from "@/lib/types";
import { PLACES } from "@/lib/lk-geo";
import { describeCode, beaufortLabel } from "@/lib/weather/codes";
import { fmtDay, fmtNum, fmtTemp, fmtTime } from "@/lib/format";

type RouteDef = { name: string; waypoints: { name: string; lat: number; lon: number }[] };

const ROUTES: RouteDef[] = [
  {
    name: "Colombo → Kandy (A1)",
    waypoints: [
      { name: "Colombo", lat: 6.9271, lon: 79.8612 },
      { name: "Kadawatha", lat: 7.0, lon: 79.95 },
      { name: "Nittambuwa", lat: 7.1394, lon: 80.0967 },
      { name: "Kegalle", lat: 7.2513, lon: 80.3464 },
      { name: "Mawanella", lat: 7.25, lon: 80.4469 },
      { name: "Peradeniya", lat: 7.2599, lon: 80.5977 },
      { name: "Kandy", lat: 7.2906, lon: 80.6337 },
    ],
  },
  {
    name: "Colombo → Galle → Matara (Southern Expressway)",
    waypoints: [
      { name: "Colombo", lat: 6.9271, lon: 79.8612 },
      { name: "Panadura", lat: 6.7132, lon: 79.9026 },
      { name: "Horana junction", lat: 6.7156, lon: 80.0628 },
      { name: "Galle", lat: 6.0535, lon: 80.221 },
      { name: "Weligama", lat: 5.9727, lon: 80.4297 },
      { name: "Matara", lat: 5.9485, lon: 80.5353 },
    ],
  },
  {
    name: "Kandy → Nuwara Eliya → Ella (Hill country)",
    waypoints: [
      { name: "Kandy", lat: 7.2906, lon: 80.6337 },
      { name: "Peradeniya", lat: 7.2599, lon: 80.5977 },
      { name: "Hatton", lat: 6.8916, lon: 80.5955 },
      { name: "Nuwara Eliya", lat: 6.9497, lon: 80.7891 },
      { name: "Ella", lat: 6.8667, lon: 81.0467 },
    ],
  },
  {
    name: "Anuradhapura → Jaffna (A9)",
    waypoints: [
      { name: "Anuradhapura", lat: 8.3114, lon: 80.4037 },
      { name: "Medawachchiya", lat: 8.5333, lon: 80.6 },
      { name: "Vavuniya", lat: 8.7514, lon: 80.4971 },
      { name: "Kilinochchi", lat: 9.3803, lon: 80.377 },
      { name: "Jaffna", lat: 9.6615, lon: 80.0255 },
    ],
  },
];

const FEATURED = ["Colombo", "Kandy", "Galle", "Jaffna", "Batticaloa", "Nuwara Eliya", "Trincomalee", "Ratnapura", "Negombo", "Badulla"];

function useWeatherFor(points: { name: string; lat: number; lon: number }[]) {
  const key = points.map((p) => `${p.lat},${p.lon}`).join("|");
  const url = points.length ? `/api/travel-compare?points=${encodeURIComponent(key)}` : null;
  return useApi<{
    results: { point: { name: string; lat: number; lon: number }; current: WeatherResponse["current"]; daily: WeatherResponse["daily"]; hourly: WeatherResponse["hourly"]; provenance: WeatherResponse["provenance"] }[];
    provenance: WeatherResponse["provenance"];
    error?: string;
  }>(url, [key]);
}

export default function TravelPage() {
  const { location } = useApp();
  const [picked, setPicked] = useState<string[]>(["Colombo", "Kandy", "Jaffna"]);
  const [routeIdx, setRouteIdx] = useState(0);

  const points = useMemo(
    () =>
      picked
        .map((name) => PLACES.find((p) => p.name === name))
        .filter((p): p is (typeof PLACES)[number] => Boolean(p))
        .map((p) => ({ name: p.name, lat: p.lat, lon: p.lon })),
    [picked],
  );

  const compare = useWeatherFor(points);
  const route = ROUTES[routeIdx];
  const routeData = useWeatherFor(route.waypoints.slice(0, 6));

  if (compare.error) return <ErrorState title="Travel module unavailable" message={compare.error} onRetry={compare.reload} />;

  const results = compare.data?.results ?? [];
  const best = results.length
    ? [...results].sort((a, b) => (a.daily?.[0]?.precipitationProbabilityMax ?? 0) - (b.daily?.[0]?.precipitationProbabilityMax ?? 0))[0]
    : null;

  const chartData = useMemo(() => {
    if (!results.length) return [];
    const days = Math.min(...results.map((r) => r.daily?.length ?? 0), 7);
    return Array.from({ length: days }).map((_, i) => {
      const row: Record<string, number | string | null> = { label: fmtDay(results[0].daily?.[i]?.date ?? "", "short") };
      for (const r of results) row[r.point.name] = r.daily?.[i]?.tempMax ?? null;
      return row;
    });
  }, [results]);

  return (
    <div className="space-y-5">
      <Card>
        <SectionTitle
          title="Travel weather intelligence"
          subtitle="Compare destinations, read conditions along a corridor and find the calmest travel window — all from the same live model data."
          right={<ProvenanceBadge provider={compare.data?.provenance.provider ?? "Open-Meteo"} model={compare.data?.provenance.model} fetchedAt={compare.loadedAt} />}
        />
        <div className="flex flex-wrap gap-1.5">
          {FEATURED.map((name) => (
            <button
              key={name}
              onClick={() =>
                setPicked((prev) => (prev.includes(name) ? prev.filter((p) => p !== name) : prev.length >= 4 ? [...prev.slice(1), name] : [...prev, name]))
              }
              className={`focus-ring rounded-full px-3 py-1.5 text-[11px] ${picked.includes(name) ? "bg-sky-500/25 text-sky-100 ring-1 ring-sky-300/30" : "border border-sky-400/20 text-slate-300"}`}
            >
              {name}
            </button>
          ))}
        </div>
        <p className="mt-2 text-[11px] text-muted">Up to four destinations can be compared at once. Current selection: {picked.join(", ") || "none"}.</p>
      </Card>

      {compare.loading ? <Card><Spinner label="Fetching destination forecasts…" /></Card> : null}

      {best ? (
        <Card>
          <SectionTitle title="Calmest destination today" subtitle="Ranked by the lowest modelled rain probability for the first forecast day." />
          <div className="flex flex-wrap items-center gap-4">
            <WeatherIcon code={best.current?.weatherCode} isDay={best.current?.isDay ?? true} size={64} />
            <div>
              <p className="text-xl font-semibold text-slate-50">{best.point.name}</p>
              <p className="text-sm text-muted">
                {describeCode(best.current?.weatherCode ?? 3)} · {fmtTemp(best.current?.temperature)} · rain chance {fmtNum(best.daily?.[0]?.precipitationProbabilityMax, 0, "%")}
              </p>
            </div>
            <button onClick={() => setPicked([best.point.name])} className="focus-ring ml-auto rounded-lg border border-sky-400/30 bg-sky-500/15 px-3 py-2 text-xs text-sky-100">
              Focus on {best.point.name}
            </button>
          </div>
        </Card>
      ) : null}

      {results.length ? (
        <>
          <Card>
            <SectionTitle title="Destination comparison" subtitle="Daily maximum temperature for the selected destinations." />
            <CompareChart data={chartData} />
          </Card>

          <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
            {results.map((r) => (
              <Card key={r.point.name} className="!p-4">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-semibold text-slate-50">{r.point.name}</p>
                  <WeatherIcon code={r.current?.weatherCode} isDay={r.current?.isDay ?? true} size={40} />
                </div>
                <p className="mt-1 text-xs text-muted">{describeCode(r.current?.weatherCode ?? 3)}</p>
                <div className="mt-2 grid grid-cols-2 gap-2 text-[11px]">
                  <Stat label="Now" value={fmtTemp(r.current?.temperature)} />
                  <Stat label="Feels" value={fmtTemp(r.current?.apparentTemperature)} />
                  <Stat label="Rain 24 h" value={fmtNum(r.daily?.[0]?.precipitationSum, 1, "mm")} />
                  <Stat label="Chance" value={fmtNum(r.daily?.[0]?.precipitationProbabilityMax, 0, "%")} />
                  <Stat label="Wind" value={fmtNum(r.current?.windSpeed, 0, "km/h")} />
                  <Stat label="Visibility" value={r.hourly?.[0]?.visibility ? `${(r.hourly[0].visibility / 1000).toFixed(0)} km` : "—"} />
                </div>
                <div className="mt-3 space-y-1 text-[11px] text-muted">
                  {r.daily?.slice(1, 4).map((d) => (
                    <div key={d.date} className="flex items-center justify-between">
                      <span>{fmtDay(d.date, "short")}</span>
                      <span className="flex items-center gap-1.5">
                        <WeatherIcon code={d.weatherCode} isDay size={18} />
                        {fmtTemp(d.tempMax)} · {fmtNum(d.precipitationProbabilityMax, 0, "%")}
                      </span>
                    </div>
                  ))}
                </div>
              </Card>
            ))}
          </div>
        </>
      ) : null}

      <Card>
        <SectionTitle
          title="Corridor conditions"
          subtitle="Point-by-point model weather along the route, including visibility and disruption screening."
          right={
            <select value={routeIdx} onChange={(e) => setRouteIdx(Number(e.target.value))} className="focus-ring rounded-lg border border-sky-400/20 bg-[#0a1733] px-2.5 py-1.5 text-xs text-slate-100">
              {ROUTES.map((r, i) => (
                <option key={r.name} value={i}>
                  {r.name}
                </option>
              ))}
            </select>
          }
        />
        {routeData.loading ? <Spinner label="Reading corridor conditions…" /> : null}
        {routeData.error ? <ErrorState title="Corridor unavailable" message={routeData.error} onRetry={routeData.reload} /> : null}
        <div className="space-y-2">
          {(routeData.data?.results ?? []).map((r, i, arr) => {
            const wet = (r.daily?.[0]?.precipitationSum ?? 0) >= 10;
            const lowVis = (r.hourly?.[0]?.visibility ?? 20000) < 3000;
            const windy = (r.current?.windSpeed ?? 0) >= 35;
            return (
              <div key={r.point.name} className="glass-soft flex flex-wrap items-center gap-3 p-3">
                <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-sky-500/20 text-[11px] font-semibold text-sky-100">{i + 1}</span>
                <div className="min-w-[130px]">
                  <p className="text-sm font-medium text-slate-100">{r.point.name}</p>
                  <p className="text-[10px] text-muted">{i === 0 ? "Start" : i === arr.length - 1 ? "Destination" : `Via · ${fmtTime(r.current?.time)}`}</p>
                </div>
                <WeatherIcon code={r.current?.weatherCode} isDay={r.current?.isDay ?? true} size={34} />
                <div className="flex flex-wrap gap-3 text-[11px] text-muted">
                  <span>{fmtTemp(r.current?.temperature)}</span>
                  <span>RH {fmtNum(r.current?.humidity, 0, "%")}</span>
                  <span>Wind {fmtNum(r.current?.windSpeed, 0, "km/h")}</span>
                  <span>Vis {r.hourly?.[0]?.visibility ? `${(r.hourly[0].visibility / 1000).toFixed(1)} km` : "—"}</span>
                  <span>Rain 24 h {fmtNum(r.daily?.[0]?.precipitationSum, 1, "mm")}</span>
                </div>
                <div className="ml-auto flex flex-wrap gap-1.5">
                  {wet ? <Badge color="#f97316">Wet road risk</Badge> : null}
                  {lowVis ? <Badge color="#fbbf24">Low visibility</Badge> : null}
                  {windy ? <Badge color="#fb7185">Gusty — {beaufortLabel(r.current?.windSpeed ?? 0)}</Badge> : null}
                  {!wet && !lowVis && !windy ? <Badge color="#34d399">Clear corridor</Badge> : null}
                </div>
              </div>
            );
          })}
        </div>
        <p className="mt-3 text-[11px] text-muted">
          Waypoint conditions are model values for each coordinate — not observations from road-side sensors. Always follow police and Road Development Authority advisories during severe weather.
        </p>
      </Card>

      <Card>
        <SectionTitle title="Recommended travel windows" subtitle="Computed for your current location from hourly model data." />
        {(() => {
          const hourly = results.find((r) => r.point.name === picked[0])?.hourly ?? [];
          const future = hourly.filter((h) => new Date(h.time).getTime() >= Date.now() - 3600 * 1000).slice(0, 24);
          const good = future.filter((h) => (h.precipitationProbability ?? 0) < 40 && (h.visibility ?? 20000) > 5000);
          if (!future.length) return <p className="text-xs text-muted">Select at least one destination to compute windows.</p>;
          return (
            <div className="space-y-2 text-xs">
              {good.slice(0, 4).map((h) => (
                <div key={h.time} className="glass-soft flex flex-wrap items-center justify-between gap-2 p-3">
                  <span className="text-slate-100">
                    {fmtDay(h.time, "short")} {fmtTime(h.time)}
                  </span>
                  <span className="text-muted">
                    {fmtTemp(h.temperature)} · rain chance {fmtNum(h.precipitationProbability, 0, "%")} · wind {fmtNum(h.windSpeed, 0, "km/h")}
                  </span>
                  <Badge color="#34d399">Good window</Badge>
                </div>
              ))}
              {!good.length ? (
                <p className="text-muted">
                  No clearly dry, high-visibility window appears in the next 24 hours for {picked[0]}. If travel is essential, aim for the hour with the lowest modelled rain chance.
                </p>
              ) : null}
              <p className="text-[11px] text-muted">Current location context: {location.name}.</p>
            </div>
          );
        })()}
      </Card>
    </div>
  );
}
