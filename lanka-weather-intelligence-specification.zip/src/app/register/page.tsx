import { AuthForm } from "@/components/auth-form";

export default function RegisterPage() {
  return (
    <div className="py-6">
      <AuthForm mode="register" />
    </div>
  );
}
