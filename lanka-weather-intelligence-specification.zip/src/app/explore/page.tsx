"use client";

import { Map as MlMap, NavigationControl, Popup, ScaleControl, type GeoJSONSource, type StyleSpecification } from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";
import Link from "next/link";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useApp } from "@/components/location-context";
import { useApi } from "@/components/use-api";
import { Badge, Card, EmptyState, ErrorState, ProvenanceBadge, SectionTitle, Spinner } from "@/components/ui";
import type { GridResponse } from "@/lib/types";
import { fmtNum, fmtTime, fmtDay, timeAgo } from "@/lib/format";
import { describeCode } from "@/lib/weather/codes";

type LayerId = "temperature" | "rain6" | "rain24" | "wind" | "cloud" | "humidity" | "cape" | "floodScreen";

type LayerDef = {
  id: LayerId;
  label: string;
  unit: string;
  min: number;
  max: number;
  note: string;
  colors: string[];
  value: (c: GridResponse["cells"][number]) => number | null;
  format: (v: number) => string;
};

const LAYERS: LayerDef[] = [
  {
    id: "temperature",
    label: "Temperature",
    unit: "°C",
    min: 15,
    max: 36,
    note: "Live model air temperature at 2 m for each district centre.",
    colors: ["#1d4ed8", "#22d3ee", "#34d399", "#fbbf24", "#f97316", "#f43f5e"],
    value: (c) => c.temperature,
    format: (v) => `${v.toFixed(1)}°C`,
  },
  {
    id: "rain6",
    label: "Rain next 6 h",
    unit: "mm",
    min: 0,
    max: 25,
    note: "Accumulated model precipitation expected in the next six hours.",
    colors: ["#0b2545", "#155e75", "#0ea5e9", "#22d3ee", "#a78bfa"],
    value: (c) => c.rainNext6h,
    format: (v) => `${v.toFixed(1)} mm`,
  },
  {
    id: "rain24",
    label: "Rain next 24 h",
    unit: "mm",
    min: 0,
    max: 100,
    note: "Accumulated model precipitation for the next 24 hours — the basis of the flood screening layer.",
    colors: ["#0b2545", "#155e75", "#0ea5e9", "#22d3ee", "#a78bfa", "#f43f5e"],
    value: (c) => c.rainNext24h,
    format: (v) => `${v.toFixed(1)} mm`,
  },
  {
    id: "wind",
    label: "Wind",
    unit: "km/h",
    min: 0,
    max: 50,
    note: "Model 10 m wind speed with direction from the arrow glyphs.",
    colors: ["#0f766e", "#34d399", "#fbbf24", "#f97316", "#f43f5e"],
    value: (c) => c.windSpeed,
    format: (v) => `${v.toFixed(0)} km/h`,
  },
  {
    id: "cloud",
    label: "Cloud cover",
    unit: "%",
    min: 0,
    max: 100,
    note: "Total column cloud cover from the model.",
    colors: ["#1e293b", "#475569", "#94a3b8", "#e2e8f0"],
    value: (c) => c.cloudCover,
    format: (v) => `${v.toFixed(0)}%`,
  },
  {
    id: "humidity",
    label: "Humidity",
    unit: "%",
    min: 40,
    max: 100,
    note: "Relative humidity at 2 m.",
    colors: ["#fbbf24", "#a3e635", "#22d3ee", "#2563eb"],
    value: (c) => c.humidity,
    format: (v) => `${v.toFixed(0)}%`,
  },
  {
    id: "cape",
    label: "Thunderstorm potential",
    unit: "J/kg",
    min: 0,
    max: 3000,
    note: "CAPE indicates atmospheric instability — the energy available for thunderstorms. It is potential, not a certainty, and is not a lightning detection feed.",
    colors: ["#0b2545", "#7c3aed", "#c026d3", "#f59e0b", "#f43f5e"],
    value: (c) => c.cape,
    format: (v) => `${v.toFixed(0)} J/kg`,
  },
  {
    id: "floodScreen",
    label: "Flood / slope screening",
    unit: "index",
    min: 0,
    max: 100,
    note: "LWI screening index combining model rainfall, terrain class and coastality. This is not an official DMC or NBRO warning.",
    colors: ["#0f172a", "#155e75", "#0ea5e9", "#fbbf24", "#f43f5e"],
    value: (c) => {
      const rain = (c.rainNext24h ?? 0) + (c.rainPast24h ?? 0) * 0.5;
      return Math.max(0, Math.min(100, Math.round((rain / 150) * 100)));
    },
    format: (v) => `${v.toFixed(0)}/100`,
  },
];

const ARROWS = ["↑", "↗", "→", "↘", "↓", "↙", "←", "↖"];

/** Wind direction expressed as a glyph pointing where the wind blows towards. */
function windArrow(deg: number | null): string {
  if (deg === null || !Number.isFinite(deg)) return "";
  // Meteorological direction = where wind comes FROM; arrow points where it goes.
  const towards = (deg + 180) % 360;
  return ARROWS[Math.round(towards / 45) % 8];
}

const DARK_STYLE: StyleSpecification = {
  version: 8,
  glyphs: "https://demotiles.maplibre.org/font/{fontstack}/{range}.pbf",
  sources: {
    basemap: {
      type: "raster",
      tiles: [
        "https://a.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}@2x.png",
        "https://b.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}@2x.png",
        "https://c.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}@2x.png",
      ],
      tileSize: 256,
      maxzoom: 19,
      attribution: "© OpenStreetMap contributors © CARTO",
    },
    provinces: { type: "geojson", data: "/geo/lk-provinces.geojson" },
    districts: { type: "geojson", data: "/geo/lk-districts.geojson" },
    cells: { type: "geojson", data: { type: "FeatureCollection", features: [] } },
  },
  layers: [
    { id: "bg", type: "background", paint: { "background-color": "#050d20" } },
    { id: "basemap", type: "raster", source: "basemap", paint: { "raster-opacity": 0.85 } },
    {
      id: "province-fill",
      type: "fill",
      source: "provinces",
      paint: { "fill-color": "#38bdf8", "fill-opacity": 0.04 },
    },
    {
      id: "province-line",
      type: "line",
      source: "provinces",
      paint: { "line-color": "#7dd3fc", "line-width": 1.8, "line-opacity": 0.75 },
    },
    {
      id: "district-line",
      type: "line",
      source: "districts",
      paint: { "line-color": "#a78bfa", "line-width": 0.8, "line-opacity": 0.45, "line-dasharray": [2, 2] },
    },
    {
      id: "cells-heat",
      type: "heatmap",
      source: "cells",
      layout: { visibility: "none" },
      paint: {
        "heatmap-weight": ["interpolate", ["linear"], ["coalesce", ["get", "value"], 0], 0, 0, 1, 1],
        "heatmap-intensity": 0.85,
        "heatmap-radius": 46,
        "heatmap-opacity": 0.7,
        "heatmap-color": [
          "interpolate",
          ["linear"],
          ["heatmap-density"],
          0,
          "rgba(4,10,25,0)",
          0.2,
          "#0ea5e9",
          0.4,
          "#22d3ee",
          0.6,
          "#34d399",
          0.8,
          "#fbbf24",
          1,
          "#f43f5e",
        ],
      },
    },
    {
      id: "cells-circle",
      type: "circle",
      source: "cells",
      paint: {
        "circle-radius": ["interpolate", ["linear"], ["zoom"], 5, 9, 9, 16],
        "circle-color": ["interpolate", ["linear"], ["coalesce", ["get", "value"], 0], 0, "#1e3a5f", 1, "#f43f5e"],
        "circle-stroke-color": "rgba(230,237,249,0.65)",
        "circle-stroke-width": 1,
        "circle-opacity": 0.92,
      },
    },
    {
      id: "cells-arrow",
      type: "symbol",
      source: "cells",
      minzoom: 5.5,
      layout: {
        "text-field": ["get", "arrow"],
        "text-font": ["Noto Sans Regular"],
        "text-size": 13,
        "text-offset": [0, -1.5],
        "text-anchor": "bottom",
      },
      paint: { "text-color": "#fde68a", "text-halo-color": "rgba(4,10,25,0.9)", "text-halo-width": 1.2 },
    },
    {
      id: "cells-label",
      type: "symbol",
      source: "cells",
      minzoom: 6,
      layout: {
        "text-field": ["get", "label"],
        "text-font": ["Noto Sans Regular"],
        "text-size": 10,
        "text-offset": [0, 1.4],
        "text-anchor": "top",
      },
      paint: { "text-color": "#dbeafe", "text-halo-color": "rgba(4,10,25,0.9)", "text-halo-width": 1.2 },
    },
  ],
};

export default function ExplorePage() {
  const { setLocation } = useApp();
  const { data, error, loading, reload, loadedAt } = useApi<GridResponse>("/api/weather/grid?timeline=1");
  const mapRef = useRef<MlMap | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [layer, setLayer] = useState<LayerId>("temperature");
  const [showHeat, setShowHeat] = useState(true);
  const [showDistricts, setShowDistricts] = useState(true);
  const [playing, setPlaying] = useState(false);
  const [frame, setFrame] = useState(0);
  const [selected, setSelected] = useState<GridResponse["cells"][number] | null>(null);

  const def = LAYERS.find((l) => l.id === layer) ?? LAYERS[0];

  const cells = data?.cells ?? [];
  const times = data?.timeline?.times ?? [];

  const activeValues = useMemo(() => {
    if (playing && times.length && data?.timeline) {
      return data.timeline.series.map((s) => ({ ...s, v: s.precipitation[frame] ?? null, label: `${s.name}` }));
    }
    return cells.map((c) => ({ name: c.name, district: c.district, lat: c.lat, lon: c.lon, v: def.value(c) }));
  }, [playing, times.length, data, frame, cells, def]);

  const [min, max] = useMemo(() => {
    const vals = activeValues.map((a) => a.v).filter((v): v is number => v !== null);
    if (!vals.length) return [def.min, def.max];
    const lo = Math.min(...vals);
    const hi = Math.max(...vals);
    return [lo === hi ? lo - 1 : lo, hi === lo ? hi + 1 : hi];
  }, [activeValues, def]);

  // Map init
  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;
    const map = new MlMap({
      container: containerRef.current,
      style: DARK_STYLE,
      center: [80.7, 7.7],
      zoom: 6.4,
      minZoom: 5.5,
      maxZoom: 13,
      attributionControl: { compact: true },
    });
    mapRef.current = map;
    map.addControl(new NavigationControl({ visualizePitch: false }), "top-right");
    map.addControl(new ScaleControl({ unit: "metric" }), "bottom-left");
    map.on("load", () => {
      map.setLayoutProperty("cells-heat", "visibility", showHeat ? "visible" : "none");
      map.setLayoutProperty("district-line", "visibility", showDistricts ? "visible" : "none");
    });
    map.on("click", "cells-circle", (e) => {
      const props = e.features?.[0]?.properties as { name: string; district: string; lat: number; lon: number; value: number; weatherCode: number; windSpeed: number; windDirection: number; humidity: number } | undefined;
      if (!props) return;
      setSelected({
        name: props.name,
        district: props.district,
        lat: props.lat,
        lon: props.lon,
        temperature: props.value,
        weatherCode: props.weatherCode,
        windSpeed: props.windSpeed,
        windDirection: props.windDirection,
        humidity: props.humidity,
        precipitation: null,
        cloudCover: null,
        uvIndex: null,
        cape: null,
        rainNext6h: null,
        rainNext24h: null,
        rainPast24h: null,
      });
      new Popup({ offset: 14 })
        .setLngLat([props.lon, props.lat])
        .setHTML(
          `<strong>${props.name}</strong> (${props.district})<br/>${def.label}: ${props.value !== null && props.value !== undefined ? def.format(Number(props.value)) : "n/a"}<br/>` +
            `<span style="opacity:.7">${describeCode(Number(props.weatherCode), true)} · wind ${Number(props.windSpeed).toFixed(0)} km/h · RH ${Number(props.humidity).toFixed(0)}%</span>`,
        )
        .addTo(map);
    });
    map.on("mouseenter", "cells-circle", () => (map.getCanvas().style.cursor = "pointer"));
    map.on("mouseleave", "cells-circle", () => (map.getCanvas().style.cursor = ""));
    return () => {
      map.remove();
      mapRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Push layer data into the map
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !map.isStyleLoaded() || !activeValues.length) return;
    const features = activeValues.map((a) => {
      const cell = cells.find((c) => c.name === a.name);
      return {
        type: "Feature" as const,
        properties: {
          name: a.name,
          district: a.district ?? cell?.district ?? "",
          lat: a.lat,
          lon: a.lon,
          value: a.v ?? 0,
          label: a.v === null ? "" : `${a.name} ${def.format(a.v)}`,
          weatherCode: cell?.weatherCode ?? 3,
          windSpeed: cell?.windSpeed ?? 0,
          windDirection: cell?.windDirection ?? 0,
          humidity: cell?.humidity ?? 0,
          arrow: windArrow(cell?.windDirection ?? null),
        },
        geometry: { type: "Point" as const, coordinates: [a.lon, a.lat] },
      };
    });
    (map.getSource("cells") as GeoJSONSource | undefined)?.setData({ type: "FeatureCollection", features });

    const span = max - min || 1;
    const colorStops: (number | string)[] = [];
    def.colors.forEach((color, i) => {
      colorStops.push(min + (span * i) / (def.colors.length - 1), color);
    });
    map.setPaintProperty("cells-circle", "circle-color", ["interpolate", ["linear"], ["get", "value"], ...colorStops]);
    map.setPaintProperty("cells-heat", "heatmap-weight", ["interpolate", ["linear"], ["get", "value"], min, 0, max, 1]);
    map.setLayoutProperty("cells-heat", "visibility", showHeat ? "visible" : "none");
    map.setLayoutProperty("district-line", "visibility", showDistricts ? "visible" : "none");
  }, [activeValues, cells, def, min, max, showHeat, showDistricts]);

  // Animation loop for the model precipitation timeline
  useEffect(() => {
    if (!playing || !times.length) return;
    const timer = setInterval(() => setFrame((f) => (f + 1) % times.length), 650);
    return () => clearInterval(timer);
  }, [playing, times.length]);

  const legendStops = def.colors.map((color, i) => ({ color, value: min + ((max - min) * i) / (def.colors.length - 1) }));

  const ranked = useMemo(() => {
    return [...cells]
      .map((c) => ({ ...c, metric: def.value(c) }))
      .filter((c) => c.metric !== null)
      .sort((a, b) => (b.metric ?? 0) - (a.metric ?? 0));
  }, [cells, def]);

  const jump = useCallback(
    (lat: number, lon: number) => {
      mapRef.current?.flyTo({ center: [lon, lat], zoom: 9, speed: 0.9 });
    },
    [],
  );

  return (
    <div className="space-y-4">
      <Card>
        <SectionTitle
          title="Interactive Sri Lanka weather map"
          subtitle="Live model values sampled at every district centre plus key towns. Switch layers, animate the model precipitation timeline and click any point for detail."
          right={<ProvenanceBadge provider={data?.provenance.provider ?? "Open-Meteo"} model={data?.provenance.model} fetchedAt={loadedAt} degraded={data?.provenance.degraded} />}
        />
        <div className="flex flex-wrap gap-1.5">
          {LAYERS.map((l) => (
            <button
              key={l.id}
              onClick={() => {
                setLayer(l.id);
                setPlaying(false);
              }}
              className={`focus-ring rounded-lg px-3 py-1.5 text-xs font-medium transition ${
                layer === l.id ? "bg-gradient-to-r from-sky-500/30 to-violet-500/20 text-white ring-1 ring-sky-300/30" : "border border-sky-400/15 text-slate-300 hover:bg-sky-500/10"
              }`}
            >
              {l.label}
            </button>
          ))}
        </div>
        <p className="mt-2 text-[11px] text-muted">{def.note}</p>
        <div className="mt-2 flex flex-wrap items-center gap-3 text-[11px]">
          <label className="flex items-center gap-1.5 text-slate-300">
            <input type="checkbox" checked={showHeat} onChange={(e) => setShowHeat(e.target.checked)} className="accent-sky-400" /> Smooth heat surface
          </label>
          <label className="flex items-center gap-1.5 text-slate-300">
            <input type="checkbox" checked={showDistricts} onChange={(e) => setShowDistricts(e.target.checked)} className="accent-violet-400" /> District boundaries
          </label>
          <Badge color="#38bdf8">Province + district boundaries: geoBoundaries (open licence)</Badge>
        </div>
      </Card>

      {error ? (
        <ErrorState title="Weather layers unavailable" message={`${error} The map still shows administrative boundaries, but no weather values are drawn, because none can be verified right now.`} onRetry={reload} />
      ) : null}

      <div className="grid gap-4 xl:grid-cols-[1fr_320px]">
        <Card className="!p-3">
          <div className="relative overflow-hidden rounded-xl border border-sky-400/15">
            <div ref={containerRef} className="h-[560px] w-full" />
            {loading ? (
              <div className="absolute inset-x-0 top-0 flex justify-center p-2">
                <div className="glass px-3 py-1.5 text-xs text-sky-200">Loading live grid…</div>
              </div>
            ) : null}
            {/* Legend */}
            <div className="pointer-events-none absolute bottom-3 left-3 glass max-w-[220px] p-3">
              <p className="text-[11px] font-medium text-slate-100">{def.label}</p>
              <div className="mt-1.5 flex h-2.5 w-full overflow-hidden rounded-full">
                {def.colors.map((c) => (
                  <span key={c} className="h-full flex-1" style={{ background: c }} />
                ))}
              </div>
              <div className="mt-1 flex justify-between text-[10px] text-muted">
                <span>{def.format(min)}</span>
                <span>{def.format(max)}</span>
              </div>
              <div className="mt-1.5 space-y-0.5">
                {legendStops.map((s) => (
                  <div key={s.color} className="flex items-center gap-1.5 text-[10px] text-muted">
                    <span className="h-2 w-2 rounded-full" style={{ background: s.color }} />
                    {def.format(s.value)}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {times.length ? (
            <div className="mt-3 glass-soft p-3">
              <div className="flex flex-wrap items-center gap-3">
                <button
                  onClick={() => setPlaying((p) => !p)}
                  className="focus-ring rounded-lg border border-sky-400/30 bg-sky-500/15 px-3 py-1.5 text-xs font-medium text-sky-100"
                >
                  {playing ? "Pause timeline" : "Play precipitation timeline"}
                </button>
                <input
                  type="range"
                  min={0}
                  max={Math.max(0, times.length - 1)}
                  value={frame}
                  onChange={(e) => {
                    setPlaying(false);
                    setFrame(Number(e.target.value));
                  }}
                  className="min-w-[180px] flex-1 accent-sky-400"
                  aria-label="Timeline position"
                />
                <span className="text-xs text-slate-200">
                  {fmtDay(times[frame])} {fmtTime(times[frame])}
                </span>
              </div>
              <p className="mt-1.5 text-[11px] text-muted">
                Timeline shows hourly model precipitation, not observed radar. Sri Lanka has no open radar tile feed, so this layer animates verified model output from Open-Meteo instead.
              </p>
            </div>
          ) : null}
        </Card>

        <div className="space-y-4">
          <Card>
            <SectionTitle title="Layer source & freshness" />
            <p className="text-xs leading-relaxed text-muted">{data?.layerNotice}</p>
            <p className="mt-2 text-[11px] text-muted">
              Last retrieved {timeAgo(loadedAt)} · {cells.length} sample points · refresh target 10 minutes.
            </p>
          </Card>

          <Card>
            <SectionTitle title="Highest right now" subtitle={`Ranked by ${def.label.toLowerCase()}`} />
            <div className="space-y-1.5">
              {ranked.slice(0, 8).map((c) => (
                <button
                  key={c.name}
                  onClick={() => jump(c.lat, c.lon)}
                  className="focus-ring flex w-full items-center justify-between gap-2 rounded-lg px-2 py-1.5 text-left text-xs hover:bg-sky-500/10"
                >
                  <span className="min-w-0">
                    <span className="block truncate text-slate-100">{c.name}</span>
                    <span className="block truncate text-[10px] text-muted">{c.district}</span>
                  </span>
                  <span className="shrink-0 font-medium text-sky-200">{c.metric === null ? "—" : def.format(c.metric)}</span>
                </button>
              ))}
              {!ranked.length ? <EmptyState title="No readings yet" message="Waiting for the live grid to load." /> : null}
            </div>
          </Card>

          {selected ? (
            <Card>
              <SectionTitle title={selected.name} subtitle={`${selected.district} District · ${selected.lat.toFixed(3)}°N ${selected.lon.toFixed(3)}°E`} />
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="glass-soft p-2.5">
                  <p className="text-muted">Condition</p>
                  <p className="mt-0.5 text-slate-100">{describeCode(selected.weatherCode ?? 3, true)}</p>
                </div>
                <div className="glass-soft p-2.5">
                  <p className="text-muted">Temperature</p>
                  <p className="mt-0.5 text-slate-100">{fmtNum(selected.temperature, 1, "°C")}</p>
                </div>
                <div className="glass-soft p-2.5">
                  <p className="text-muted">Wind</p>
                  <p className="mt-0.5 text-slate-100">{fmtNum(selected.windSpeed, 0, "km/h")}</p>
                </div>
                <div className="glass-soft p-2.5">
                  <p className="text-muted">Humidity</p>
                  <p className="mt-0.5 text-slate-100">{fmtNum(selected.humidity, 0, "%")}</p>
                </div>
              </div>
              <button
                onClick={() => {
                  setLocation({ name: selected.name, lat: selected.lat, lon: selected.lon, district: selected.district, province: "" });
                }}
                className="focus-ring mt-3 w-full rounded-lg border border-sky-400/30 bg-sky-500/15 px-3 py-2 text-xs text-sky-100"
              >
                Set {selected.name} as my location
              </button>
              <Link href={`/forecast`} className="focus-ring mt-2 block rounded-lg border border-sky-400/20 px-3 py-2 text-center text-xs text-slate-300">
                Open full forecast
              </Link>
            </Card>
          ) : (
            <Card>
              <EmptyState title="Click a point on the map" message="Select any sample point to read its live values and make it your active location." />
            </Card>
          )}
        </div>
      </div>

      {data?.advisories?.length ? (
        <Card>
          <SectionTitle title="Screening raised on this grid" subtitle="Model-derived only. Official advisories appear in the Alerts section when the feeds are reachable." />
          <div className="flex flex-wrap gap-2">
            {data.advisories.slice(0, 12).map((a) => (
              <Badge key={a.dedupeKey} color={a.severity === "warning" ? "#f43f5e" : a.severity === "watch" ? "#f97316" : "#eab308"}>
                {a.areas?.[0] ?? "—"} · {a.hazard} · {a.severity}
              </Badge>
            ))}
          </div>
        </Card>
      ) : null}
    </div>
  );
}
