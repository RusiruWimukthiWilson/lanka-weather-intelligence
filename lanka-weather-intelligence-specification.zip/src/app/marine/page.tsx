"use client";

import Link from "next/link";
import { useState } from "react";
import { useApi } from "@/components/use-api";
import { Badge, Card, EmptyState, ErrorState, OriginTag, ProvenanceBadge, SectionTitle, Spinner, Stat } from "@/components/ui";
import { WaveChart, WindChart } from "@/components/charts";
import type { MarineResponse } from "@/lib/types";
import { DISTRICTS } from "@/lib/lk-geo";
import { beaufortLabel, compassDirection } from "@/lib/weather/codes";
import { fmtDay, fmtNum, fmtTime } from "@/lib/format";
import { useApi as useApiGeneric } from "@/components/use-api";
import type { AlertsResponse } from "@/lib/types";

const COASTAL = DISTRICTS.filter((d) => d.coastal);

function seaState(wave: number | null): { label: string; color: string } {
  if (wave === null) return { label: "unknown", color: "#94a3b8" };
  if (wave < 0.5) return { label: "Calm (glassy)", color: "#34d399" };
  if (wave < 1.25) return { label: "Slight", color: "#a3e635" };
  if (wave < 2.5) return { label: "Moderate", color: "#fbbf24" };
  if (wave < 4) return { label: "Rough", color: "#f97316" };
  if (wave < 6) return { label: "Very rough", color: "#f43f5e" };
  return { label: "High / phenomenal", color: "#a855f7" };
}

export default function MarinePage() {
  const [key, setKey] = useState("Galle");
  const district = COASTAL.find((d) => d.name === key) ?? COASTAL[0];
  const url = `/api/weather/marine?lat=${district.lat}&lon=${district.lon}&name=${encodeURIComponent(district.capital)}&district=${encodeURIComponent(district.name)}`;
  const { data, error, loading, reload, loadedAt } = useApi<MarineResponse>(url, [key]);
  const alerts = useApiGeneric<AlertsResponse>("/api/alerts?refresh=0&history=0", []);
  const marineAlerts = (alerts.data?.alerts ?? []).filter((a) => a.hazard === "marine");

  const wave = data?.marine.current.waveHeight ?? null;
  const state = seaState(wave);

  if (error) return <ErrorState title="Marine module unavailable" message={error} onRetry={reload} />;

  return (
    <div className="space-y-5">
      <Card>
        <SectionTitle
          title="Marine & coastal conditions"
          subtitle="Wave model output blended with coastal wind. Official sea-area bulletins are issued by the Sri Lanka Department of Meteorology — always confirm before sailing."
          right={<ProvenanceBadge provider={data?.marine.provenance.provider ?? "ECMWF WAM via Open-Meteo Marine"} model={data?.marine.provenance.model} fetchedAt={loadedAt} degraded={data?.marine.provenance.degraded} />}
        />
        <label className="text-xs text-muted">
          Coastal district
          <select value={key} onChange={(e) => setKey(e.target.value)} className="focus-ring mt-1 block w-60 rounded-lg border border-sky-400/20 bg-[#0a1733] px-2.5 py-2 text-xs text-slate-100">
            {COASTAL.map((d) => (
              <option key={d.name} value={d.name}>
                {d.name} — {d.marineArea}
              </option>
            ))}
          </select>
        </label>
      </Card>

      {loading ? <Card><Spinner label="Reading the wave model…" /></Card> : null}

      {data ? (
        <>
          {data.marine.available ? (
            <>
              <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
                <Stat label="Significant wave height" value={fmtNum(wave, 2)} unit="m" tone={wave !== null && wave >= 2.5 ? "bad" : wave !== null && wave >= 1.25 ? "warn" : "good"} hint={state.label} />
                <Stat label="Wave period" value={fmtNum(data.marine.current.wavePeriod, 1)} unit="s" hint="Time between wave crests" />
                <Stat label="Wave direction" value={compassDirection(data.marine.current.waveDirection)} hint={fmtNum(data.marine.current.waveDirection, 0, "°")} />
                <Stat label="Swell height" value={fmtNum(data.marine.current.swellHeight, 2)} unit="m" />
                <Stat label="Sea surface temp" value={fmtNum(data.marine.current.seaSurfaceTemperature, 1)} unit="°C" />
                <Stat label="Coastal wind" value={fmtNum(data.wind.current?.speed, 0)} unit="km/h" hint={`${compassDirection(data.wind.current?.direction)} · ${beaufortLabel(data.wind.current?.speed ?? 0)}`} />
              </div>

              <div className="grid gap-4 lg:grid-cols-2">
                <Card>
                  <SectionTitle title="Wave height (5 days)" subtitle="Significant wave height in metres from the ECMWF WAM model." />
                  <WaveChart data={data.marine.hourly.slice(0, 120).map((h) => ({ label: `${fmtDay(h.time, "short")} ${fmtTime(h.time)}`, waveHeight: h.waveHeight }))} height={220} />
                </Card>
                <Card>
                  <SectionTitle title="Coastal wind (48 h)" subtitle="Sustained wind and gusts at the coastal grid point." />
                  <WindChart data={data.wind.hourly.slice(0, 48).map((h) => ({ label: fmtTime(h.time), speed: h.speed, gust: h.gust }))} height={220} />
                </Card>
              </div>

              <Card>
                <SectionTitle title="Operational guidance for fishing community" subtitle="Screened from the model values above." />
                <div className="grid gap-3 md:grid-cols-3">
                  <div className="glass-soft p-3">
                    <Badge color={state.color}>Sea state: {state.label}</Badge>
                    <p className="mt-2 text-xs text-muted">
                      {wave !== null && wave < 1.25
                        ? "Conditions suitable for small craft and day boats in sheltered waters; still confirm the official bulletin."
                        : wave !== null && wave < 2.5
                          ? "Moderate seas — small craft should stay close to shore and secure gear."
                          : "Rough or worse seas expected; multiday boats should delay departure and small craft must remain in port."}
                    </p>
                  </div>
                  <div className="glass-soft p-3">
                    <Badge color={(data.wind.current?.speed ?? 0) >= 40 ? "#f43f5e" : "#34d399"}>Wind: {beaufortLabel(data.wind.current?.speed ?? 0)}</Badge>
                    <p className="mt-2 text-xs text-muted">
                      {fmtNum(data.wind.current?.speed, 0, "km/h")} from {compassDirection(data.wind.current?.direction)}, gusting {fmtNum(data.wind.current?.gust, 0, "km/h")}. Above 40 km/h, landing on open beaches becomes hazardous.
                    </p>
                  </div>
                  <div className="glass-soft p-3">
                    <Badge color="#38bdf8">Area</Badge>
                    <p className="mt-2 text-xs text-muted">
                      {district.marineArea} sea area · {district.name} District coastline. Model point: {data.location.lat.toFixed(2)}°N {data.location.lon.toFixed(2)}°E.
                    </p>
                  </div>
                </div>
                <p className="mt-3 text-[11px] text-amber-200/90">
                  This module cannot verify official fishing bans or naval advisories. Treat it as weather context only.
                </p>
              </Card>
            </>
          ) : (
            <EmptyState
              title="Wave model has no data for this point"
              message={data.marine.reason ?? "The marine grid does not cover this coordinate (it may be inland or outside the model domain). No wave values are estimated in its place."}
              action={
                <button onClick={reload} className="focus-ring rounded-lg border border-sky-400/30 bg-sky-500/15 px-3 py-2 text-xs text-sky-100">
                  Try again
                </button>
              }
            />
          )}

          <Card>
            <SectionTitle title="Sea-area screening records" subtitle="Model-derived only. Official bulletins come from the Department of Meteorology." />
            {marineAlerts.length ? (
              <div className="space-y-2">
                {marineAlerts.map((a) => (
                  <div key={a.id} className="glass-soft p-3">
                    <div className="flex flex-wrap items-center gap-2">
                      <OriginTag origin={a.origin} authority={a.authority} />
                      <Badge color={a.severity === "warning" ? "#f43f5e" : a.severity === "watch" ? "#f97316" : "#eab308"}>{a.severity}</Badge>
                    </div>
                    <p className="mt-1.5 text-sm text-slate-100">{a.title}</p>
                    <p className="mt-1 text-xs text-muted">{a.summary}</p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-muted">No marine screening currently exceeds 40 km/h coastal wind in the active grid.</p>
            )}
            <Link href="/alerts" className="focus-ring mt-3 inline-block rounded-lg border border-sky-400/30 bg-sky-500/15 px-3 py-2 text-xs text-sky-100">
              Open the full alert centre
            </Link>
          </Card>
        </>
      ) : null}
    </div>
  );
}
