"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { useApp } from "@/components/location-context";
import { useApi } from "@/components/use-api";
import { Badge, Card, ErrorState, ProvenanceBadge, SectionTitle, Spinner, Stat } from "@/components/ui";
import { MiniBarChart } from "@/components/charts";
import type { WeatherResponse } from "@/lib/types";
import { DISTRICTS } from "@/lib/lk-geo";
import { intensityFromMm, beaufortLabel } from "@/lib/weather/codes";
import { fmtDay, fmtNum, fmtTemp, fmtTime } from "@/lib/format";

const CROPS = [
  { name: "Rice (paddy)", season: "Maha: Oct–Mar · Yala: Apr–Sep", rainNeed: "900–1500 mm per season", note: "Sensitive to flooding at tillering and to dry spells at flowering." },
  { name: "Tea", season: "Year-round with two flush peaks", rainNeed: "1750–2500 mm/year, well distributed", note: "Frost risk above 1500 m in Dec–Jan; leaf disease rises in very wet spells." },
  { name: "Coconut", season: "Year-round", rainNeed: "1200–2500 mm/year", note: "Moisture stress cuts nut yield 8–10 months later." },
  { name: "Vegetables (up-country)", season: "Maha & Yala windows", rainNeed: "600–1000 mm/season", note: "Heavy rain damages flowers and increases downy mildew pressure." },
  { name: "Chilli & onion (dry zone)", season: "Yala preferred", rainNeed: "600–900 mm with drainage", note: "Waterlogging is the main risk; needs raised beds in Maha." },
];

function seasonInfo(date: Date) {
  const m = date.getMonth() + 1;
  if (m >= 10 || m <= 3) {
    return { name: "Maha", si: "මහ කන්නය", ta: "மகா பருவம்", window: "October – March (north-east monsoon dominant)", advice: "Land preparation and sowing peak in October–November; harvest runs from late February." };
  }
  if (m >= 4 && m <= 9) {
    return { name: "Yala", si: "යල කන්නය", ta: "யாலா பருவம்", window: "April – September (south-west monsoon then inter-monsoon)", advice: "Sow with the April–May rains; the dry zone depends heavily on irrigation from July." };
  }
  return { name: "Inter-monsoon", si: "අතුරු කන්නය", ta: "இடைப்பருவம்", window: "Transition period", advice: "Short, sharp showers are common; plan drainage and stagger planting." };
}

export default function AgriculturePage() {
  const { location } = useApp();
  const [district, setDistrict] = useState(location.district || "Kurunegala");
  const info = DISTRICTS.find((d) => d.name === district) ?? DISTRICTS[17];
  const url = `/api/weather?lat=${info.lat}&lon=${info.lon}&name=${encodeURIComponent(info.capital)}&district=${encodeURIComponent(info.name)}`;
  const { data, error, loading, reload, loadedAt } = useApi<WeatherResponse>(url, [district]);

  const next7 = useMemo(() => (data?.daily ?? []).slice(0, 7), [data]);
  const rain7 = next7.reduce((a, d) => a + (d.precipitationSum ?? 0), 0);
  const season = seasonInfo(new Date());

  const hourly = useMemo(() => (data?.hourly ?? []).filter((h) => new Date(h.time).getTime() >= Date.now() - 3600 * 1000).slice(0, 72), [data]);
  const sprayWindows = hourly.filter((h) => (h.windSpeed ?? 0) < 15 && (h.precipitationProbability ?? 0) < 40).slice(0, 4);
  const irrigationPressure = rain7 < 20;

  if (error) return <ErrorState title="Agriculture data unavailable" message={error} onRetry={reload} />;

  return (
    <div className="space-y-5">
      <Card>
        <SectionTitle
          title="Agricultural weather intelligence"
          subtitle={`${info.name} District (${info.province}) · ${info.terrain.replace("-", " ")} terrain · season-aware guidance from live model data`}
          right={<ProvenanceBadge provider={data?.provenance.provider ?? "Open-Meteo"} model={data?.provenance.model} fetchedAt={loadedAt} degraded={data?.provenance.degraded} />}
        />
        <div className="flex flex-wrap items-end gap-3">
          <label className="text-xs text-muted">
            District
            <select value={district} onChange={(e) => setDistrict(e.target.value)} className="focus-ring mt-1 block w-56 rounded-lg border border-sky-400/20 bg-[#0a1733] px-2.5 py-2 text-xs text-slate-100">
              {DISTRICTS.map((d) => (
                <option key={d.name} value={d.name}>
                  {d.name} — {d.province}
                </option>
              ))}
            </select>
          </label>
          {loading ? <Spinner label="Loading agri-meteorology…" /> : null}
        </div>
      </Card>

      {data ? (
        <>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
            <Stat label="Rain next 7 days" value={fmtNum(rain7, 1)} unit="mm" hint={intensityFromMm(rain7 / 7).label + " daily average"} />
            <Stat label="Irrigation pressure" value={irrigationPressure ? "High" : rain7 < 45 ? "Moderate" : "Low"} tone={irrigationPressure ? "bad" : rain7 < 45 ? "warn" : "good"} hint="Based on modelled 7-day totals only" />
            <Stat label="Max temp (7 d)" value={fmtTemp(Math.max(...next7.map((d) => d.tempMax ?? 0)))} hint="Heat stress above 35 °C for many crops" tone={Math.max(...next7.map((d) => d.tempMax ?? 0)) >= 35 ? "warn" : "default"} />
            <Stat label="Min temp (7 d)" value={fmtTemp(Math.min(...next7.map((d) => d.tempMin ?? 99)))} hint={Math.min(...next7.map((d) => d.tempMin ?? 99)) <= 12 ? "Frost watch for highland tea" : "No frost signal"} />
            <Stat label="Max wind (7 d)" value={fmtNum(Math.max(...next7.map((d) => d.windSpeedMax ?? 0)), 0)} unit="km/h" hint={beaufortLabel(Math.max(...next7.map((d) => d.windSpeedMax ?? 0)))} />
            <Stat label="Current RH" value={fmtNum(data.current?.humidity, 0)} unit="%" hint={data.current?.dewPoint !== null ? `Dew point ${fmtTemp(data.current?.dewPoint)}` : undefined} />
          </div>

          <div className="grid gap-4 lg:grid-cols-2">
            <Card>
              <SectionTitle title="7-day rainfall outlook" subtitle="Daily model precipitation totals (mm) for the selected district." />
              <MiniBarChart data={next7.map((d) => ({ label: fmtDay(d.date, "short"), value: d.precipitationSum ?? 0 }))} />
              <div className="mt-3 space-y-1.5 text-xs">
                {next7.slice(0, 4).map((d) => (
                  <div key={d.date} className="flex flex-wrap items-center justify-between gap-2 text-muted">
                    <span className="text-slate-200">{fmtDay(d.date, "long")}</span>
                    <span>
                      {fmtNum(d.precipitationSum, 1, "mm")} · {fmtNum(d.precipitationHours, 0)} rain hours · {fmtTemp(d.tempMax)}/{fmtTemp(d.tempMin)}
                    </span>
                  </div>
                ))}
              </div>
            </Card>

            <Card>
              <SectionTitle title="Season status" subtitle="Sri Lanka's two cultivation seasons" />
              <div className="glass-soft p-4">
                <div className="flex flex-wrap items-center gap-2">
                  <Badge color="#34d399">{season.name}</Badge>
                  <Badge color="#38bdf8">{season.si}</Badge>
                  <Badge color="#a78bfa">{season.ta}</Badge>
                </div>
                <p className="mt-2 text-sm text-slate-100">{season.window}</p>
                <p className="mt-1 text-xs text-muted">{season.advice}</p>
              </div>
              <p className="mt-3 text-xs text-muted">
                District terrain is classified as <span className="text-slate-200">{info.terrain.replace("-", " ")}</span>. In {info.terrain === "dry-plain" ? "dry-zone districts most Yala cultivation depends on irrigation tanks, so rainfall deficits matter sooner." : info.terrain === "highland" || info.terrain === "hill-country" ? "hill-country districts slope failure and erosion are the main rainfall hazards." : "lowland districts drainage and waterlogging dominate the risk profile."}
              </p>
            </Card>
          </div>

          <div className="grid gap-4 lg:grid-cols-3">
            <Card>
              <SectionTitle title="Spraying & field-work windows" subtitle="Hours with wind under 15 km/h and rain chance under 40%." />
              {sprayWindows.length ? (
                <div className="space-y-1.5 text-xs">
                  {sprayWindows.map((h) => (
                    <div key={h.time} className="flex items-center justify-between rounded-lg bg-emerald-400/10 px-3 py-2">
                      <span className="text-slate-100">
                        {fmtDay(h.time, "short")} {fmtTime(h.time)}
                      </span>
                      <span className="text-muted">
                        wind {fmtNum(h.windSpeed, 0, "km/h")} · chance {fmtNum(h.precipitationProbability, 0, "%")}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-muted">No suitable window in the next 72 hours — conditions are either too windy or too wet for spraying.</p>
              )}
            </Card>

            <Card>
              <SectionTitle title="Irrigation planning" subtitle="Derived only from modelled rainfall — no soil-moisture sensor input" />
              <p className="text-xs leading-relaxed text-muted">
                {irrigationPressure
                  ? `Only ${fmtNum(rain7, 1, "mm")} is modelled over the next 7 days for ${info.name}. For paddy that is well below evapotranspiration demand, so schedule tank/ canal issues and consider supplemental irrigation for vegetables.`
                  : `Modelled rainfall of ${fmtNum(rain7, 1, "mm")} over 7 days should cover a meaningful share of crop water demand. Keep drainage paths open for the heavier days.`}
              </p>
              <p className="mt-2 text-[11px] text-amber-200/90">
                Soil moisture is not available from an open forecast model, so this page cannot report it. Use Department of Agriculture / Irrigation Department field data for final decisions.
              </p>
            </Card>

            <Card>
              <SectionTitle title="Farming notifications" subtitle="Get district advisories in your notification centre" />
              <p className="text-xs text-muted">
                Subscribe to {info.name} District and include the rain, heat and landslide categories to receive irrigation-relevant screening and slope-stability notices.
              </p>
              <Link href="/alerts" className="focus-ring mt-3 inline-block rounded-lg border border-sky-400/30 bg-sky-500/15 px-3 py-2 text-xs text-sky-100">
                Manage district subscriptions
              </Link>
            </Card>
          </div>

          <Card>
            <SectionTitle title="Crop notes" subtitle="General agronomic requirements — not a substitute for Department of Agriculture extension advice." />
            <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
              {CROPS.map((c) => (
                <div key={c.name} className="glass-soft p-3">
                  <p className="text-sm font-medium text-slate-100">{c.name}</p>
                  <p className="mt-1 text-[11px] text-muted">{c.season}</p>
                  <p className="mt-1 text-[11px] text-sky-200">Water: {c.rainNeed}</p>
                  <p className="mt-1 text-[11px] text-muted">{c.note}</p>
                </div>
              ))}
            </div>
          </Card>

          <Card>
            <ProvenanceBadge provider={`${data.provenance.provider} · ${data.provenance.attribution}`} model={data.provenance.model} fetchedAt={loadedAt ?? data.provenance.fetchedAt} stale={data.provenance.stale} />
          </Card>
        </>
      ) : null}
    </div>
  );
}
