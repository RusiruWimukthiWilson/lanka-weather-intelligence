import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { AppShell } from "@/components/app-shell";
import "./globals.css";

export const metadata: Metadata = {
  title: "Lanka Weather Intelligence — Understand Your Weather. Protect Your Tomorrow.",
  description:
    "Live, location-aware weather intelligence for all 9 provinces and 25 districts of Sri Lanka: forecasts, interactive maps, official advisory tracking, marine and agriculture modules, community reports and an AI weather assistant.",
  applicationName: "Lanka Weather Intelligence",
  keywords: ["Sri Lanka weather", "Colombo weather", "Sri Lanka forecast", "DMC alerts", "marine weather Sri Lanka", "agriculture weather"],
  manifest: "/manifest.webmanifest",
};

export const viewport: Viewport = {
  themeColor: "#050d20",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="antialiased">
        <AppShell>{children}</AppShell>
      </body>
    </html>
  );
}
