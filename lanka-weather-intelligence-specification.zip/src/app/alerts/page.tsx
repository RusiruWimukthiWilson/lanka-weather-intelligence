"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { useApp } from "@/components/location-context";
import { useApi } from "@/components/use-api";
import { Badge, Card, EmptyState, ErrorState, OriginTag, ProvenanceBadge, SectionTitle, Spinner } from "@/components/ui";
import type { AlertsResponse } from "@/lib/types";
import { DISTRICTS } from "@/lib/lk-geo";
import { HAZARD_LABELS } from "@/lib/advisory";
import { fmtDateTime, severityColor, severityLabel, timeAgo } from "@/lib/format";

const HAZARDS = ["rain", "flood", "landslide", "lightning", "wind", "cyclone", "heat", "marine"];

function asStringArray(value: unknown): string[] {
  return Array.isArray(value) ? (value as string[]) : [];
}

export default function AlertsPage() {
  const { location, user, refreshFavourites } = useApp();
  const [district, setDistrict] = useState<string>(location.district || "");
  const [hazard, setHazard] = useState<string>("");
  const [tab, setTab] = useState<"active" | "history">("active");
  const [busy, setBusy] = useState<string | null>(null);
  const [flash, setFlash] = useState<string | null>(null);

  const url = `/api/alerts?district=${encodeURIComponent(district)}&history=1&refresh=${tab === "active" ? "1" : "0"}`;
  const { data, error, loading, reload, loadedAt } = useApi<AlertsResponse>(url, [district, hazard, tab]);

  const rows = useMemo(() => {
    const list = tab === "active" ? (data?.alerts ?? []) : (data?.history ?? []);
    return hazard ? list.filter((a) => a.hazard === hazard) : list;
  }, [data, tab, hazard]);

  async function subscribe(targetDistrict: string) {
    setBusy(targetDistrict);
    setFlash(null);
    try {
      const res = await fetch("/api/subscriptions", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ scopeType: "district", scopeLabel: targetDistrict, district: targetDistrict, categories: ["rain", "flood", "landslide", "lightning", "wind", "heat", "marine"], minimumSeverity: "advisory" }),
      });
      const body = (await res.json()) as { error?: string };
      if (!res.ok) {
        setFlash(body.error ?? "Could not save the subscription.");
        if (res.status === 401) setTimeout(() => window.location.assign("/login?next=/alerts"), 900);
      } else {
        setFlash(`Watching ${targetDistrict} District. Run the notification engine to check for new advisories.`);
        await refreshFavourites();
      }
    } finally {
      setBusy(null);
    }
  }

  async function runEngine() {
    setBusy("engine");
    setFlash(null);
    try {
      const res = await fetch("/api/notifications", { method: "POST" });
      const body = (await res.json()) as { error?: string; engine?: { notificationsCreated: number; checkedSubscriptions: number; skippedQuietHours: number } };
      if (!res.ok) {
        setFlash(body.error ?? "Engine run failed.");
        return;
      }
      setFlash(
        body.engine
          ? `Checked ${body.engine.checkedSubscriptions} subscription(s): ${body.engine.notificationsCreated} new notification(s) created, ${body.engine.skippedQuietHours} deferred by quiet hours.`
          : "Engine finished.",
      );
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="space-y-5">
      <Card>
        <SectionTitle
          title="National weather alert centre"
          subtitle="Official advisories are ingested from public Sri Lankan authority feeds where reachable. Everything else is transparent model screening with published thresholds and evidence."
          right={<ProvenanceBadge provider="DMC / Met Department feeds + LWI model screening" fetchedAt={loadedAt} />}
        />

        <div
          className={`mb-4 rounded-xl border p-3 text-xs ${
            data?.officialFeed.status === "ok" ? "border-emerald-400/25 bg-emerald-400/10 text-emerald-100" : "border-amber-400/25 bg-amber-400/10 text-amber-100"
          }`}
        >
          <p className="font-medium">
            Official feed status: {data?.officialFeed.status ?? "checking"} · checked {data?.officialFeed.checkedAt ? timeAgo(data.officialFeed.checkedAt) : "—"}
          </p>
          <p className="mt-1 opacity-90">{data?.officialFeed.note}</p>
          <p className="mt-1 opacity-80">
            Emergency contacts: DMC 117 · Police 119 · Ambulance 1990. Never rely on this platform alone for life-safety decisions.
          </p>
        </div>

        <div className="flex flex-wrap items-end gap-3">
          <label className="text-xs text-muted">
            District
            <select
              value={district}
              onChange={(e) => setDistrict(e.target.value)}
              className="focus-ring mt-1 block w-52 rounded-lg border border-sky-400/20 bg-[#0a1733] px-2.5 py-2 text-xs text-slate-100"
            >
              <option value="">All districts</option>
              {DISTRICTS.map((d) => (
                <option key={d.name} value={d.name}>
                  {d.name} ({d.province})
                </option>
              ))}
            </select>
          </label>
          <label className="text-xs text-muted">
            Hazard
            <select value={hazard} onChange={(e) => setHazard(e.target.value)} className="focus-ring mt-1 block w-48 rounded-lg border border-sky-400/20 bg-[#0a1733] px-2.5 py-2 text-xs text-slate-100">
              <option value="">All hazards</option>
              {HAZARDS.map((h) => (
                <option key={h} value={h}>
                  {HAZARD_LABELS[h] ?? h}
                </option>
              ))}
            </select>
          </label>
          <div className="flex gap-1.5">
            {(["active", "history"] as const).map((tb) => (
              <button key={tb} onClick={() => setTab(tb)} className={`focus-ring rounded-lg px-3 py-2 text-xs capitalize ${tab === tb ? "bg-sky-500/25 text-sky-100" : "border border-sky-400/20 text-slate-300"}`}>
                {tb} ({tb === "active" ? (data?.counts.active ?? 0) : (data?.history.length ?? 0)})
              </button>
            ))}
          </div>
          <button onClick={reload} className="focus-ring rounded-lg border border-sky-400/25 px-3 py-2 text-xs text-slate-200">
            Refresh
          </button>
          {user ? (
            <div className="flex flex-wrap gap-2">
              <button onClick={() => subscribe(district || location.district || "Colombo")} disabled={busy !== null} className="focus-ring rounded-lg border border-violet-400/30 bg-violet-500/15 px-3 py-2 text-xs text-violet-100 disabled:opacity-50">
                {busy ? "Saving…" : `Watch ${district || location.district || "Colombo"}`}
              </button>
              <button onClick={runEngine} disabled={busy !== null} className="focus-ring rounded-lg border border-sky-400/30 bg-sky-500/15 px-3 py-2 text-xs text-sky-100 disabled:opacity-50">
                {busy === "engine" ? "Running…" : "Run notification engine"}
              </button>
            </div>
          ) : (
            <Link href="/login?next=/alerts" className="focus-ring rounded-lg border border-sky-400/30 bg-sky-500/15 px-3 py-2 text-xs text-sky-100">
              Sign in for personalised notifications
            </Link>
          )}
        </div>
        {flash ? <p className="mt-3 rounded-lg border border-sky-400/20 bg-sky-500/10 px-3 py-2 text-xs text-sky-100">{flash}</p> : null}
      </Card>

      {error ? <ErrorState title="Alert service error" message={error} onRetry={reload} /> : null}
      {loading ? <Card><Spinner label="Loading alert records…" /></Card> : null}

      {!loading && !rows.length ? (
        <EmptyState
          title="No matching records"
          message="Nothing currently crosses the screening thresholds for this filter. That is not the same as an all-clear — official advisories may still be in force."
          action={
            <Link href="/explore" className="focus-ring rounded-lg border border-sky-400/30 bg-sky-500/15 px-3 py-2 text-xs text-sky-100">
              Open the weather map
            </Link>
          }
        />
      ) : null}

      <div className="grid gap-3 xl:grid-cols-2">
        {rows.map((a) => {
          const color = severityColor(a.severity);
          return (
            <Card key={a.id} className="!p-4">
              <div className="flex flex-wrap items-center gap-2">
                <Badge color={color}>{severityLabel(a.severity)}</Badge>
                <OriginTag origin={a.origin} authority={a.authority} />
                <Badge color="#94a3b8">{HAZARD_LABELS[a.hazard] ?? a.hazard}</Badge>
                {a.source === "model-lwi" ? null : <Badge color="#38bdf8">feed: {a.source}</Badge>}
              </div>
              <h3 className="mt-2 text-sm font-semibold text-slate-50">{a.title}</h3>
              <p className="mt-1.5 text-xs leading-relaxed text-muted">{a.summary}</p>

              {asStringArray(a.areas).length ? (
                <p className="mt-2 text-[11px] text-slate-300">
                  <span className="text-muted">Areas: </span>
                  {asStringArray(a.areas).join(" · ")}
                </p>
              ) : null}

              {asStringArray(a.impacts).length ? (
                <div className="mt-3">
                  <p className="text-[10px] uppercase tracking-wider text-muted">Possible impacts</p>
                  <ul className="mt-1 list-disc space-y-0.5 pl-4 text-[11px] text-slate-300">
                    {asStringArray(a.impacts).map((imp) => (
                      <li key={imp}>{imp}</li>
                    ))}
                  </ul>
                </div>
              ) : null}

              {asStringArray(a.actions).length ? (
                <div className="mt-3">
                  <p className="text-[10px] uppercase tracking-wider text-muted">Recommended safety actions</p>
                  <ul className="mt-1 list-disc space-y-0.5 pl-4 text-[11px] text-slate-300">
                    {asStringArray(a.actions).map((act) => (
                      <li key={act}>{act}</li>
                    ))}
                  </ul>
                </div>
              ) : null}

              <div className="mt-3 border-t border-sky-400/10 pt-2 text-[10px] text-muted">
                Issued {fmtDateTime(a.issuedAt)} · effective {fmtDateTime(a.effectiveAt)} · expires {fmtDateTime(a.expiresAt)}
                {a.evidence && Object.keys(a.evidence).length ? ` · evidence: ${Object.entries(a.evidence).map(([k, v]) => `${k}=${String(v)}`).join(", ")}` : ""}
              </div>
            </Card>
          );
        })}
      </div>

      <Card>
        <SectionTitle title="How severity is decided" subtitle="Every threshold is published so you can audit the screening yourself." />
        <div className="grid gap-3 text-xs md:grid-cols-3">
          <div className="glass-soft p-3">
            <p className="font-medium text-amber-200">Advisory</p>
            <p className="mt-1 text-muted">Be aware. Rain ≥ 50 mm/24 h, wind ≥ 40 km/h, CAPE ≥ 1200 J/kg, apparent temperature ≥ 36 °C.</p>
          </div>
          <div className="glass-soft p-3">
            <p className="font-medium text-orange-200">Watch</p>
            <p className="mt-1 text-muted">Be prepared. Rain ≥ 75 mm/24 h, wind ≥ 62 km/h, CAPE ≥ 2500 J/kg, apparent temperature ≥ 39 °C, coastal wind ≥ 70 km/h.</p>
          </div>
          <div className="glass-soft p-3">
            <p className="font-medium text-rose-200">Warning (screening)</p>
            <p className="mt-1 text-muted">Act if confirmed officially. Rain ≥ 100 mm/24 h, wind ≥ 90 km/h, apparent temperature ≥ 43 °C. Only DMC / Met Department can issue official warnings.</p>
          </div>
        </div>
      </Card>
    </div>
  );
}
