import { randomBytes, scryptSync } from "node:crypto";
import { Client } from "pg";

const url = process.env.DATABASE_URL ?? "postgresql://postgres:postgres@127.0.0.1:5432/app_db";

function hash(password) {
  const salt = randomBytes(16).toString("hex");
  return `${salt}:${scryptSync(password, salt, 64).toString("hex")}`;
}

const client = new Client({ connectionString: url });
await client.connect();

async function upsertUser(email, name, password, role, language) {
  const res = await client.query(
    `insert into users (email, name, password_hash, role, language)
     values ($1,$2,$3,$4,$5)
     on conflict (email) do update set name = excluded.name, role = excluded.role
     returning id`,
    [email, name, hash(password), role, language],
  );
  return res.rows[0].id;
}

const adminId = await upsertUser("admin@lkweather.lk", "LWI Administrator", "Admin@12345", "admin", "en");
const demoId = await upsertUser("nuwan@example.lk", "Nuwan Perera", "Citizen@12345", "user", "si");
const tamilId = await upsertUser("mathy@example.lk", "Mathy Raj", "Citizen@12345", "user", "ta");

await client.query(
  `insert into saved_locations (user_id, label, district, province, lat, lon, is_default)
   select $1,'Colombo','Colombo','Western',6.9271,79.8612,true
   where not exists (select 1 from saved_locations where user_id = $1)`,
  [demoId],
);
await client.query(
  `insert into saved_locations (user_id, label, district, province, lat, lon)
   select $1,'Jaffna','Jaffna','Northern',9.6615,80.0255
   where not exists (select 1 from saved_locations where user_id = $1 and label = 'Jaffna')`,
  [demoId],
);

await client.query(
  `insert into subscriptions (user_id, scope_type, scope_label, district, lat, lon, categories, minimum_severity)
   select $1,'district','Colombo','Colombo',6.9271,79.8612,$2::jsonb,'advisory'
   where not exists (select 1 from subscriptions where user_id = $1)`,
  [demoId, JSON.stringify(["rain", "flood", "lightning", "wind", "heat"])],
);
await client.query(
  `insert into subscriptions (user_id, scope_type, scope_label, district, lat, lon, categories, minimum_severity)
   select $1,'district','Jaffna','Jaffna',9.6615,80.0255,$2::jsonb,'watch'
   where not exists (select 1 from subscriptions where user_id = $1)`,
  [tamilId, JSON.stringify(["rain", "wind", "marine"])],
);

// Demo community observations, explicitly flagged as demonstration seed data.
const demoReports = [
  ["Nuwan Perera", "heavy_rain", "heavy", "Demo seed: continuous rain for the last two hours near Kohuwala; drain on the side road is overflowing.", "Kohuwala, Dehiwala", "Colombo", 6.8497, 79.8747, demoId],
  ["Mathy Raj", "waterlogging", "moderate", "Demo seed: knee-deep water collecting on Temple Road after the evening shower.", "Temple Road, Nallur", "Jaffna", 9.6733, 80.0333, tamilId],
  ["LWI Demo Observer", "strong_wind", "moderate", "Demo seed: gusty winds bending coconut palms along the coast this afternoon.", "Kalpiti town", "Puttalam", 8.2363, 79.7663, null],
];

for (const [name, category, intensity, note, place, district, lat, lon, uid] of demoReports) {
  await client.query(
    `insert into community_reports (user_id, reporter_name, category, intensity, note, place_label, district, lat, lon, credibility, is_demo)
     select $1,$2,$3,$4,$5,$6,$7,$8,$9,55,true
     where not exists (select 1 from community_reports where note = $5)`,
    [uid, name, category, intensity, note, place, district, lat, lon],
  );
}

await client.query(
  `insert into audit_logs (user_id, actor_label, action, entity, meta)
   values ($1,'system','seed.completed','users',$2::jsonb)
   on conflict do nothing`,
  [adminId, JSON.stringify({ seeded: ["admin", "demo users", "demo community reports"] })],
);

const counts = await client.query(
  `select (select count(*) from users) as users, (select count(*) from community_reports) as reports, (select count(*) from subscriptions) as subs`,
);
console.log("Seed complete:", counts.rows[0]);
await client.end();
